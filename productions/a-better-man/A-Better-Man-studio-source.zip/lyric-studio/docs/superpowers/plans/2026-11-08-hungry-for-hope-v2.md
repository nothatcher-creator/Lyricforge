# Hungry For Hope V2 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox syntax for tracking.

**Goal:** Deliver a separate full-song 1080p V2 implementing the ten individually approved visual upgrades.
**Architecture:** Keep the existing project, cues, audio and V1 component intact. Add a typed V2 shot timeline, dedicated layered compositor and generated asset catalog. Preview and export share the composition; baseline media/QC checks apply to the finished file.
**Tech Stack:** React, TypeScript, Remotion, Canvas/SVG, FFmpeg, image_gen.
**Spec:** `docs/hungry-for-hope-approved-upgrades.md`

## Global Constraints

- Preserve the existing lyric lines, word timestamps and full 176.84-second source audio.
- Deliver 1920×1080, 24 FPS, H.264/AAC; preserve V1 artifacts and existing repository files.
- Use multiple genuine generated assets per setting, multiple reference-based artist scenes, and generated title assets.
- Implement all ten approved ideas; exclude semantic word effects, additional lyric retiming, and a recurring amber-light narrative.
- No paid external generation services or subscriptions; image animation is procedural, not claimed as generated video footage.

## Review Focus

- Long phrases and oblique world text must stay readable and inside safe boundaries.
- Monochrome middle covers the quiet passages and build; the returning full hook restores color.
- Generated title wording and artist identity references must be visually checked; no unrelated portrait substitution.
- Every scene interval and transition must resolve to real assets with no timeline gaps.
- Frame, audio, decode and file-integrity checks apply to the final delivered MP4, not only preview.

### Task 1: Generated assets and provenance
**Files:** `public/hope-v2/`, `projects/hope-v2/assets.json`
**Interfaces:** Asset IDs resolve to local PNGs; manifest records kind, setting, dimensions, hash and generator provenance.
- [ ] Generate two additional environment views for each of coast, cathedral and aperture, plus separate foreground assets.
- [ ] Generate storm portrait, ruined-hall silhouette and warm artist portrait using the inspected local reference composite.
- [ ] Generate matching transparent opening and closing title marks with exact wording.
- [ ] Inspect assets, verify title text and alpha, and write the provenance manifest.

### Task 2: Shot and project model
**Files:** `src/hope-v2/model.ts`, `server/build-hope-v2.ts`, `projects/hungry-for-hope-v2.json`, `tests/hope-v2.test.ts`
**Interfaces:** `V2Shot` contains start/end, plate, foreground, transition, text placement, focus and chorus level. `HopeV2Project` extends `Project` with shots and asset references.
- [ ] Test unchanged lyric/audio data, contiguous complete shot coverage, asset references, monochrome interval, and increasing full-hook levels.
- [ ] Build approximately 28 phrase/section-motivated shots with 3D/world text placements on selected shots.
- [ ] Run model tests and inspect the serialized timeline.

### Task 3: Layered film composition
**Files:** `src/hope-v2/HopeV2Film.tsx`, `src/hope-v2/Atmosphere.tsx`, `src/Video.tsx`
**Interfaces:** `HopeV2Film({project: HopeV2Project})` renders frame-deterministically; `getShotState(project,time)` supports render and tests.
- [ ] Layer generated plates and foregrounds with independent motion; animate coast water bands, rain, clouds/fog and dust.
- [ ] Add camera paths, focus pulls, occlusion/cloud/arch transitions, and selected projected/reflected/fog-space lyrics.
- [ ] Escalate full choruses through framing, type size, lighting and camera; make the middle monochrome and restrained.
- [ ] Choreograph light with stored bass/impact data, then apply matched grade, bloom, animated grain and fast-move motion trails.
- [ ] Reveal generated title assets at both ends; load the V2 project in the existing editor.

### Task 4: Verification and delivery
**Files:** `server/render-hope-v2.ts`, `server/qc-hope-v2.py`, `tests/hope-v2-layout.mjs`, `docs/hungry-for-hope-v2-production.md`
- [ ] Typecheck/build; run model tests and browser checks at lyric midpoint and transition samples.
- [ ] Render and visually inspect representative shots, projected text, focus changes, monochrome/color return and generated titles.
- [ ] Render the complete MP4; verify 4,245 frames, dimensions/FPS/audio, full decoding, audio start alignment, peak, and contact sheet.
- [ ] Package assets/fonts/source/JSON/SRT and a ten-item implementation map.
- [ ] Push a separate V2 production folder/branch to Lyricforge and verify the published video hash and URL.
