# A Better Man production plan

Spec: docs/a-better-man-treatment.md. User supplied audio, exact lyrics and two artist references, requested greater effort after Hungry For Hope V2, and delegated technical/artistic decisions in the master prompt.

1. Analyze audio; preserve canonical text; independently transcribe and align; inspect vocal timing and discrepancies. Write recoverable cues and confidence report.
2. Generate a coherent set of mirror-room, industrial, suspended-reflection, daylight/fatherhood and reference-based artist assets, plus foreground glass and title pair. Record real provenance and licenses.
3. Build a typed shot timeline and dedicated deterministic composition using the existing editor/render system. Develop distinct typography, depth, transitions, instrumental storytelling and escalating refrains. Keep V2 files intact.
4. Verify source text/timing/shot coverage and safe-layout samples; inspect representative frames; render the whole song; verify actual MP4 decode, frames, audio and contact sheet; package and upload a separate production.

Review focus: repeated hooks must remain in sequence; literal supplied spellings preserved; no invented performance/child identity; dark scenes retain text contrast; end cards fit video; no lyric invented over instrumental gap. Full song and exact frame/audio checks apply to delivery. V2 remains the first delivery priority.
