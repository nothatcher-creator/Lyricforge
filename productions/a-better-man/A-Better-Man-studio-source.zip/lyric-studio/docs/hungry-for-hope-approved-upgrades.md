# Hungry For Hope — approved revision brief

Artist: #WEED_SMOK

Status: 10 of 10 ideas approved individually in conversation. These are planned upgrades to the delivered first cut.

1. **Living cinematic environments.** Build each setting from multiple generated assets: wide shots, closer details, and atmospheric layers. Animate weather, fog, dust, waves and light with intentional musical progression.

2. **Cinematic artist scenes.** Use the supplied artist photos as references for multiple generated artist scenes, including storm-lit close-ups, silhouettes within the ruins, and portraits near the amber opening.

3. **Escalating choruses.** Keep the first hook dark and contained. Expand later hooks through wider shots, stronger lighting and larger typography. Make the final hook the visual peak.

4. **Connected cinematic transitions.** Connect scenes through archways, sweeping clouds and foreground occlusion so locations feel part of one coherent world.

5. **Lyrics integrated into environments.** Project selected phrases onto walls, reflect them across wet ground, or suspend them within fog. Match perspective and lighting while preserving readability.

6. **Focus pulls and depth of field.** Shift focus from foreground rain or debris to artist imagery. Soften scenery when needed to keep lyrics crisp and prominent.

7. **Lighting choreographed to music.** Use broad light waves for bass, brief rain and portrait-edge illumination for percussion, and opening light beams for musical swells.

8. **Black-and-white middle section.** Use intimate artist close-ups, deep shadows and restrained movement during the quieter middle section. Return to full color and wider environments with the hook.

9. **Generated opening and closing titles.** Create generated title assets with distinctive lettering for #WEED_SMOK and Hungry For Hope. Use matching cinematic opening and closing compositions woven into the imagery.

10. **Unified cinematic finishing.** Match shot color and exposure, then apply subtle light bloom, fine animated film grain and motion blur during fast movements.

## Not selected during the brainstorm

- Semantic word animations acting out literal meanings
- An additional dedicated vocal-timing refinement pass
- A recurring small amber-light narrative motif

Existing baseline timing and media verification remain part of the studio workflow.
