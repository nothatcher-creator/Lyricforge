import React, { useEffect, useLayoutEffect, useRef, useState } from "react";
import {
  staticFile,
  delayRender,
  continueRender,
  cancelRender,
  useVideoConfig,
} from "remotion";
import { BetterProject, BetterShot, betterShotAt, clamp, ease } from "./model";
const random = (i: number) => {
  const n = Math.sin(i * 127.1 + 91.7) * 43121.431;
  return n - Math.floor(n);
};
export function WorldCanvas({
  p,
  t,
  bass,
  hit,
}: {
  p: BetterProject;
  t: number;
  bass: number;
  hit: number;
}) {
  const { width: W, height: H, fps } = useVideoConfig(),
    ref = useRef<HTMLCanvasElement>(null),
    [handle] = useState(() => delayRender("Canvas world assets")),
    [images, setImages] = useState<Map<string, HTMLImageElement>>(new Map()),
    continued = useRef(false);
  const assetKey = [
    ...new Set([
      ...p.film.shots.flatMap((s) => [s.plate, s.foreground]),
      "better-man/mirror-detail.png",
    ]),
  ]
    .sort()
    .join("\n");
  useEffect(() => {
    let live = true;
    const keys = assetKey.split("\n");
    Promise.all(
      keys.map(
        (file) =>
          new Promise<[string, HTMLImageElement]>((resolve, reject) => {
            const img = new Image();
            img.onload = () => resolve([file, img]);
            img.onerror = () => reject(Error("Missing world image: " + file));
            img.src = staticFile(file);
          }),
      ),
    )
      .then((entries) => {
        if (live) setImages(new Map(entries));
      })
      .catch((e) => {
        if (live) cancelRender(e);
      });
    return () => {
      live = false;
    };
  }, [assetKey]);
  useLayoutEffect(() => {
    const c = ref.current?.getContext("2d", {
      alpha: false,
      willReadFrequently: true,
    });
    if (!c || !images.size) return;
    const { shot: s, previous, index, local, progress } = betterShotAt(p, t),
      transition = index > 0 && local < 0.72,
      mix = ease(local / 0.72);
    if (
      ![
        s.plate,
        s.foreground,
        previous.plate,
        "better-man/mirror-detail.png",
      ].every((k) => images.has(k))
    )
      return;
    const cover = (
      img: HTMLImageElement,
      x: number,
      y: number,
      w: number,
      h: number,
    ) => {
      const scale = Math.max(w / img.width, h / img.height),
        sw = w / scale,
        sh = h / scale;
      c.drawImage(
        img,
        (img.width - sw) / 2,
        (img.height - sh) / 2,
        sw,
        sh,
        x,
        y,
        w,
        h,
      );
    };
    const plate = (shot: BetterShot, alpha: number) => {
      const ph = clamp((t - shot.start) / (shot.end - shot.start)),
        x =
          shot.camera === "slide"
            ? (ph - 0.5) * 2.2
            : Math.sin(t * 0.08) * 0.35,
        y = Math.cos(t * 0.065) * 0.25,
        scale =
          1.035 +
          (shot.camera === "pull" ? 1 - ph : ph) *
            (0.035 + shot.level * 0.007) +
          bass * shot.level * 0.0008;
      c.save();
      c.globalAlpha = alpha;
      c.translate(W / 2 + (x / 100) * W, H / 2 + (y / 100) * H);
      c.scale(scale, scale);
      c.rotate(
        ((shot.mode === "hook" ? Math.sin(t * 0.09) * shot.level * 0.025 : 0) *
          Math.PI) /
          180,
      );
      cover(images.get(shot.plate)!, -W / 2, -H / 2, W, H);
      c.restore();
    };
    c.fillStyle = "#04070d";
    c.fillRect(0, 0, W, H);
    if (transition) plate(previous, 1);
    c.save();
    if (transition && index % 3 === 1) {
      c.beginPath();
      c.moveTo(0, 0);
      c.lineTo(mix * 1.25 * W, 0);
      c.lineTo((mix * 1.25 - 0.25) * W, H);
      c.lineTo(0, H);
      c.closePath();
      c.clip();
    }
    plate(s, transition ? mix : 1);
    c.restore();
    // Filmic negative space and edge exposure, drawn in one raster surface.
    if (s.layout === "right") {
      const g = c.createLinearGradient(0, 0, W, 0);
      g.addColorStop(0, "transparent");
      g.addColorStop(0.2, "transparent");
      g.addColorStop(0.46, "rgba(4,7,13,.12)");
      g.addColorStop(1, "rgba(4,7,13,.46)");
      c.fillStyle = g;
      c.fillRect(0, 0, W, H);
    } else {
      c.save();
      c.translate(W / 2, H * 0.48);
      c.scale(W, H);
      const g = c.createRadialGradient(0, 0, 0, 0, 0, 0.65);
      g.addColorStop(0, "rgba(3,7,13,.32)");
      g.addColorStop(1, "transparent");
      c.fillStyle = g;
      c.fillRect(-1, -1, 2, 2);
      c.restore();
    }
    const edge = c.createLinearGradient(0, H, 0, 0);
    edge.addColorStop(0, "#050a13a0");
    edge.addColorStop(0.35, "transparent");
    edge.addColorStop(0.72, "transparent");
    edge.addColorStop(1, "#050a1350");
    c.fillStyle = edge;
    c.fillRect(0, 0, W, H);
    if ((s.mode === "hook" || s.mode === "instrumental") && !s.warm)
      for (const i of [0, 1]) {
        const pw = W * 0.17,
          ph = H * 0.72,
          x = i ? W * 0.89 : -W * 0.06,
          y = i ? H * 0.5 : -H * 0.12,
          angle =
            ((i ? -1 : 1) * (16 + Math.sin(t * 0.15 + i) * 4) * Math.PI) / 180;
        c.save();
        c.translate(x + pw / 2, y + ph / 2 + Math.sin(t * 0.18 + i) * 10);
        c.transform(Math.cos(angle), Math.sin(angle) * 0.08, 0, 1, 0, 0);
        c.translate(-pw / 2, -ph / 2);
        c.globalAlpha = 0.1 + s.level * 0.007;
        c.beginPath();
        const pts = i
          ? [
              [0.25, 0],
              [1, 0.08],
              [0.85, 1],
              [0, 0.8],
            ]
          : [
              [0, 0],
              [0.85, 0.12],
              [1, 0.88],
              [0.1, 1],
            ];
        pts.forEach(([px, py], j) =>
          j ? c.lineTo(px * pw, py * ph) : c.moveTo(px * pw, py * ph),
        );
        c.closePath();
        c.clip();
        c.save();
        c.translate(pw / 2, ph / 2 + Math.sin(t * 0.1) * 0.03 * ph);
        c.scale(1.2, 1.2);
        cover(
          images.get("better-man/mirror-detail.png")!,
          -pw / 2,
          -ph / 2,
          pw,
          ph,
        );
        c.restore();
        c.strokeStyle = "#b3c5d24a";
        c.lineWidth = 1;
        c.stroke();
        c.restore();
      }
    c.save();
    c.globalAlpha = s.warm ? 0.28 : 0.3;
    c.translate(W / 2, H / 2);
    c.scale(1.07, 1.07);
    c.translate(
      ((Math.sin(t * 0.1) * 0.6 - (progress - 0.5) * 1.5) / 100) * W,
      ((Math.cos(t * 0.12) * 0.3) / 100) * H,
    );
    cover(images.get(s.foreground)!, -W / 2, -H / 2, W, H);
    c.restore();
    if (transition && index % 3 === 2) {
      c.save();
      c.globalAlpha = Math.sin(Math.PI * clamp(local / 0.72)) * 0.7;
      c.translate(W / 2 + (mix * 2.8 - 1.4) * W, H / 2);
      c.scale(2.6, 2.6);
      cover(images.get(s.foreground)!, -W / 2, -H / 2, W, H);
      c.restore();
    }
    c.save();
    c.globalCompositeOperation = "screen";
    c.translate(W * (s.warm ? 0.74 : 0.42), H * 0.38);
    c.scale(W, H);
    const glow = c.createRadialGradient(0, 0, 0, 0, 0, 0.68);
    glow.addColorStop(
      0,
      `rgba(${s.warm ? "231,210,177" : "190,215,231"},${0.012 + bass * (0.022 + s.level * 0.007)})`,
    );
    glow.addColorStop(1, "transparent");
    c.fillStyle = glow;
    c.fillRect(-2, -2, 4, 4);
    c.restore();
    c.save();
    c.scale(W / 1920, H / 1080);
    const atmosphere = s.mode === "bridge" ? 0.18 : 0.3;
    for (const i of [0, 1, 2]) {
      const x = 220 + i * 420,
        a = 540 + i * 440 + Math.sin(t * 0.07) * 50,
        b = 750 + i * 440,
        g = c.createLinearGradient(Math.min(x, a), 0, Math.max(x, b), 0);
      g.addColorStop(0, "transparent");
      g.addColorStop(0.5, "rgba(220,232,242,.12)");
      g.addColorStop(1, "transparent");
      c.globalAlpha = atmosphere * (0.25 + bass * 0.35 + s.level * 0.07);
      c.fillStyle = g;
      c.beginPath();
      c.moveTo(x, -100);
      c.lineTo(a, 1150);
      c.lineTo(b, 1150);
      c.closePath();
      c.fill();
    }
    for (let i = 0; i < 26; i++) {
      c.globalAlpha = atmosphere * (0.08 + random(i + 31) * 0.4);
      c.fillStyle = s.warm ? "#e7d6b6" : "#c8d9e5";
      c.beginPath();
      c.arc(
        random(i) * 2200 - 100 + Math.sin(t * 0.15 + i) * 12,
        ((((random(i + 41) * 1350 - t * (8 + random(i + 12) * 12)) % 1350) +
          1350) %
          1350) -
          100,
        0.7 + random(i + 5) * 1.4,
        0,
        Math.PI * 2,
      );
      c.fill();
    }
    for (const i of [0, 1]) {
      c.globalAlpha = atmosphere * hit * (0.12 + s.level * 0.025);
      c.strokeStyle = "#d8e7ef";
      c.lineWidth = 2 + hit * 3;
      c.beginPath();
      c.moveTo(i ? 1770 : 120, 0);
      c.lineTo(i ? 1640 : 260, 1080);
      c.stroke();
    }
    c.restore();
    c.save();
    c.globalAlpha = 0.045;
    c.globalCompositeOperation = "soft-light";
    c.scale(W / 960, H / 540);
    const noise = document.createElement("canvas");
    noise.width = 192;
    noise.height = 192;
    const nc = noise.getContext("2d")!;
    const pixels = nc.createImageData(192, 192);
    let seed =
      (Math.floor(Math.round(t * fps) / 2) * 2 * 1664525 + 1013904223) >>> 0;
    for (let i = 0; i < pixels.data.length; i += 4) {
      seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
      const value = seed >>> 24;
      pixels.data[i] = value;
      pixels.data[i + 1] = value;
      pixels.data[i + 2] = value;
      pixels.data[i + 3] = 255;
    }
    nc.putImageData(pixels, 0, 0);
    c.fillStyle = c.createPattern(noise, "repeat")!;
    c.fillRect(0, 0, 960, 540);
    c.restore();
    if (!continued.current) {
      continued.current = true;
      continueRender(handle);
    }
  }, [images, t, p, W, H, fps, bass, hit, handle]);
  return (
    <canvas
      ref={ref}
      width={W}
      height={H}
      style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}
    />
  );
}
