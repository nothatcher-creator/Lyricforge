export const betterFonts = {
  display: "fonts/BarlowCondensed-Black.ttf",
  bridge: "fonts/CormorantGaramond.ttf",
} as const;
