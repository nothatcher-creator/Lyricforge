import { betterFonts } from "./fonts";
import { WorldCanvas } from "./WorldCanvas";
import React, { useEffect, useState } from "react";
import {
  AbsoluteFill,
  Audio,
  Img,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
  delayRender,
  continueRender,
} from "remotion";
import {
  BetterProject,
  BetterShot,
  BetterLine,
  betterShotAt,
  clamp,
  ease,
} from "./model";
import { FilmGrain } from "../hope-v2/Atmosphere";
const random = (i: number) => {
  const n = Math.sin(i * 127.1 + 91.7) * 43121.431;
  return n - Math.floor(n);
};
function World({
  p,
  t,
  bass,
  hit,
}: {
  p: BetterProject;
  t: number;
  bass: number;
  hit: number;
}) {
  const { shot: s, previous, index, local, progress } = betterShotAt(p, t),
    transition = index > 0 && local < 0.72,
    mix = ease(local / 0.72);
  const image = (shot: BetterShot, alpha: number) => {
    const ph = clamp((t - shot.start) / (shot.end - shot.start));
    return (
      <AbsoluteFill
        key={shot.id}
        style={{
          opacity: alpha,
          transform: `translate(${shot.camera === "slide" ? (ph - 0.5) * 2.2 : Math.sin(t * 0.08) * 0.35}%,${Math.cos(t * 0.065) * 0.25}%) scale(${1.035 + (shot.camera === "pull" ? 1 - ph : ph) * (0.035 + shot.level * 0.007) + bass * shot.level * 0.0008}) rotate(${shot.mode === "hook" ? Math.sin(t * 0.09) * shot.level * 0.025 : 0}deg)`,
        }}
      >
        <Img
          src={staticFile(shot.plate)}
          style={{ width: "100%", height: "100%", objectFit: "cover" }}
        />
      </AbsoluteFill>
    );
  };
  return (
    <>
      {transition && image(previous, 1)}
      <AbsoluteFill
        style={{
          opacity: transition ? mix : 1,
          clipPath:
            transition && index % 3 === 1
              ? `polygon(0 0,${mix * 125}% 0,${mix * 125 - 25}% 100%,0 100%)`
              : undefined,
        }}
      >
        {image(s, 1)}
      </AbsoluteFill>
      <AbsoluteFill
        style={{
          background:
            s.layout === "right"
              ? "linear-gradient(90deg,transparent 20%,rgba(4,7,13,.12) 46%,rgba(4,7,13,.46)),linear-gradient(0deg,#050a13a0,transparent 35%,transparent 75%,#050a1350)"
              : "radial-gradient(ellipse at 50% 48%,rgba(3,7,13,.32),transparent 78%),linear-gradient(0deg,#050a13a0,transparent 35%,transparent 72%,#050a1350)",
        }}
      />
      {(s.mode === "hook" || s.mode === "instrumental") &&
        !s.warm &&
        [0, 1].map((i) => (
          <div
            key={i}
            style={{
              position: "absolute",
              left: i ? "89%" : "-6%",
              top: i ? "50%" : "-12%",
              width: "17%",
              height: "72%",
              opacity: 0.1 + s.level * 0.007,
              overflow: "hidden",
              transform: `perspective(1200px) rotateY(${(i ? -1 : 1) * (16 + Math.sin(t * 0.15 + i) * 4)}deg) translateY(${Math.sin(t * 0.18 + i) * 10}px)`,
              clipPath: i
                ? "polygon(25% 0,100% 8%,85% 100%,0 80%)"
                : "polygon(0 0,85% 12%,100% 88%,10% 100%)",
              border: "1px solid #b3c5d24a",
            }}
          >
            <Img
              src={staticFile("better-man/mirror-detail.png")}
              style={{
                height: "100%",
                width: "100%",
                objectFit: "cover",
                transform: `scale(1.2) translateY(${Math.sin(t * 0.1) * 3}%)`,
              }}
            />
          </div>
        ))}
      <AbsoluteFill
        style={{
          opacity: s.warm ? 0.28 : 0.3,
          transform: `scale(1.07) translate(${Math.sin(t * 0.1) * 0.6 - (progress - 0.5) * 1.5}%,${Math.cos(t * 0.12) * 0.3}%)`,
          pointerEvents: "none",
        }}
      >
        <Img
          src={staticFile(s.foreground)}
          style={{ width: "100%", height: "100%", objectFit: "cover" }}
        />
      </AbsoluteFill>
      {transition && index % 3 === 2 && (
        <AbsoluteFill
          style={{
            opacity: Math.sin(Math.PI * clamp(local / 0.72)) * 0.7,
            transform: `translateX(${(mix * 2.8 - 1.4) * 100}%) scale(2.6)`,
          }}
        >
          <Img
            src={staticFile(s.foreground)}
            style={{ width: "100%", height: "100%", objectFit: "cover" }}
          />
        </AbsoluteFill>
      )}
      <AbsoluteFill
        style={{
          background: `radial-gradient(ellipse at ${s.warm ? 74 : 42}% 38%,rgba(${s.warm ? "231,210,177" : "190,215,231"},${0.012 + bass * (0.022 + s.level * 0.007)}),transparent 68%)`,
          mixBlendMode: "screen",
        }}
      />
      <svg
        viewBox="0 0 1920 1080"
        preserveAspectRatio="none"
        style={{
          position: "absolute",
          width: "100%",
          height: "100%",
          opacity: s.mode === "bridge" ? 0.18 : 0.3,
        }}
      >
        <defs>
          <linearGradient id="better-ray">
            <stop stopColor="#dce8f2" stopOpacity="0" />
            <stop offset=".5" stopColor="#dce8f2" stopOpacity=".12" />
            <stop offset="1" stopColor="#dce8f2" stopOpacity="0" />
          </linearGradient>
        </defs>
        {[0, 1, 2].map((i) => (
          <path
            key={i}
            d={`M${220 + i * 420} -100 L${540 + i * 440 + Math.sin(t * 0.07) * 50} 1150 L${750 + i * 440} 1150Z`}
            fill="url(#better-ray)"
            opacity={0.25 + bass * 0.35 + s.level * 0.07}
          />
        ))}
        {Array.from({ length: 26 }, (_, i) => (
          <circle
            key={i}
            cx={random(i) * 2200 - 100 + Math.sin(t * 0.15 + i) * 12}
            cy={
              ((((random(i + 41) * 1350 - t * (8 + random(i + 12) * 12)) %
                1350) +
                1350) %
                1350) -
              100
            }
            r={0.7 + random(i + 5) * 1.4}
            fill={s.warm ? "#e7d6b6" : "#c8d9e5"}
            opacity={0.08 + random(i + 31) * 0.4}
          />
        ))}
        {[0, 1].map((i) => (
          <path
            key={"glint" + i}
            d={`M${i ? 1770 : 120} 0 L${i ? 1640 : 260} 1080`}
            stroke="#d8e7ef"
            strokeWidth={2 + hit * 3}
            opacity={hit * (0.12 + s.level * 0.025)}
          />
        ))}
      </svg>
    </>
  );
}
function Lyrics({
  l,
  s,
  t,
  width,
  bass,
  hit,
  closing,
}: {
  l: BetterLine;
  s: BetterShot;
  t: number;
  width: number;
  bass: number;
  hit: number;
  closing: boolean;
}) {
  const side = s.layout === "right",
    bridge = s.mode === "bridge",
    hero = s.mode === "hook",
    local = t - l.start;
  const alpha = Math.min(ease(local / 0.18), clamp((l.end - t) / 0.16));
  const tail = hero
    ? l.text.startsWith("Find")
      ? 3
      : l.text.startsWith("I do")
        ? 3
        : l.text.startsWith("How")
          ? 2
          : l.text.startsWith("Said")
            ? 3
            : 1
    : 0;
  const split = l.words.length - tail,
    available = width * (side ? 0.46 : 0.78),
    tailChars = l.words
      .slice(split)
      .map((w) => w.text)
      .join(" ").length;
  const huge = Math.min(
    width * (side ? 0.063 : 0.087) + s.level * width * 0.002,
    available / Math.max(1, tailChars * 0.49),
  );
  const normal =
    width *
    (side
      ? l.text.length > 43
        ? 0.031
        : 0.037
      : l.text.length > 45
        ? 0.039
        : 0.047);
  const accent = s.warm ? "#e5d4b5" : pale(s.level);
  const span = (w: BetterLine["words"][number], i: number, large = false) => {
    const active = t >= w.start && t < w.end,
      entrance = ease((local - i * 0.016) / 0.28),
      sustain = active ? clamp((w.end - w.start - 0.5) / 1.7) : 0;
    return (
      <span
        data-word
        key={i}
        style={{
          display: "inline-block",
          whiteSpace: "nowrap",
          opacity: 0.58 + 0.42 * entrance,
          color: active || large ? accent : "#f0f0e9",
          transform: `translateY(${(1 - entrance) * 12}px) scale(${1 + (active ? hit * 0.012 : 0)},${1 + sustain * 0.018})`,
          textShadow: "0 3px 18px #000b",
        }}
      >
        {w.text.toUpperCase()}
      </span>
    );
  };
  return (
    <div
      data-lyric={l.id}
      data-layout={s.layout}
      style={{
        position: "absolute",
        left: side ? "43%" : "11%",
        width: side ? "46%" : "78%",
        top: closing ? "34%" : "48%",
        transform: `translateY(-50%) perspective(1600px) rotateY(${hero ? (side ? -3 : Math.sin(t * 0.15) * 1.2) : 0}deg) scale(${1 + bass * (hero ? 0.003 + s.level * 0.002 : 0.0015)})`,
        transformOrigin: "center",
        opacity: alpha,
        textAlign: "center",
        fontFamily: bridge ? "BetterSerif" : "BetterDisplay",
        fontWeight: bridge ? 500 : 900,
        letterSpacing: width * 0.0006,
        lineHeight: 1.18,
      }}
    >
      {hero ? (
        <>
          <div
            style={{
              fontSize: width * (side ? 0.022 : 0.027),
              display: "flex",
              flexWrap: "wrap",
              justifyContent: "center",
              gap: "0 .24em",
              marginBottom: width * 0.009,
            }}
          >
            {l.words.slice(0, split).map((w, i) => span(w, i))}
          </div>
          <div
            style={{
              fontSize: huge,
              display: "flex",
              flexWrap: "wrap",
              justifyContent: "center",
              gap: "0 .22em",
              lineHeight: 1.02,
              letterSpacing: -width * 0.001,
            }}
          >
            {l.words.slice(split).map((w, i) => span(w, split + i, true))}
          </div>
          <div
            style={{
              height: 1,
              width: `${24 + s.level * 7}%`,
              background: accent,
              opacity: 0.22,
              margin: "18px auto 0",
              transform: `scaleX(${0.7 + bass * 0.3})`,
            }}
          />
        </>
      ) : (
        <div
          style={{
            fontSize: bridge ? normal * 1.12 : normal,
            display: "flex",
            flexWrap: "wrap",
            justifyContent: "center",
            gap: "0 .25em",
            lineHeight: bridge ? 1.25 : 1.3,
          }}
        >
          {l.words.map((w, i) => span(w, i))}
        </div>
      )}
    </div>
  );
}
const pale = (level: number) =>
  level >= 4 ? "#e2e9eb" : level >= 2 ? "#ccdee8" : "#dbe3e7";
export const BetterFilm: React.FC<{ project: BetterProject }> = ({
  project: p,
}) => {
  const f = useCurrentFrame(),
    { fps, width } = useVideoConfig(),
    t = f / fps,
    { shot: s } = betterShotAt(p, t),
    l = p.lines.find((l) => t >= l.start && t < l.end);
  const [handle] = useState(() => delayRender("A Better Man typography"));
  useEffect(() => {
    Promise.all([
      document.fonts.load("900 16px BetterDisplay"),
      document.fonts.load("500 16px BetterSerif"),
    ])
      .then(() => continueRender(handle))
      .catch(() => continueRender(handle));
  }, [handle]);
  const bass = p.analysis.bass?.[Math.floor(t * 20)] || 0;
  let h = -10,
    strength = 0;
  for (const x of p.analysis.impacts || []) {
    if (x.time > t) break;
    h = x.time;
    strength = x.strength;
  }
  const hit = Math.exp(-(t - h) * 15) * strength * p.intensity,
    opening = t < 8.6,
    closing = t >= 302.55;
  const titleAlpha = opening
    ? ease((t - 0.7) / 1.2) * clamp((8.6 - t) / 0.8)
    : ease((t - 302.55) / 0.6) * clamp((p.duration - t) / 0.5);
  const WorldLayer = p.film.renderer === "canvas" ? WorldCanvas : World;
  return (
    <AbsoluteFill
      data-composition-frame={f}
      style={{
        background: "#04070d",
        overflow: "hidden",
        color: "#f0f0e9",
        fontFamily: "BetterDisplay",
      }}
    >
      <style>{`@font-face{font-family:BetterDisplay;src:url('${staticFile(betterFonts.display)}');font-weight:900}@font-face{font-family:BetterSerif;src:url('${staticFile(betterFonts.bridge)}');font-weight:300 700}`}</style>
      <Audio src={p.audio} />
      <WorldLayer p={p} t={t} bass={bass} hit={hit} />
      {!opening && !closing && p.branding && (
        <div
          style={{
            position: "absolute",
            left: "6.5%",
            top: "6%",
            fontSize: width * 0.0075,
            letterSpacing: width * 0.0026,
            opacity: 0.4,
          }}
        >
          {p.artist}
        </div>
      )}
      {l && (
        <Lyrics
          l={l}
          s={s}
          t={t}
          width={width}
          bass={bass}
          hit={hit}
          closing={closing}
        />
      )}
      {(opening || closing) && (
        <div
          data-title={opening ? "opening" : "closing"}
          style={{
            position: "absolute",
            left: opening ? "38%" : "42%",
            width: opening ? "56%" : "51%",
            top: opening ? "10%" : "53%",
            opacity: titleAlpha,
            transform: `translateY(${(1 - ease((opening ? t - 0.7 : t - 302.55) / 1)) * 12}px) scale(${1 + Math.min(8, opening ? t : t - 302.55) * 0.0015})`,
            clipPath: `inset(0 ${(1 - ease((opening ? t - 0.7 : t - 302.55) / 1.3)) * 100}% 0 0)`,
          }}
        >
          <Img
            src={staticFile(opening ? p.film.titleOpen : p.film.titleClose)}
            style={{ width: "100%", height: "auto" }}
          />
          {opening && (
            <div
              style={{
                textAlign: "center",
                fontSize: width * 0.0075,
                letterSpacing: width * 0.003,
                opacity: 0.65,
                marginTop: -20,
              }}
            >
              JUNE 11, 2025
            </div>
          )}
        </div>
      )}
      <AbsoluteFill
        style={{
          background: "radial-gradient(ellipse,transparent 40%,#02050a40)",
          pointerEvents: "none",
        }}
      />
      {p.film.renderer !== "canvas" && (
        <FilmGrain frame={Math.floor(f / 2) * 2} />
      )}
      <AbsoluteFill
        style={{
          background: "#04070d",
          opacity: 1 - Math.min(clamp(t / 0.7), clamp((p.duration - t) / 0.65)),
          pointerEvents: "none",
        }}
      />
    </AbsoluteFill>
  );
};
