import type { Project, Line, Word } from "../model";
export type BetterLine = Line & { section: string; block: number };
export type BetterShot = {
  id: string;
  start: number;
  end: number;
  plate: string;
  foreground: string;
  layout: "center" | "right";
  mode: "verse" | "hook" | "bridge" | "instrumental" | "title";
  level: number;
  camera: "push" | "pull" | "slide";
  warm: boolean;
};
export type BetterProject = Omit<Project, "lines"> & {
  lines: BetterLine[];
  film: {
    renderer?: "canvas" | "dom";
    shots: BetterShot[];
    titleOpen: string;
    titleClose: string;
    songDate: string;
  };
};
export const clamp = (n: number) => Math.max(0, Math.min(1, n));
export const ease = (n: number) => 1 - Math.pow(1 - clamp(n), 3);
export const isBetterProject = (p: Project): p is BetterProject =>
  Array.isArray((p as BetterProject).film?.shots) &&
  (p as BetterProject).film.shots.length > 0;
type RawLine = {
  text: string;
  start: number;
  end: number;
  section: string;
  block: number;
  words: (Word & { confidence: number })[];
};
export function createBetterProject(
  base: Project,
  measured: { duration: number; analysis: Project["analysis"] },
  raw: RawLine[],
  lyrics: string,
): BetterProject {
  const lines: BetterLine[] = raw.map((l, i) => ({
    ...l,
    id: `better-${i}`,
    start: Math.max(l.start - 0.1, i ? raw[i - 1].end : 0),
    preset: l.section.includes("Chorus")
      ? "impact"
      : l.section.includes("Bridge")
        ? "cinematic"
        : "rise",
    words: l.words.map((w) => ({
      ...w,
      review: i === 0 || (w.review ?? w.confidence < 0.25),
    })),
  }));
  for (let i = 0; i < lines.length; i++) {
    lines[i].end = Math.min(
      lines[i + 1]?.start ?? measured.duration,
      Math.max(lines[i].end, lines[i].end + 0.24),
    );
    if (
      lines[i].block === 18 &&
      lines[i + 1]?.block === 18 &&
      lines[i + 1].start - raw[i].end < 2
    )
      lines[i].end = lines[i + 1].start;
  }
  type Row = [number, string, BetterShot["layout"], BetterShot["mode"], number];
  const rows: Row[] = [
    [0, "artist-fractured", "right", "title", 0],
    [8.6, "mirror-detail", "right", "instrumental", 0],
    [16.5, "mirror-hall", "center", "instrumental", 0],
  ];
  const group = (b: number) => lines.filter((l) => l.block === b);
  const add = (
    b: number,
    a: string,
    layout: BetterShot["layout"],
    mode: BetterShot["mode"],
    level = 0,
    n = 0,
  ) => rows.push([group(b)[n].start, a, layout, mode, level]);
  add(0, "artist-fractured", "right", "verse");
  add(0, "mirror-hall", "center", "verse", 0, 3);
  add(0, "mirror-detail", "right", "verse", 0, 5);
  add(1, "mirror-hall", "center", "hook", 1);
  add(2, "artist-fractured", "right", "hook", 1);
  add(2, "mirror-hall", "center", "hook", 1, 2);
  add(3, "industrial-wide", "center", "verse");
  add(3, "artist-industrial", "right", "verse", 0, 2);
  add(3, "industrial-detail", "right", "verse", 0, 4);
  add(4, "industrial-wide", "center", "hook", 2);
  add(5, "artist-industrial", "right", "hook", 2);
  add(5, "industrial-wide", "center", "hook", 2, 2);
  add(6, "suspended-wide", "center", "verse");
  add(6, "suspended-detail", "right", "verse", 0, 2);
  add(6, "artist-mosaic", "right", "verse", 0, 4);
  add(7, "suspended-wide", "center", "hook", 3);
  add(8, "artist-mosaic", "right", "hook", 3);
  add(8, "suspended-wide", "center", "hook", 3, 2);
  add(9, "artist-intimate", "right", "bridge");
  add(10, "mirror-detail", "center", "bridge");
  add(11, "artist-intimate", "right", "bridge");
  rows.push(
    [189.2, "mirror-detail", "center", "instrumental", 0],
    [194.5, "suspended-detail", "right", "instrumental", 0],
    [199.8, "artist-mosaic", "right", "instrumental", 0],
    [205.2, "suspended-wide", "center", "instrumental", 0],
  );
  add(12, "artist-mosaic", "right", "hook", 4);
  add(13, "suspended-wide", "center", "hook", 4);
  add(13, "artist-fractured", "right", "hook", 4, 2);
  rows.push([235.2, "daylight-wide", "center", "instrumental", 0]);
  add(14, "father-wide", "right", "verse");
  add(14, "father-detail", "right", "verse", 0, 2);
  add(14, "artist-resolved", "right", "verse", 0, 4);
  add(15, "daylight-wide", "center", "hook", 5);
  add(16, "artist-resolved", "right", "hook", 5);
  add(16, "daylight-wide", "center", "hook", 5, 2);
  add(17, "artist-intimate", "right", "bridge");
  add(18, "daylight-wide", "center", "hook", 6);
  add(18, "artist-resolved", "right", "hook", 6, 2);
  add(19, "artist-resolved", "right", "verse");
  rows.sort((a, b) => a[0] - b[0]);
  const shots: BetterShot[] = rows.map(
    ([start, asset, layout, mode, level], i) => {
      const warm = /father|resolved|daylight/.test(asset);
      return {
        id: `better-shot-${i}`,
        start,
        end: rows[i + 1]?.[0] ?? measured.duration,
        plate: `better-man/${asset}.png`,
        foreground: `better-man/foreground-${warm ? "window" : "mirror"}.png`,
        layout,
        mode,
        level,
        camera: i % 3 === 0 ? "push" : i % 3 === 1 ? "pull" : "slide",
        warm,
      };
    },
  );
  const impacts: NonNullable<Project["analysis"]["impacts"]> = [];
  for (const h of measured.analysis.impacts || [])
    if (
      h.strength > 0.78 &&
      (!impacts.length || h.time - impacts.at(-1)!.time > 0.32)
    )
      impacts.push(h);
  return {
    ...structuredClone(base),
    id: "a-better-man",
    title: "A Better Man",
    artist: "#WEED_SMOK",
    audio: "/media/a-better-man.mp3",
    duration: measured.duration,
    lyrics,
    lines,
    scenes: shots.map((s) => ({
      id: s.id,
      start: s.start,
      end: s.end,
      label: `${s.mode} ${s.level || ""}`.trim(),
      environment: s.plate,
      energy: s.level ? 0.6 + s.level * 0.06 : 0.4,
      camera: s.camera,
      effects: s.mode === "hook" ? 0.65 : 0.35,
    })),
    analysis: {
      ...measured.analysis,
      bpm: 88.24,
      beats: measured.analysis.beats.filter((_, i) => i % 2 === 0),
      impacts,
      method:
        measured.analysis.method +
        " Main pulse uses 88.24 BPM half-time interpretation; measured transients drive impacts.",
    },
    style: "better-man",
    accent: "#d5e3e9",
    font: "Barlow Condensed",
    intensity: 0.85,
    branding: true,
    approved: true,
    settings: { width: 1920, height: 1080, fps: 24 },
    history: [
      "User approved Fragments / Becoming Whole treatment.",
      "All 361 supplied lyric words preserved, including spelling and profanity.",
      "Independent Whisper anchors constrain local CTC phrase windows; uncertain boundaries retained for review.",
      "Reference-based generated artist stills; anonymous fictional fatherhood imagery; no singing performance or real family identity claimed.",
    ],
    film: {
      renderer: "canvas",
      shots,
      titleOpen: "better-man/title-open.png",
      titleClose: "better-man/title-close.png",
      songDate: "2025-06-11",
    },
  };
}
export function betterShotAt(p: BetterProject, time: number) {
  const t = Math.max(0, Math.min(time, p.duration - 0.000001));
  const i = Math.max(
    0,
    p.film.shots.findIndex((s) => t >= s.start && t < s.end),
  );
  const shot = p.film.shots[i];
  return {
    shot,
    index: i,
    previous: p.film.shots[Math.max(0, i - 1)],
    local: t - shot.start,
    progress: clamp((t - shot.start) / (shot.end - shot.start)),
  };
}
