import type { Project } from "../model";
export type Placement = "center" | "right" | "wall" | "floor" | "fog";
export type V2Shot = {
  id: string;
  start: number;
  end: number;
  plate: string;
  foreground: string;
  world: "coast" | "cathedral" | "aperture" | "artist";
  placement: Placement;
  transition: "cloud" | "arch" | "occlusion";
  camera: "push" | "pull" | "slide";
  level: number;
  focus: boolean;
  gradedPlate?: string;
  monoPlate?: string;
  gradedForeground?: string;
  monoForeground?: string;
};
export type HopeV2Project = Project & {
  v2: {
    shots: V2Shot[];
    titleOpen: string;
    titleClose: string;
    monochrome: [number, number];
    approvedUpgrades: number[];
  };
};
export const clamp = (x: number) => Math.max(0, Math.min(1, x));
export const ease = (x: number) => 1 - Math.pow(1 - clamp(x), 3);
export const isV2Project = (p: Project): p is HopeV2Project => {
  const data = (p as Partial<HopeV2Project>).v2;
  return !!data && Array.isArray(data.shots) && data.shots.length > 0 &&
    typeof data.titleOpen === "string" && typeof data.titleClose === "string";
};
export const shotEnvironment = (shot: Pick<V2Shot, "world" | "plate">) =>
  shot.plate.includes("artist-storm") ? "coast" :
  shot.plate.includes("artist-amber") ? "aperture" : shot.world;
export const monochromeAt = (t: number) =>
  clamp((t - 87.59) / 0.7) * (1 - clamp((t - 115.43) / 0.65));
export function buildV2(v1: Project): HopeV2Project {
  const rows: [
    number,
    string,
    V2Shot["world"],
    Placement,
    V2Shot["transition"],
    number,
  ][] = [
    [0, "artist-storm", "artist", "right", "cloud", 0],
    [9.49, "../hope/coast", "coast", "center", "cloud", 0],
    [18.39, "coast-detail", "coast", "fog", "cloud", 0],
    [24.99, "artist-storm", "artist", "right", "occlusion", 0],
    [29.01, "../hope/cathedral", "cathedral", "center", "arch", 1],
    [37.65, "cathedral-wall", "cathedral", "wall", "arch", 0],
    [45.45, "artist-silhouette", "artist", "right", "occlusion", 0],
    [50.3, "cathedral-vault", "cathedral", "fog", "arch", 0],
    [54.51, "../hope/cathedral", "cathedral", "center", "arch", 2],
    [58.61, "cathedral-vault", "cathedral", "center", "occlusion", 2],
    [63.61, "coast-high", "coast", "center", "cloud", 0],
    [72.63, "cathedral-wall", "cathedral", "wall", "arch", 0],
    [81.75, "artist-silhouette", "artist", "right", "occlusion", 0],
    [87.59, "artist-storm", "artist", "right", "cloud", 0],
    [94.07, "coast-detail", "coast", "fog", "cloud", 0],
    [98.97, "artist-amber", "artist", "right", "occlusion", 0],
    [106.1, "aperture-detail", "aperture", "floor", "arch", 0],
    [111.51, "cathedral-wall", "cathedral", "wall", "arch", 0],
    [115.43, "aperture-wide", "aperture", "center", "arch", 3],
    [119.45, "artist-amber", "artist", "right", "occlusion", 3],
    [124.75, "aperture-detail", "aperture", "floor", "arch", 0],
    [133.81, "../hope/light", "aperture", "fog", "cloud", 0],
    [142.89, "artist-amber", "artist", "right", "occlusion", 0],
    [147.72, "aperture-detail", "aperture", "floor", "arch", 0],
    [151.55, "aperture-wide", "aperture", "center", "arch", 4],
    [155.93, "artist-amber", "artist", "right", "occlusion", 4],
    [160.37, "aperture-wide", "aperture", "center", "arch", 4],
    [163, "../hope/portrait", "artist", "center", "cloud", 0],
  ];
  const shots: V2Shot[] = rows.map(
    ([start, asset, world, placement, transition, level], i) => ({
      id: `v2-shot-${i + 1}`,
      start,
      end: rows[i + 1]?.[0] ?? v1.duration,
      plate: asset.startsWith("../hope/")
        ? asset.slice(3) + ".png"
        : `hope-v2/${asset}.png`,
      foreground: `hope-v2/foreground-${world === "coast" || asset === "artist-storm" ? "rain" : world === "aperture" || asset === "artist-amber" ? "stone" : "arch"}.png`,
      world,
      placement,
      transition,
      level,
      focus: i % 3 !== 1,
      camera: i % 3 === 0 ? "push" : i % 3 === 1 ? "slide" : "pull",
    }),
  );
  return {
    ...structuredClone(v1),
    id: "hungry-for-hope-v2",
    title: "Hungry For Hope",
    style: "hope-v2",
    approved: true,
    intensity: 0.8,
    history: [
      ...v1.history,
      "V2: ten approved visual upgrades. Original audio, words and timestamps retained.",
    ],
    v2: {
      shots,
      titleOpen: "hope-v2/title-open.png",
      titleClose: "hope-v2/title-close.png",
      monochrome: [87.59, 115.43],
      approvedUpgrades: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    },
  };
}
export function getShotState(p: HopeV2Project, t: number) {
  const playhead = Math.max(0, Math.min(t, p.duration - 0.000001));
  const index = Math.max(0, p.v2.shots.findIndex((s) => playhead >= s.start && playhead < s.end));
  const shot = p.v2.shots[index];
  return {
    shot,
    index,
    previous: p.v2.shots[Math.max(0, index - 1)],
    local: t - shot.start,
    progress: clamp((t - shot.start) / (shot.end - shot.start)),
    transition: index ? ease((t - shot.start) / 0.72) : 1,
    monochrome: monochromeAt(t),
  };
}
