import React, { useEffect, useState } from "react";
import {
  AbsoluteFill,
  Audio,
  Img,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
  delayRender,
  continueRender,
} from "remotion";
import { HopeV2Project, clamp, ease, getShotState, shotEnvironment } from "./model";
import { WorldStack } from "./World";
import { Weather, LightRig, FilmGrain } from "./Atmosphere";
import { V2Lyrics } from "./Lyrics";
export const HopeV2Film: React.FC<{ project: HopeV2Project }> = ({
  project: p,
}) => {
  const f = useCurrentFrame(),
    { fps, width, height } = useVideoConfig(),
    t = f / fps;
  const state = getShotState(p, t),
    { shot, monochrome } = state;
  const [fontHandle] = useState(() => delayRender("V2 cinematic fonts"));
  useEffect(() => {
    Promise.all([
      document.fonts.load("16px HopeV2Display"),
      document.fonts.load("500 16px HopeV2Verse"),
    ])
      .then(() => continueRender(fontHandle))
      .catch(() => continueRender(fontHandle));
  }, [fontHandle]);
  const line = p.lines.find((l) => t >= l.start && t < l.end);
  const energy = p.analysis.energy[Math.floor(t * 20)] || 0;
  const bass = p.analysis.bass?.[Math.floor(t * 20)] || energy;
  let hitTime = -10,
    hitStrength = 0;
  for (const hit of p.analysis.impacts || []) {
    if (hit.time > t) break;
    hitTime = hit.time;
    hitStrength = hit.strength;
  }
  const impact = Math.exp(-(t - hitTime) * 14) * hitStrength * p.intensity;
  const title = t < 8.8 || t >= 163;
  const opening = t < 8.8;
  const titleAlpha = opening
    ? ease((t - 0.5) / 1.2) * clamp((8.8 - t) / 0.85)
    : ease((t - 163) / 1.2) * clamp((p.duration - t) / 1.4);
  return (
    <AbsoluteFill
      style={{
        background: "#060a0e",
        color: "#eeede7",
        overflow: "hidden",
        fontFamily: "HopeV2Verse,sans-serif",
      }}
    >
      <style>{`@font-face{font-family:HopeV2Display;src:url('${staticFile("fonts/Anton.ttf")}')}@font-face{font-family:HopeV2Verse;src:url('${staticFile("fonts/Oswald.ttf")}');font-weight:200 700}`}</style>
      <Audio src={p.audio} />
      <WorldStack project={p} time={t} bass={bass} impact={impact} />
      <LightRig
        time={t}
        bass={bass}
        impact={impact}
        energy={energy}
        level={shot.level}
        mono={monochrome}
        world={shotEnvironment(shot)}
      />
      <Weather time={t} world={shotEnvironment(shot)} energy={energy} mono={monochrome} />
      {!title && p.branding && (
        <div
          style={{
            position: "absolute",
            left: "7%",
            top: "6.4%",
            fontSize: width * 0.008,
            letterSpacing: width * 0.0025,
            opacity: 0.42,
          }}
        >
          {p.artist}
        </div>
      )}
      {line && (
        <V2Lyrics
          line={line}
          shot={shot}
          time={t}
          width={width}
          height={height}
          bass={bass}
          impact={impact}
          mono={monochrome}
        />
      )}
      {title && (
        <div
          data-title={opening ? "opening" : "closing"}
          style={{
            position: "absolute",
            left: opening ? "37%" : "30%",
            width: opening ? "57%" : "64%",
            top: opening ? "17%" : "22%",
            opacity: titleAlpha,
            transform: `translateY(${(1 - ease((opening ? t - 0.5 : t - 163) / 1.3)) * 18}px) scale(${0.99 + ease((opening ? t - 0.5 : t - 163) / 5) * 0.015})`,
            clipPath: `inset(0 ${(1 - ease((opening ? t - 0.5 : t - 163) / 1.5)) * 100}% 0 0)`,
          }}
        >
          <Img
            src={staticFile(opening ? p.v2.titleOpen : p.v2.titleClose)}
            style={{
              width: "100%",
              height: "auto",
              filter: "drop-shadow(0 5px 14px #0009)",
            }}
          />
          <div
            style={{
              fontSize: width * 0.008,
              letterSpacing: width * 0.003,
              opacity: 0.65,
              textAlign: "center",
              marginTop: -height * 0.01,
            }}
          >
            SEPTEMBER 22, 2024
          </div>
        </div>
      )}
      <AbsoluteFill
        style={{
          background:
            "radial-gradient(ellipse,transparent 45%,rgba(2,5,8,.28))",
          pointerEvents: "none",
        }}
      />
      <FilmGrain frame={f} />
      <AbsoluteFill
        style={{
          background: "#04070b",
          opacity: 1 - Math.min(clamp(t / 0.6), clamp((p.duration - t) / 1.4)),
          pointerEvents: "none",
        }}
      />
    </AbsoluteFill>
  );
};
