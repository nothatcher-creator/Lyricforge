import React from "react";
import type { Line } from "../model";
import { clamp, ease, V2Shot } from "./model";
export function V2Lyrics({
  line,
  shot,
  time: t,
  width,
  height,
  bass,
  impact,
  mono,
}: {
  line: Line;
  shot: V2Shot;
  time: number;
  width: number;
  height: number;
  bass: number;
  impact: number;
  mono: number;
}) {
  const local = t - line.start;
  const fade = Math.min(ease(local / 0.18), clamp((line.end - t) / 0.16));
  const side = shot.placement === "right" || shot.placement === "wall";
  const level = shot.level;
  const hero = level > 0 && line.words.length <= 4;
  const accent = mono > 0.5 ? "#e2e5e5" : level ? "#e8b77d" : "#c6d6db";
  const fontSize = hero
    ? width * (side ? 0.085 : 0.105) + level * width * (side ? 0.006 : 0.008)
    : width *
      (side
        ? line.text.length > 38
          ? 0.032
          : 0.037
        : line.text.length > 42
          ? 0.042
          : 0.05);
  const baseTransform =
    shot.placement === "wall"
      ? "perspective(1300px) rotateY(-15deg) rotateZ(-1.6deg)"
      : shot.placement === "floor"
        ? "perspective(1400px) rotateX(9deg)"
        : shot.placement === "fog"
          ? "perspective(1500px) translateZ(12px)"
          : "";
  const words = (reflection = false) => (
    <div
      style={{
        display: "flex",
        flexWrap: "wrap",
        justifyContent: "center",
        gap: "0 .26em",
        lineHeight: 1.28,
        fontFamily: hero ? "HopeV2Display" : "HopeV2Verse",
        fontWeight: 500,
        fontSize: hero ? width * 0.029 : fontSize,
        letterSpacing: hero ? width * 0.002 : width * 0.0007,
        textAlign: "center",
      }}
    >
      {line.words.map((w, i) => {
        const last = hero && i === line.words.length - 1;
        return (
          <span
            {...(!reflection ? { "data-word": true } : {})}
            key={i}
            style={{
              display: "inline-block",
              ...(last
                ? {
                    flexBasis: "100%",
                    fontSize,
                    lineHeight: 1.15,
                    color: accent,
                    letterSpacing: width * 0.001,
                  }
                : {}),
              color: last
                ? accent
                : t >= w.start && t < w.end
                  ? accent
                  : "#eeede7",
              opacity: 0.5 + 0.5 * ease((local - i * 0.025) / 0.3),
              transform: reflection
                ? "none"
                : `translateY(${(1 - ease((local - i * 0.025) / 0.3)) * 14}px)`,
              textShadow: reflection
                ? "none"
                : shot.placement === "wall"
                  ? "0 0 10px #d5dfd84d,0 2px 3px #0009"
                  : "0 3px 20px #000a",
            }}
          >
            {w.text.toUpperCase()}
          </span>
        );
      })}
    </div>
  );
  return (
    <>
      <div
        data-lyric={line.id}
        data-placement={shot.placement}
        style={{
          position: "absolute",
          left: side ? "42%" : "11%",
          width: side ? "47%" : "78%",
          top: hero ? "47%" : shot.placement === "floor" ? "44%" : "47%",
          opacity: fade,
          transform: `translateY(-50%) ${baseTransform} scale(${1 + bass * (0.003 + level * 0.0035) + impact * level * 0.003})`,
          transformOrigin: "center center",
          mixBlendMode: shot.placement === "wall" ? "screen" : "normal",
        }}
      >
        {words()}
      </div>
      {shot.placement === "floor" && (
        <div
          aria-hidden
          style={{
            position: "absolute",
            left: "12%",
            width: "76%",
            top: "63%",
            opacity: fade * 0.16,
            transform: `perspective(1100px) rotateX(46deg) skewX(-12deg) scaleY(-.75) translateX(${Math.sin(t * 1.8) * 2}px)`,
            filter: "blur(.7px)",
            maskImage: "linear-gradient(transparent,black 25%,transparent 95%)",
          }}
        >
          {words(true)}
        </div>
      )}
      {shot.placement === "fog" && (
        <div
          aria-hidden
          style={{
            position: "absolute",
            left: "10%",
            width: "80%",
            top: "48%",
            opacity: fade * 0.055,
            transform: "translateY(-50%) scale(1.04)",
            filter: "blur(4px)",
          }}
        >
          {words(true)}
        </div>
      )}
    </>
  );
}
