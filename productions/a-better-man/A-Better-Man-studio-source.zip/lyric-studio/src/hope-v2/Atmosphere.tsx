import React, { useLayoutEffect, useRef } from "react";
import { AbsoluteFill } from "remotion";
import { clamp } from "./model";
const r = (n: number) => {
  const x = Math.sin(n * 127.1 + 331.3) * 43758.5453;
  return x - Math.floor(x);
};
export function Weather({
  time,
  world,
  energy,
  mono,
}: {
  time: number;
  world: string;
  energy: number;
  mono: number;
}) {
  const rain = world === "coast";
  return (
    <svg
      viewBox="0 0 1920 1080"
      preserveAspectRatio="none"
      style={{
        position: "absolute",
        width: "100%",
        height: "100%",
        opacity: 0.3 + energy * 0.15,
        pointerEvents: "none",
      }}
    >
      <defs>
        <radialGradient id="v2-fog">
          <stop stopColor="#bec8cc" stopOpacity=".16" />
          <stop offset="1" stopColor="#a6b6c0" stopOpacity="0" />
        </radialGradient>
      </defs>
      {[0, 1, 2].map((i) => (
        <ellipse
          key={`fog${i}`}
          cx={((time * (12 + i * 3) + i * 690) % 2600) - 300}
          cy={(rain ? 190 : 720) + i * 80 + Math.sin(time * 0.1 + i) * 35}
          rx={620 + i * 70}
          ry={120 + i * 30}
          fill="url(#v2-fog)"
        />
      ))}
      {Array.from({ length: rain ? 70 : 48 }, (_, i) => {
        const x = ((r(i) * 2200 + Math.sin(time * 0.12 + i) * 12) % 2200) - 100;
        const y =
          ((((r(i + 81) * 1400 + time * (rain ? 220 : -18) * (1 + r(i + 6))) %
            1400) +
            1400) %
            1400) -
          150;
        return rain ? (
          <line
            key={i}
            x1={x}
            y1={y}
            x2={x - 14}
            y2={y + 45 + r(i + 8) * 30}
            stroke="#b4cbd3"
            strokeWidth={0.5 + r(i + 3)}
            opacity={0.12 + r(i + 6) * 0.25}
          />
        ) : (
          <circle
            key={i}
            cx={x + Math.sin(time * 0.4 + i) * 18}
            cy={y}
            r={0.7 + r(i + 18) * 2.2}
            fill={mono > 0.5 ? "#cdd1d3" : "#d5b18c"}
            opacity={0.15 + r(i + 32) * 0.4}
          />
        );
      })}
    </svg>
  );
}
export function LightRig({
  time,
  bass,
  impact,
  energy,
  level,
  mono,
  world,
}: {
  time: number;
  bass: number;
  impact: number;
  energy: number;
  level: number;
  mono: number;
  world: string;
}) {
  const color = mono > 0.5 ? "205,216,224" : "242,184,112";
  const x = world === "coast" ? 86 : world === "cathedral" ? 36 : 75;
  return (
    <>
      <AbsoluteFill
        style={{
          background: `radial-gradient(ellipse at ${x}% ${42 + Math.sin(time * 0.14) * 5}%,rgba(${color},${0.025 + level * 0.013 + bass * 0.045}),transparent ${40 + level * 4}%)`,
          mixBlendMode: "screen",
        }}
      />
      <svg
        viewBox="0 0 1920 1080"
        preserveAspectRatio="none"
        style={{
          position: "absolute",
          width: "100%",
          height: "100%",
          opacity: 0.13 + level * 0.025 + energy * 0.035,
        }}
      >
        <defs>
          <linearGradient id="v2-ray">
            <stop stopColor={`rgb(${color})`} stopOpacity="0" />
            <stop offset=".5" stopColor={`rgb(${color})`} stopOpacity=".3" />
            <stop offset="1" stopColor={`rgb(${color})`} stopOpacity="0" />
          </linearGradient>
        </defs>
        {Array.from({ length: 4 }, (_, i) => (
          <path
            key={i}
            d={`M${(x / 100) * 1920 - 200 + i * 95} -100 L${400 + i * 360 + Math.sin(time * 0.07) * 70} 1150 L${680 + i * 360 + level * 30} 1150Z`}
            fill="url(#v2-ray)"
          />
        ))}
      </svg>
      <AbsoluteFill
        style={{
          background: `linear-gradient(${105 + Math.sin(time * 0.2) * 12}deg,transparent 25%,rgba(${color},${impact * (0.018 + level * 0.012)}) 48%,transparent 70%)`,
          mixBlendMode: "screen",
        }}
      />
      <div
        style={{
          position: "absolute",
          left: 0,
          top: "14%",
          bottom: "14%",
          width: "1.5%",
          background: `rgba(${color},${impact * 0.085})`,
          filter: "blur(14px)",
          opacity: 0.5,
        }}
      />
      <div
        style={{
          position: "absolute",
          right: 0,
          top: "20%",
          bottom: "10%",
          width: "2%",
          background: `rgba(${color},${impact * 0.1})`,
          filter: "blur(12px)",
          opacity: 0.5,
        }}
      />
    </>
  );
}
export function FilmGrain({ frame }: { frame: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useLayoutEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const tile = document.createElement("canvas");
    tile.width = 192;
    tile.height = 192;
    const tc = tile.getContext("2d")!;
    const pixels = tc.createImageData(192, 192);
    let seed = (frame * 1664525 + 1013904223) >>> 0;
    for (let i = 0; i < pixels.data.length; i += 4) {
      seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
      const value = seed >>> 24;
      pixels.data[i] = value;
      pixels.data[i + 1] = value;
      pixels.data[i + 2] = value;
      pixels.data[i + 3] = 255;
    }
    tc.putImageData(pixels, 0, 0);
    ctx.clearRect(0, 0, 960, 540);
    const pattern = ctx.createPattern(tile, "repeat");
    if (pattern) {
      ctx.fillStyle = pattern;
      ctx.fillRect(0, 0, 960, 540);
    }
  }, [frame]);
  return (
    <canvas
      ref={ref}
      width={960}
      height={540}
      style={{
        position: "absolute",
        width: "100%",
        height: "100%",
        opacity: 0.045,
        mixBlendMode: "soft-light",
        pointerEvents: "none",
      }}
    />
  );
}
