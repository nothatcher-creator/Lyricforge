import React from "react";
import { AbsoluteFill, Img, staticFile } from "remotion";
import { clamp, ease, HopeV2Project, V2Shot, getShotState } from "./model";
export function WorldStack({
  project: p,
  time: t,
  bass,
  impact,
}: {
  project: HopeV2Project;
  time: number;
  bass: number;
  impact: number;
}) {
  const state = getShotState(p, t),
    { shot, index, previous, local, transition, monochrome } = state;
  const camera = (s: V2Shot, time: number) => {
    const phase = clamp((time - s.start) / (s.end - s.start));
    const dir = s.camera === "pull" ? -1 : 1;
    return {
      scale:
        1.055 +
        (s.camera === "pull" ? 1 - phase : phase) * (0.04 + s.level * 0.012) +
        bass * s.level * 0.0015,
      x:
        (s.camera === "slide"
          ? phase * 2.1 - 1.05
          : Math.sin(time * 0.08) * 0.4) * dir,
      y: Math.cos(time * 0.07) * 0.35,
      rotate: s.level ? Math.sin(time * 0.13) * (0.04 + s.level * 0.04) : 0,
    };
  };
  const plate = (s: V2Shot, opacity: number, offset = 0) => {
    const c = camera(s, t + offset),
      focus = s.focus ? (1 - ease((t - s.start) / 1.1)) * 3.2 : 0;
    return (
      <AbsoluteFill
        key={s.id + offset}
        style={{
          opacity,
          transform: `translate(${c.x}%,${c.y}%) scale(${c.scale}) rotate(${c.rotate}deg)`,
        }}
      >
        {(!s.gradedPlate || monochrome < 1) && <Img
          src={staticFile(s.gradedPlate || s.plate)}
          style={{
            width: "100%",
            height: "100%",
            objectFit: "cover",
            filter: `${s.gradedPlate ? "" : `grayscale(${monochrome}) saturate(.83) contrast(1.055) brightness(${0.78 + s.level * 0.045})`} ${focus > 0.08 ? `blur(${focus}px)` : ""}`,
          }}
        />}
        {s.monoPlate && monochrome > 0 && <Img src={staticFile(s.monoPlate)} style={{position:"absolute",inset:0,width:"100%",height:"100%",objectFit:"cover",opacity:monochrome,filter:focus > .08 ? `blur(${focus}px)` : undefined}} />}
      </AbsoluteFill>
    );
  };
  const transActive = index > 0 && local < 0.72;
  return (
    <>
      {transActive && plate(previous, 1)}
      {plate(shot, transActive ? transition : 1)}
      {transActive && (
        <>
          {plate(shot, (1 - transition) * 0.055, -1 / 24)}
          {plate(shot, (1 - transition) * 0.025, -2 / 24)}
        </>
      )}
      {shot.world === "coast" && (
        <AbsoluteFill
          style={{
            opacity: 0.16,
            clipPath: "inset(58% 0 0 0)",
            maskImage:
              "linear-gradient(transparent 58%,black 75%,transparent 98%)",
            transform: `translate(${Math.sin(t * 0.9) * 0.16}%,${Math.sin(t * 1.4) * 0.2}%) scale(1.06)`,
          }}
        >
          <Img
            src={staticFile(shot.plate)}
            style={{
              width: "100%",
              height: "100%",
              objectFit: "cover",
              filter: `grayscale(${monochrome}) saturate(.7)`,
            }}
          />
        </AbsoluteFill>
      )}
      <AbsoluteFill
        style={{
          background:
            "radial-gradient(ellipse at center,transparent 18%,rgba(3,7,12,.42)),linear-gradient(0deg,rgba(3,7,12,.65),transparent 30%,transparent 72%,rgba(3,7,12,.25))",
        }}
      />
      <AbsoluteFill
        style={{
          transform: `translate(${Math.sin(t * 0.08) * 0.9 - (state.progress - 0.5) * 1.7}%,${Math.cos(t * 0.1) * 0.4}%) scale(1.08)`,
          opacity: shot.world === "artist" ? 0.32 : 0.42,
          pointerEvents: "none",
        }}
      >
        {(!shot.gradedForeground || monochrome < 1) && <Img
          src={staticFile(shot.gradedForeground || shot.foreground)}
          style={{
            width: "100%",
            height: "100%",
            objectFit: "cover",
            filter: shot.gradedForeground ? undefined : `grayscale(${monochrome}) brightness(.75) blur(${shot.focus ? ease(local / 1.1) * 5 : 4}px)`,
          }}
        />}
        {shot.monoForeground && monochrome > 0 && <Img src={staticFile(shot.monoForeground)} style={{position:"absolute",inset:0,width:"100%",height:"100%",objectFit:"cover",opacity:monochrome}} />}
      </AbsoluteFill>
      {transActive && shot.transition === "cloud" && (
        <AbsoluteFill
          style={{
            opacity: Math.sin(Math.PI * clamp(local / 0.72)) * 0.34,
            background:
              "radial-gradient(ellipse at 40% 50%,#8e9da9,transparent 80%)",
            transform: `translateX(${(transition - 0.5) * 45}%) scale(1.5)`,
            filter: "blur(25px)",
          }}
        />
      )}
      {transActive && shot.transition !== "cloud" && (
        <AbsoluteFill
          style={{
            opacity: Math.sin(Math.PI * clamp(local / 0.72)) * 0.95,
            transform:
              shot.transition === "arch"
                ? `translateX(${(transition * 2.4 - 1.2) * 100}%) scale(2.2)`
                : `translateX(${(transition * 3 - 1.5) * 100}%) scale(3.5)`,
            filter: `blur(${Math.sin(Math.PI * transition) * 3}px)`,
            pointerEvents: "none",
          }}
        >
          <Img
            src={staticFile(shot.foreground)}
            style={{
              width: "100%",
              height: "100%",
              objectFit: "cover",
              filter: "brightness(.42)",
            }}
          />
        </AbsoluteFill>
      )}
    </>
  );
}
