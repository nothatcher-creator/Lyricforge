import React, { useEffect, useState } from "react";
import {
  AbsoluteFill,
  Audio,
  Img,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
  delayRender,
  continueRender,
} from "remotion";
import type { Project } from "./model";
const clamp = (x: number) => Math.max(0, Math.min(1, x));
const ease = (x: number) => 1 - Math.pow(1 - clamp(x), 3);
const rand = (n: number) => {
  const x = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
};
const COL = {
  white: "#f0eee6",
  amber: "#efba78",
  blue: "#a8c5d0",
  rust: "#ce8e7e",
};
export const HopeFilm: React.FC<{ project: Project }> = ({ project: p }) => {
  const frame = useCurrentFrame(),
    { fps, width, height } = useVideoConfig(),
    t = frame / fps;
  const [handle] = useState(() => delayRender("Load song typography"));
  useEffect(() => {
    Promise.all([
      document.fonts.load("16px HopeDisplay"),
      document.fonts.load("500 16px HopeVerse"),
    ])
      .then(() => continueRender(handle))
      .catch(() => continueRender(handle));
  }, [handle]);
  const si = Math.max(
      0,
      p.scenes.findIndex((s) => t >= s.start && t < s.end),
    ),
    scene = p.scenes[si],
    previous = p.scenes[Math.max(0, si - 1)];
  const line = p.lines.find((l) => t >= l.start && t < l.end),
    local = t - scene.start;
  const energy = p.analysis.energy[Math.floor(t * 20)] || 0,
    bass = p.analysis.bass?.[Math.floor(t * 20)] ?? energy;
  let nearest = -10;
  for (const b of p.analysis.beats) {
    if (b > t) break;
    nearest = b;
  }
  let impact = -10,
    strength = 0;
  for (const hit of p.analysis.impacts || []) {
    if (hit.time > t) break;
    impact = hit.time;
    strength = hit.strength;
  }
  const beatPulse = Math.exp(-(t - nearest) * 11) * bass * p.intensity;
  const hitPulse = Math.exp(-(t - impact) * 17) * strength * p.intensity;
  const chorus =
    scene.label.toLowerCase().includes("hook") ||
    scene.label.toLowerCase().includes("refrain");
  const bridge = scene.label === "Starving" || scene.label === "Starved";
  const accent = bridge
    ? COL.rust
    : si >= 8
      ? COL.amber
      : chorus
        ? COL.amber
        : COL.blue;
  const phraseTime = line ? t - line.start : 0,
    fade = line
      ? Math.min(ease(phraseTime / 0.18), clamp((line.end - t) / 0.16))
      : 0;
  const background = (environment: string, index: number, opacity: number) => {
    const duration = p.scenes[index].end - p.scenes[index].start;
    const offset = clamp((t - p.scenes[index].start) / duration);
    return (
      <AbsoluteFill
        key={index}
        style={{
          opacity,
          transform: `scale(${1.06 + offset * 0.075 + hitPulse * 0.003}) translate(${Math.sin(t * 0.09) * 0.6 + (index % 2 ? 1 : -1) * offset * 0.9}%,${Math.cos(t * 0.07) * 0.5}%) rotate(${chorus ? Math.sin(t * 0.13) * 0.18 : 0}deg)`,
        }}
      >
        <Img
          src={staticFile(`hope/${environment}.png`)}
          style={{ width: "100%", height: "100%", objectFit: "cover" }}
        />
      </AbsoluteFill>
    );
  };
  const mix = si ? ease(local / 0.8) : 1;
  return (
    <AbsoluteFill
      style={{
        background: "#070b10",
        color: COL.white,
        overflow: "hidden",
        fontFamily: "HopeVerse,sans-serif",
      }}
    >
      <style>{`@font-face{font-family:HopeDisplay;src:url('${staticFile("fonts/Anton.ttf")}')}@font-face{font-family:HopeVerse;src:url('${staticFile("fonts/Oswald.ttf")}');font-weight:200 700}`}</style>
      <Audio src={p.audio} />
      {si > 0 && background(previous.environment, si - 1, 1 - mix)}
      {background(scene.environment, si, mix)}
      <AbsoluteFill
        style={{
          background: `radial-gradient(ellipse at 50% 48%,rgba(5,10,15,${chorus ? 0.12 : 0.34}),transparent 80%),linear-gradient(0deg,rgba(3,7,12,.86),transparent 33%,transparent 65%,rgba(3,7,12,.5))`,
        }}
      />
      <AbsoluteFill
        style={{ background: bridge ? "rgba(7,9,15,.28)" : "transparent" }}
      />
      <svg
        viewBox="0 0 1920 1080"
        preserveAspectRatio="none"
        style={{
          position: "absolute",
          width: "100%",
          height: "100%",
          opacity: 0.2 + energy * 0.16,
        }}
      >
        {Array.from({ length: 42 }, (_, i) => {
          const x = rand(i) * 1920,
            y =
              ((((rand(i + 72) * 1400 +
                t *
                  (scene.environment === "coast" ? 95 : -12) *
                  (1 + rand(i + 4))) %
                1400) +
                1400) %
                1400) -
              160;
          return scene.environment === "coast" ? (
            <line
              key={i}
              x1={x}
              y1={y}
              x2={x - 9}
              y2={y + 32}
              stroke={COL.blue}
              strokeWidth="1"
              opacity={0.1 + rand(i + 10) * 0.25}
            />
          ) : (
            <circle
              key={i}
              cx={x + Math.sin(t * 0.3 + i) * 12}
              cy={y}
              r={1 + rand(i + 91) * 2}
              fill={accent}
              opacity={0.12 + rand(i + 12) * 0.5}
            />
          );
        })}
      </svg>
      {chorus && (
        <AbsoluteFill
          style={{
            background: `radial-gradient(ellipse at 60% 70%,rgba(230,162,78,${0.015 + beatPulse * 0.04}),transparent 65%)`,
          }}
        />
      )}
      <div
        style={{
          position: "absolute",
          left: "7%",
          right: "7%",
          top: "6.5%",
          display: "flex",
          justifyContent: "space-between",
          fontSize: width * 0.008,
          letterSpacing: width * 0.002,
          color: COL.white,
          opacity: 0.6,
        }}
      >
        <span>{p.branding ? p.artist : ""}</span>
        <span>{String(si + 1).padStart(2, "0")} / HUNGRY FOR HOPE</span>
      </div>
      {line && (
        <AbsoluteFill
          style={{
            alignItems: "center",
            justifyContent: "center",
            padding: "15% 10%",
            opacity: fade,
            transform: `translate(${chorus ? Math.sin(frame * 2.1) * hitPulse * width * 0.0007 : 0}px,${chorus ? Math.cos(frame * 2.3) * hitPulse * height * 0.0008 : 0}px)`,
          }}
        >
          {chorus && line.words.length <= 4 ? (
            <div
              data-lyric={line.id}
              style={{
                textAlign: "center",
                width: "100%",
                transform: `scale(${1 + beatPulse * 0.018 + hitPulse * 0.022})`,
              }}
            >
              <div
                style={{
                  display: "flex",
                  gap: ".3em",
                  justifyContent: "center",
                  fontSize: width * 0.035,
                  letterSpacing: width * 0.006,
                  marginBottom: height * 0.015,
                  opacity: 0.85,
                }}
              >
                {line.words.slice(0, -1).map((w, i) => (
                  <span
                    data-word
                    key={i}
                    style={{
                      display: "inline-block",
                      opacity: t >= w.start ? 1 : 0.4,
                      transform: `translateY(${(1 - ease((phraseTime - i * 0.06) / 0.35)) * 18}px)`,
                    }}
                  >
                    {w.text.toUpperCase()}
                  </span>
                ))}
              </div>
              <div
                style={{
                  position: "relative",
                  fontFamily: "HopeDisplay",
                  fontSize: Math.min(
                    width * 0.163,
                    ((width * 0.72) /
                      Math.max(3, line.words.at(-1)!.text.length)) *
                      1.3,
                  ),
                  lineHeight: 1.13,
                  letterSpacing: width * 0.001,
                }}
              >
                <div
                  aria-hidden
                  style={{
                    position: "absolute",
                    inset: 0,
                    color: "transparent",
                    WebkitTextStroke: `${width * 0.0007}px ${accent}`,
                    opacity: 0.11,
                    transform: `translate(${width * 0.008}px,${height * 0.012}px) scale(1.04)`,
                  }}
                >
                  {line.words.at(-1)!.text.toUpperCase()}
                </div>
                <span
                  data-word
                  style={{
                    display: "inline-block",
                    color: accent,
                    opacity:
                      0.25 + 0.75 * ease((t - line.words.at(-1)!.start) / 0.14),
                    transform: `translateY(${(1 - ease((t - line.words.at(-1)!.start) / 0.22)) * height * 0.025}px) scale(${1 + (1 - ease((t - line.words.at(-1)!.start) / 0.22)) * 0.06})`,
                    textShadow: "0 5px 35px #0008",
                  }}
                >
                  {line.words.at(-1)!.text.toUpperCase()}
                </span>
              </div>
            </div>
          ) : (
            <div
              data-lyric={line.id}
              style={{
                maxWidth: "100%",
                display: "flex",
                flexWrap: "wrap",
                gap: "0 .27em",
                justifyContent: "center",
                fontFamily: bridge ? "HopeDisplay" : "HopeVerse",
                fontWeight: 500,
                fontSize: width * (line.text.length > 39 ? 0.047 : 0.057),
                lineHeight: 1.32,
                letterSpacing: width * (bridge ? 0.002 : 0.0006),
                textAlign: "center",
                textShadow: "0 4px 25px #000c",
                transform: `scale(${1 + beatPulse * (bridge ? 0.006 : 0.009)})`,
              }}
            >
              {line.words.map((w, i) => {
                const active = t >= w.start - 0.03 && t < w.end,
                  entry = ease((phraseTime - i * 0.035) / 0.32),
                  exit = clamp((line.end - t) / 0.18);
                return (
                  <span
                    data-word
                    key={i}
                    style={{
                      display: "inline-block",
                      color: active ? accent : COL.white,
                      opacity: 0.18 + 0.82 * entry,
                      transform: `translateY(${(1 - entry) * 24 + (1 - exit) * (i % 2 ? 12 : -12)}px) scale(${1 + (active ? hitPulse * 0.025 : 0)})`,
                      clipPath: `inset(${(1 - entry) * 100}% 0 0 0)`,
                    }}
                  >
                    {w.text.toUpperCase()}
                  </span>
                );
              })}
            </div>
          )}
          <div
            style={{
              height: 2,
              background: accent,
              width: width * (chorus ? 0.1 : 0.04),
              opacity: 0.65,
              marginTop: height * 0.045,
              transform: `scaleX(${0.7 + beatPulse * 0.3})`,
            }}
          />
        </AbsoluteFill>
      )}
      {!line && (t < 9 || t > 163) && (
        <AbsoluteFill
          style={{
            justifyContent: "center",
            alignItems: "center",
            opacity: Math.min(
              ease((t < 9 ? t - 0.5 : t - 163) / 1),
              clamp((t < 9 ? 8.8 - t : p.duration - t) / 1.3),
            ),
            textAlign: "center",
          }}
        >
          <div
            style={{
              fontSize: width * 0.015,
              letterSpacing: width * 0.006,
              marginBottom: height * 0.025,
            }}
          >
            {p.artist}
          </div>
          <div
            style={{
              fontFamily: "HopeDisplay",
              fontSize: width * 0.122,
              lineHeight: 1.05,
              letterSpacing: width * 0.003,
              textShadow: "0 8px 40px #0008",
            }}
          >
            HUNGRY
            <br />
            <span style={{ color: COL.amber }}>FOR HOPE</span>
          </div>
          <div
            style={{
              fontSize: width * 0.009,
              letterSpacing: width * 0.003,
              marginTop: height * 0.045,
              opacity: 0.6,
            }}
          >
            SEPTEMBER 22, 2024
          </div>
        </AbsoluteFill>
      )}
      <div
        style={{
          position: "absolute",
          left: "7%",
          right: "7%",
          bottom: "7%",
          display: "flex",
          alignItems: "center",
          gap: width * 0.015,
          color: accent,
          opacity: 0.35,
        }}
      >
        <span style={{ fontSize: width * 0.0075, letterSpacing: 3 }}>
          {bridge ? "FRACTURE" : chorus ? "PERSISTENCE" : "AFTER THE SUNSET"}
        </span>
        <div style={{ height: 1, background: accent, flex: 1, opacity: 0.3 }} />
        <svg width={width * 0.13} height={height * 0.025} viewBox="0 0 240 24">
          <path
            d={Array.from({ length: 80 }, (_, i) => {
              const sample =
                p.analysis.waveform[
                  Math.max(
                    0,
                    Math.min(
                      p.analysis.waveform.length - 1,
                      Math.floor(t * 20) + i - 40,
                    ),
                  )
                ] || 0;
              return `${i ? "L" : "M"}${i * 3} ${12 + Math.sin(i * 2.3) * sample * 10}`;
            }).join(" ")}
            fill="none"
            stroke={accent}
            strokeWidth="1"
          />
        </svg>
      </div>
      <AbsoluteFill
        style={{
          background: "#05080c",
          opacity: 1 - Math.min(clamp(t / 0.65), clamp((p.duration - t) / 1.6)),
          pointerEvents: "none",
        }}
      />
    </AbsoluteFill>
  );
};
