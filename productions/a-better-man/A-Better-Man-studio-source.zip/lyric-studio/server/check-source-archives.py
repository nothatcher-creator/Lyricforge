import zipfile,tempfile,subprocess,json,sys
from pathlib import Path
names=sys.argv[1:] or ['Hungry-For-Hope-V2','A-Better-Man']
report=Path('exports/source-archive-check.json')
results=[r for r in json.loads(report.read_text()) if r['archive'].replace('-studio-source.zip','') not in names] if report.exists() else []
for name in names:
 file=Path('exports')/(name+'-studio-source.zip')
 with zipfile.ZipFile(file) as z:
  assert z.testzip() is None
  with tempfile.TemporaryDirectory(prefix='lyric-source-check-') as temp:
   z.extractall(temp)
   if name=='A-Better-Man':
    with zipfile.ZipFile('exports/A-Better-Man-assets.zip') as assets:
     assert assets.testzip() is None
     assets.extractall(temp)
   root=Path(temp)/'lyric-studio';(root/'node_modules').symlink_to('/workspace/lyric-studio/node_modules',target_is_directory=True)
   log=Path('projects')/('hope-v2' if name.startswith('Hungry') else 'better-man')/'archive-check.log'
   with log.open('w') as out:
    for cmd in [['npm','run','build'],['npm','test']]:subprocess.run(cmd,cwd=root,stdout=out,stderr=subprocess.STDOUT,check=True)
   results.append({'archive':file.name,'entries':len(z.namelist()),'integrity':'passed','build':'passed','tests':'passed'})
 print(name,'archive builds and tests independently',flush=True)
Path('exports/source-archive-check.json').write_text(json.dumps(results,indent=2))
