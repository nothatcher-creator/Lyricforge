"""Keep the native master; make a GitHub-compatible copy only when needed."""
import subprocess,shutil
from pathlib import Path
master=Path('exports/A-Better-Man-master.mp4');web=Path('exports/A-Better-Man.mp4')
subprocess.run(['python3','server/qc-better-man.py',str(master)],check=True)
if master.stat().st_size<99*1024*1024:shutil.copy2(master,web)
else:
 subprocess.run(['ffmpeg','-v','warning','-i',str(master),'-map','0:v:0','-map','0:a:0','-c:v','libx264','-preset','slow','-threads','2','-b:v','2100k','-maxrate','2400k','-bufsize','4800k','-pix_fmt','yuv420p','-c:a','copy','-movflags','+faststart','-y',str(web)],check=True)
subprocess.run(['python3','server/qc-better-man.py',str(web)],check=True)
print('MASTER AND GITHUB VIDEO VERIFIED')
