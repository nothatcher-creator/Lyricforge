import fs from "node:fs/promises";
import { createBetterProject } from "../src/better-man/model";
import { demo } from "../src/sample";
const p = createBetterProject(
  demo,
  JSON.parse(await fs.readFile("projects/better-man/analysis.json", "utf8")),
  JSON.parse(
    await fs.readFile("projects/better-man/aligned-lines.json", "utf8"),
  ),
  await fs.readFile("projects/better-man/lyrics.txt", "utf8"),
);
p.treatment = await fs.readFile("docs/a-better-man-treatment.md", "utf8");
await fs.writeFile("projects/a-better-man.json", JSON.stringify(p, null, 2));
const ts = (n: number) =>
  new Date(Math.round(n * 1000)).toISOString().slice(11, 23).replace(".", ",");
await fs.writeFile(
  "exports/A-Better-Man.srt",
  p.lines
    .map((l, i) => `${i + 1}\n${ts(l.start)} --> ${ts(l.end)}\n${l.text}\n`)
    .join("\n"),
);
await fs.writeFile(
  "exports/A-Better-Man.qc.json",
  JSON.stringify(
    {
      phrases: p.lines.length,
      words: p.lines.flatMap((l) => l.words).length,
      reviewWords: p.lines.flatMap((l) => l.words).filter((w) => w.review)
        .length,
      notes: [
        "Exact supplied text preserved, including spellings.",
        "Initial whispered phrase has no independent ASR phrase anchor and remains marked for review.",
        "Additional non-supplied ad-libs and backing repetitions are not invented as primary lyric text.",
        "Phrase-constrained CTC with independent ordered Whisper anchors; timings remain estimates.",
        "Generated artist scenes use supplied references. Fatherhood scenes are anonymous fictional imagery.",
      ],
    },
    null,
    2,
  ),
);
console.log(
  p.duration,
  "seconds",
  p.lines.length,
  "phrases",
  p.film.shots.length,
  "shots",
);
