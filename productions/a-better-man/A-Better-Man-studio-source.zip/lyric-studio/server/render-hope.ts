import fs from "node:fs/promises";
import { bundle } from "@remotion/bundler";
import {
  selectComposition,
  renderMedia,
  renderStill,
} from "@remotion/renderer";
import path from "node:path";
import type { Project } from "../src/model";
const p: Project = JSON.parse(
  await fs.readFile("projects/hungry-for-hope.json", "utf8"),
);
const mode = process.argv[2] || "stills";
const patches: Record<string, [number, number]> = {
  "patch-intro": [0, 251],
  "patch-bridge": [2076, 2567],
  "patch-outro": [3912, 4244],
};
const serveUrl = await bundle({
  entryPoint: path.resolve("src/remotion.tsx"),
  publicDir: path.resolve("public"),
});
p.audio = `http://127.0.0.1:3100${p.audio}`;
const inputProps = { project: p };
const composition = await selectComposition({
  serveUrl,
  id: "LyricVideo",
  inputProps,
  browserExecutable: "/usr/bin/chromium",
});
if (mode === "poster") {
  await renderStill({
    serveUrl,
    composition,
    inputProps,
    frame: 4 * p.settings.fps,
    output: "exports/Hungry-For-Hope-poster.png",
    browserExecutable: "/usr/bin/chromium",
  });
} else if (mode === "stills") {
  for (const t of [4, 11, 30, 40.5, 58.5, 70, 90, 103, 116, 140, 155, 168]) {
    await renderStill({
      serveUrl,
      composition,
      inputProps,
      frame: Math.round(t * p.settings.fps),
      output: `exports/hope-${t}.png`,
      browserExecutable: "/usr/bin/chromium",
    });
    console.log("Still", t);
  }
} else {
  let last = -1;
  await renderMedia({
    serveUrl,
    composition,
    inputProps,
    codec: "h264",
    imageFormat: "jpeg",
    jpegQuality: 90,
    crf: 19,
    audioCodec: "aac",
    audioBitrate: "320k",
    pixelFormat: "yuv420p",
    outputLocation: patches[mode]
      ? `exports/hope-${mode}.mp4`
      : mode === "bench"
        ? "exports/hope-bench.mp4"
        : mode === "draft"
          ? "exports/hope-draft.mp4"
          : "exports/Hungry-For-Hope.mp4",
    ...(patches[mode]
      ? { frameRange: patches[mode] }
      : mode === "bench"
        ? { frameRange: [720, 815] as [number, number] }
        : {}),
    scale: mode === "draft" ? 0.5 : 1,
    browserExecutable: "/usr/bin/chromium",
    concurrency: patches[mode] ? 1 : 2,
    x264Preset: "veryfast",
    onProgress: ({ progress, renderedFrames, encodedFrames }) => {
      const n = Math.floor(progress * 100);
      if (n !== last) {
        last = n;
        console.log(
          JSON.stringify({ percent: n, renderedFrames, encodedFrames }),
        );
      }
    },
  });
}
