"""Verify the delivered stream, not just the source project."""
import json,subprocess,hashlib,re
from pathlib import Path
file=Path('exports/Hungry-For-Hope-V2.mp4')
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(file)],text=True))
video=next(x for x in probe['streams'] if x['codec_type']=='video');audio=next(x for x in probe['streams'] if x['codec_type']=='audio')
assert (video['width'],video['height'])==(1920,1080)
assert video['codec_name']=='h264' and audio['codec_name']=='aac'
assert video['avg_frame_rate']=='24/1'
assert abs(float(probe['format']['duration'])-176.84)<.15
assert int(video['nb_frames'])==4245
sync=abs(float(video.get('start_time',0))-float(audio.get('start_time',0)))
assert sync<.05
assert file.stat().st_size < 100*1024*1024, 'GitHub file limit'
layout=json.loads(Path('exports/hope-v2-layout-check.json').read_text())
assert not layout['violations'] and not layout['runtimeErrors']
check=subprocess.run(['ffmpeg','-v','error','-i',str(file),'-f','null','-'],capture_output=True,text=True,check=True)
assert not check.stderr.strip(),check.stderr
stats=subprocess.run(['ffmpeg','-hide_banner','-i',str(file),'-af','astats=metadata=1:reset=0','-vn','-f','null','-'],capture_output=True,text=True,check=True)
peaks=[float(x) for x in re.findall(r'Peak level dB: ([-\d.]+)',stats.stderr)]
assert peaks and max(peaks)<-.5,peaks
black=subprocess.run(['ffmpeg','-hide_banner','-i',str(file),'-vf','scale=320:-1,blackdetect=d=0.25:pix_th=0.02:pic_th=0.98','-an','-f','null','-'],capture_output=True,text=True,check=True)
black_spans=re.findall(r'black_start:([\d.]+) black_end:([\d.]+) black_duration:([\d.]+)',black.stderr)
unexpected=[(float(a),float(b),float(c)) for a,b,c in black_spans if float(a)>1 and float(b)<175]
# Deliberately dark art is not equivalent to missing frames. Record candidates
# rather than claiming a perceptual black-frame classifier.
subprocess.run(['ffmpeg','-v','error','-i',str(file),'-vf','fps=1/14.5,scale=480:270,tile=4x3','-frames:v','1','-y','exports/Hungry-For-Hope-V2-contact-sheet.png'],check=True)
report={'file':file.name,'sizeBytes':file.stat().st_size,'sha256':hashlib.file_digest(file.open('rb'),'sha256').hexdigest(),'duration':float(probe['format']['duration']),'video':{'codec':video['codec_name'],'width':video['width'],'height':video['height'],'fps':video['avg_frame_rate'],'frames':int(video['nb_frames'])},'audio':{'codec':audio['codec_name'],'channels':audio['channels'],'peakDbfs':max(peaks)},'streamStartDifferenceSeconds':sync,'decodeErrors':check.stderr.strip(),'darkFrameCandidates':unexpected,'layoutReport':'hope-v2-layout-check.json','lyricReviewReport':'Hungry-For-Hope-V2.qc.json','limits':'No claim of manually verified word-perfect timing. Low confidence words remain flagged.'}
Path('exports/Hungry-For-Hope-V2.verification.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
