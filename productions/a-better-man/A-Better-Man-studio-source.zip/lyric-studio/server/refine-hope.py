import sys,json,numpy as np
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from ctc_alignment import transcript_tokens,force_align,words_from_path
vocab=json.loads(next(Path.home().glob('.cache/huggingface/hub/models--Xenova--wav2vec2-base-960h/snapshots/*/vocab.json')).read_text())
c=np.load('projects/hope/emissions.npz');emissions=c['emissions'];starts=c['starts']
blocks=[b.splitlines() for b in Path('projects/hope/lyrics.txt').read_text().strip().split('\n\n')]
print([(i,len(b),b[0]) for i,b in enumerate(blocks)])
groups=[('Another',blocks[0],8.5,29.2),('Hook I',blocks[1],29.2,37.65),('Replace I',blocks[2],37.65,53.75),('Hook II',blocks[3],53.75,62.85),('Replace II',blocks[2],63,87.5),('Starving',blocks[4],87.5,95.65),('Refrain',blocks[5],95.65,97.5),('Starved',blocks[6],98.25,106.1),('Replace reprise',blocks[2][3:],106.1,114.75),('Hook III',blocks[7],114.75,123.95),('Becoming',blocks[8],124.1,151.5),('Final Hook',blocks[9],151.5,160.25),('Final Refrain',blocks[10],160.25,163)]
lines=[]
for section,texts,start,end in groups:
 words,tokens,owners=transcript_tokens(' '.join(texts),vocab)
 mask=(starts>=start)&(starts<end);lp=emissions[mask];ss=starts[mask]
 path=force_align(lp,tokens,vocab.get('<pad>',0))
 aligned=words_from_path(lp,path,tokens,owners,words,ss,176.84,min_word_confidence=0,min_mean_confidence=0)
 cursor=0
 for text in texts:
  n=len(text.split());w=aligned[cursor:cursor+n];cursor+=n
  row={'section':section,'text':text,'start':w[0]['start'],'end':w[-1]['end'],'words':w,'addedRepeat':section in ['Replace II','Replace reprise']};lines.append(row)
  print(f"{row['start']:6.2f}–{row['end']:6.2f} {section:16} {text}",flush=True)
Path('projects/hope/aligned-lines-proposed.json').write_text(json.dumps(lines,indent=2))
