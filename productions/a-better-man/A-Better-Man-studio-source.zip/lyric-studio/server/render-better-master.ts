import { betterFonts } from "../src/better-man/fonts";
import fs from "node:fs/promises";
import path from "node:path";
import { renderCacheKey } from "./render-cache";
import { execFileSync } from "node:child_process";
import { bundle } from "@remotion/bundler";
import {
  openBrowser,
  selectComposition,
  renderMedia,
} from "@remotion/renderer";
import { planFrames } from "./chunk-plan";
import type { BetterProject } from "../src/better-man/model";
const source = await fs.readFile("projects/a-better-man.json", "utf8");
const p: BetterProject = JSON.parse(source);
const quality = {
  codec: "h264" as const,
  muted: true,
  crf: 18,
  imageFormat: "jpeg" as const,
  jpegQuality: 90,
  pixelFormat: "yuv420p" as const,
  x264Preset: "veryfast" as const,
};
const sources: Record<string, Uint8Array> = {
  "package-lock.json": await fs.readFile("package-lock.json"),
  "server/render-better-master.ts": await fs.readFile(
    "server/render-better-master.ts",
  ),
  "server/render-cache.ts": await fs.readFile("server/render-cache.ts"),
};
for (const f of (await fs.readdir("src", { recursive: true }))
  .filter((f) => /\.(tsx?|css)$/.test(f))
  .sort())
  sources["src/" + f] = await fs.readFile(path.join("src", f));
const assets = new Set([
  ...Object.values(betterFonts),
  p.film.titleOpen,
  p.film.titleClose,
  ...p.film.shots.flatMap((s) => [s.plate, s.foreground]),
  p.audio.slice(1),
]);
const media: Record<string, Uint8Array> = {};
for (const f of [...assets].sort())
  media[f] = await fs.readFile(path.join("public", f));
const digest = renderCacheKey({
    project: source,
    sources,
    media,
    render: {
      ...quality,
      backend: p.film.renderer || "dom",
      chunkFrames: 1800,
    },
  }),
  folder = path.resolve("exports/.better-man-cache", digest.slice(0, 16));
await fs.mkdir(folder, { recursive: true });
const ranges = planFrames(Math.ceil(p.duration * p.settings.fps), 1800);
const serveUrl = await bundle({
  entryPoint: path.resolve("src/remotion.tsx"),
  publicDir: path.resolve("public"),
});
const browser = await openBrowser("chrome", {
  browserExecutable: "/usr/bin/chromium",
});
const inputProps = {
  project: { ...p, audio: `http://127.0.0.1:3100${p.audio}` },
};
const clips: string[] = [];
try {
  const composition = await selectComposition({
    serveUrl,
    id: "LyricVideo",
    inputProps,
    puppeteerInstance: browser,
  });
  for (let i = 0; i < ranges.length; i++) {
    const [start, end] = ranges[i],
      file = path.join(folder, `${i}.mp4`);
    clips.push(file);
    let ready = false;
    try {
      const q = JSON.parse(
        execFileSync(
          "ffprobe",
          [
            "-v",
            "error",
            "-select_streams",
            "v:0",
            "-show_entries",
            "stream=nb_frames,width,height",
            "-of",
            "json",
            file,
          ],
          { stdio: ["ignore", "pipe", "ignore"], encoding: "utf8" },
        ),
      );
      ready =
        Number(q.streams[0].nb_frames) === end - start + 1 &&
        q.streams[0].width === p.settings.width &&
        q.streams[0].height === p.settings.height;
    } catch {}
    if (ready) {
      console.log(
        JSON.stringify({
          stage: "resume",
          chunk: i + 1,
          total: ranges.length,
          start,
          end,
        }),
        true,
      );
      continue;
    }
    let last = -1;
    await renderMedia({
      serveUrl,
      composition,
      inputProps,
      puppeteerInstance: browser,
      ...quality,
      concurrency: 2,
      frameRange: [start, end],
      outputLocation: file,
      onProgress: ({ progress, renderedFrames }) => {
        const percent = Math.floor(progress * 100);
        if (percent !== last) {
          last = percent;
          console.log(
            JSON.stringify({
              stage: "render",
              chunk: i + 1,
              total: ranges.length,
              percent,
              renderedFrames,
            }),
          );
        }
      },
    });
    await fs.writeFile(
      path.join(folder, "progress.json"),
      JSON.stringify(
        { digest, completed: i + 1, total: ranges.length, ranges },
        null,
        2,
      ),
    );
  }
} finally {
  await browser.close({ silent: true });
}
const list = path.join(folder, "concat.txt");
await fs.writeFile(list, clips.map((f) => `file '${f}'`).join("\n"));
console.log("Muxing continuous original audio once");
execFileSync(
  "ffmpeg",
  [
    "-v",
    "warning",
    "-f",
    "concat",
    "-safe",
    "0",
    "-i",
    list,
    "-i",
    "public" + p.audio,
    "-map",
    "0:v:0",
    "-map",
    "1:a:0",
    "-c:v",
    "copy",
    "-af",
    `atrim=duration=${p.duration},asetpts=PTS-STARTPTS`,
    "-c:a",
    "aac",
    "-b:a",
    "320k",
    "-movflags",
    "+faststart",
    "-y",
    "exports/A-Better-Man-master.mp4",
  ],
  { stdio: "inherit" },
);
console.log("High-quality master complete");
