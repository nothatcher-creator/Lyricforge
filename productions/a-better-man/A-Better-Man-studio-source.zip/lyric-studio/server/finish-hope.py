"""Reuse rendered sections, replace portrait scenes at exact frame boundaries."""
import subprocess,time,json
from pathlib import Path
paths=[('exports/Hungry-For-Hope.mp4',4245),('exports/hope-patch-intro.mp4',252),('exports/hope-patch-bridge.mp4',492),('exports/hope-patch-outro.mp4',333)]
def ready(file,count):
 if not Path(file).exists():return False
 r=subprocess.run(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=nb_frames','-of','json',file],capture_output=True,text=True)
 try:return int(json.loads(r.stdout)['streams'][0]['nb_frames'])==count
 except (ValueError,KeyError,IndexError):return False
while not all(ready(f,n) for f,n in paths):time.sleep(3)
time.sleep(2)
base=Path(paths[0][0]);base.rename('exports/hope-base.mp4')
command=['ffmpeg','-v','warning','-i','exports/hope-base.mp4','-i',paths[1][0],'-i',paths[2][0],'-i',paths[3][0],'-filter_complex','[0:v]split=2[m1][m2];[m1]trim=start_frame=252:end_frame=2076,setpts=PTS-STARTPTS[b1];[m2]trim=start_frame=2568:end_frame=3912,setpts=PTS-STARTPTS[b2];[1:v]setpts=PTS-STARTPTS[intro];[2:v]setpts=PTS-STARTPTS[bridge];[3:v]setpts=PTS-STARTPTS[outro];[intro][b1][bridge][b2][outro]concat=n=5:v=1:a=0[v]','-map','[v]','-map','0:a','-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p','-r','24','-c:a','copy','-movflags','+faststart','-y',str(base)]
subprocess.run(command,check=True)
assert ready(str(base),4245)
subprocess.run(['python3','server/qc-hope.py'],check=True)
print('PORTRAIT FILM COMPLETE AND VERIFIED',flush=True)
