import subprocess,json,numpy as np
from pathlib import Path
sr=16000;hop=320;nfft=1024
raw=subprocess.check_output(['ffmpeg','-v','error','-i','public/media/hungry-for-hope.mp3','-ac','1','-ar',str(sr),'-f','f32le','pipe:1'])
x=np.frombuffer(raw,dtype='<f4');duration=len(x)/sr
frames=np.lib.stride_tricks.sliding_window_view(x,nfft)[::hop];spec=np.abs(np.fft.rfft(frames*np.hanning(nfft),axis=1));freq=np.fft.rfftfreq(nfft,1/sr)
rms=np.sqrt((frames**2).mean(axis=1));bass=np.sqrt((spec[:,(freq>=35)&(freq<180)]**2).mean(axis=1));flux=np.maximum(0,np.diff(np.log1p(spec[:,freq<5000]),axis=0,prepend=0)).mean(axis=1)
def norm(a):return np.minimum(1,a/(np.percentile(a,97)+1e-9))
e=norm(rms);b=norm(bass);onset=norm(flux)
# Tempo autocorrelation, then a phase search and nearby transient snapping.
scores=[]
for lag in range(15,51):
 score=float(np.dot(onset[lag:],onset[:-lag]));scores.append((score,lag))
scores.sort(reverse=True);lag=scores[0][1];period=lag*hop/sr;bpm=60/period
phase=max(range(lag),key=lambda phase:float(onset[phase::lag].sum()))
beats=[]
for center in range(phase,len(onset),lag):
 lo=max(0,center-3);hi=min(len(onset),center+4);i=lo+int(np.argmax(onset[lo:hi]));t=i*hop/sr
 if not beats or t-beats[-1]>.2:beats.append(round(t,3))
# Independent impacts with a refractory interval; these drive the strongest motions.
impacts=[]
for i in range(2,len(onset)-2):
 if onset[i]>.58 and onset[i]>=max(onset[i-2:i+3]) and (not impacts or i*.02-impacts[-1]['time']>.19):impacts.append({'time':round(i*.02,3),'strength':round(float(onset[i]),3)})
# Studio analysis is sampled at 20 Hz; additional bands preserve frame-reactive data.
idx=np.minimum(np.arange(int(np.ceil(duration*20)))*2.5,len(e)-1).astype(int)
analysis={'bpm':round(bpm,2),'beats':beats,'energy':e[idx].tolist(),'bass':b[idx].tolist(),'onset':onset[idx].tolist(),'impacts':impacts,'waveform':norm(np.max(np.abs(frames),axis=1))[idx].tolist(),'peak':float(np.max(np.abs(x))),'method':'16kHz PCM RMS, 35–180Hz bass energy, log spectral flux, autocorrelation tempo estimate, transient-snapped grid; section semantics derived from supplied lyric repetitions.'}
Path('projects/hope/analysis.json').write_text(json.dumps({'duration':duration,'analysis':analysis},indent=2));print(duration,bpm,'impacts',len(impacts),'tempo candidates',[(round(60/(l*.02),2),round(s,1)) for s,l in scores[:5]])
