import os,json,time,sys
os.environ['HF_HUB_DISABLE_XET']='1'
from faster_whisper import WhisperModel
start=time.time()
model=WhisperModel('small.en',device='cpu',compute_type='int8',cpu_threads=1)
segments,info=model.transcribe(sys.argv[1],word_timestamps=True,beam_size=5,vad_filter=False,condition_on_previous_text=False)
result=[]
for segment in segments:
 item={'start':segment.start,'end':segment.end,'text':segment.text,'words':[{'text':w.word.strip(),'start':w.start,'end':w.end,'probability':w.probability} for w in (segment.words or [])]}
 result.append(item)
 print(json.dumps(item),flush=True)
 with open(sys.argv[2],'w') as f:json.dump({'language':info.language,'duration':info.duration,'segments':result},f,indent=2)
print('Elapsed',time.time()-start,flush=True)
