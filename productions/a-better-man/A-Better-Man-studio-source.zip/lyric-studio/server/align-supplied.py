"""Reusable supplied-word CTC pass; retains every literal lyric token for review."""
import sys,os,json
from pathlib import Path
import numpy as np
from ctc_alignment import CpuAligner,decode_audio,transcript_tokens,force_align,words_from_path
os.environ.setdefault('ALIGN_THREADS','1')
audio,lyrics,out=sys.argv[1:4];root=Path(out);root.mkdir(exist_ok=True,parents=True)
a=CpuAligner();a.load();wave=decode_audio(audio);duration=len(wave)/16000
cache=root/'emissions.npz'
if cache.exists():
 c=np.load(cache);emissions,starts=c['emissions'],c['starts']
else:
 print('Extracting acoustic features',flush=True)
 emissions,starts=a.emissions(wave)
 np.savez(cache,emissions=emissions,starts=starts)
texts=[s.strip() for s in Path(lyrics).read_text().splitlines() if s.strip() and not s.startswith('[')]
words,tokens,owners=transcript_tokens(' '.join(texts),a.vocab)
print('Aligning',len(words),'exact supplied words',flush=True)
path=force_align(emissions,tokens,a.vocab.get('<pad>',0))
result=words_from_path(emissions,path,tokens,owners,words,starts,duration,min_word_confidence=0,min_mean_confidence=0)
assert [w['text'] for w in result]==' '.join(texts).split()
(root/'forced-words.json').write_text(json.dumps(result,indent=2))
lines=[];cursor=0
for text in texts:
 count=len(text.split());ww=result[cursor:cursor+count];cursor+=count
 lines.append({'text':text,'start':ww[0]['start'],'end':ww[-1]['end'],'words':ww})
(root/'aligned-lines-initial.json').write_text(json.dumps(lines,indent=2))
print('Complete',duration,'seconds,',len(lines),'phrases',flush=True)
