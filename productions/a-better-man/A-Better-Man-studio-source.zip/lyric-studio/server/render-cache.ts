import { createHash } from "node:crypto";
type Bytes = string | Uint8Array;
export function renderCacheKey(parts: {
  project: string;
  sources: Record<string, Bytes>;
  media: Record<string, Bytes>;
  render: Record<string, string | number | boolean>;
}): string {
  const h = createHash("sha256").update(parts.project);
  for (const [kind, files] of [
    ["source", parts.sources],
    ["media", parts.media],
  ] as const)
    for (const name of Object.keys(files).sort())
      h.update(kind + ":" + name + "\0")
        .update(files[name])
        .update("\0");
  h.update(
    JSON.stringify(
      Object.fromEntries(
        Object.entries(parts.render).sort(([a], [b]) => a.localeCompare(b)),
      ),
    ),
  );
  return h.digest("hex");
}
