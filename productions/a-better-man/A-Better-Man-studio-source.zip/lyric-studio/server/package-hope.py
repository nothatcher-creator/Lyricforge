from pathlib import Path
import zipfile
patterns=['src/*','server/*','docs/*.md','docs/licenses/*','tests/*','public/fonts/*','public/plates/*','public/hope/*.png']
files=[p for pat in patterns for p in Path('.').glob(pat) if p.is_file()]
files += [Path(x) for x in ['.gitignore','package.json','package-lock.json','tsconfig.json','index.html','README.md','public/media/demo.wav','projects/hungry-for-hope.json','projects/four-dollars-seventy-three.json','projects/four-dollars-captions.json','projects/four-dollars-aligned-lines.json','projects/four-dollars-lyrics.txt','projects/four-dollars-analysis.json']]
files += list(Path('projects/hope').glob('*.json')) + [Path('projects/hope/lyrics.txt')]
# The original uploaded tracks and model caches are not redistributed separately.
with zipfile.ZipFile('exports/Hungry-For-Hope-studio-source.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
 for p in files:
  if p.is_file():z.write(p,'lyric-studio/'+str(p))
print(Path('exports/Hungry-For-Hope-studio-source.zip').stat().st_size)
