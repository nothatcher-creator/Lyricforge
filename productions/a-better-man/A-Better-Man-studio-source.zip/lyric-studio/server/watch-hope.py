import time,subprocess,json
from pathlib import Path
output=Path('exports/Hungry-For-Hope.mp4')
while True:
 log=Path('projects/hope/final-render.log').read_text() if Path('projects/hope/final-render.log').exists() else ''
 if output.exists() and '"percent":100' in log:
  check=subprocess.run(['ffprobe','-v','error','-show_entries','format=duration','-of','json',str(output)],capture_output=True,text=True)
  try:
   if check.returncode==0 and abs(float(json.loads(check.stdout)['format']['duration'])-176.84)<.15:break
  except (ValueError,KeyError):pass
 time.sleep(2)
subprocess.run(['python3','server/qc-hope.py'],check=True)
print('FINAL VIDEO VERIFIED',flush=True)
