"""Refine phrase windows with ordered independent speech matches, never replacing text."""
import json,re,difflib
import numpy as np
from pathlib import Path
from ctc_alignment import CpuAligner,transcript_tokens,force_align,words_from_path
root=Path('projects/better-man');a=CpuAligner();a.load()
c=np.load(root/'emissions.npz');e,starts=c['emissions'],c['starts']
lines=json.loads((root/'aligned-lines.json').read_text());sections=json.loads((root/'sections.json').read_text());trans=json.loads((root/'transcript.json').read_text());asr=[w for s in trans['segments'] for w in s['words']]
norm=lambda x:re.sub('[^a-z]','',x.lower())
report=[]
for sec in sections:
 rows=[l for l in lines if l['block']==sec['block']];target=[w for l in rows for w in l['words']];source=[w for w in asr if w['start']>=sec['start']-.3 and w['start']<sec['end']]
 sm=difflib.SequenceMatcher(None,[norm(w['text']) for w in target],[norm(w['text']) for w in source],autojunk=False)
 mapping={i+k:j+k for i,j,n in sm.get_matching_blocks() for k in range(n)}
 windows=[];cursor=0
 for row in rows:
  n=len(row['words']);matches=[(k,source[mapping[cursor+k]]) for k in range(n) if cursor+k in mapping and source[mapping[cursor+k]].get('probability',0)>.35];cursor+=n
  use=len(matches)>=2 and len(matches)/n>=.4
  if use:
   first,last=matches[0],matches[-1]
   lo=max(sec['start'],first[1]['start']-first[0]*.3-.18);hi=min(sec['end'],last[1]['end']+(n-1-last[0])*.3+.2)
  else:lo,hi=max(sec['start'],row['start']-.12),min(sec['end'],row['end']+.15)
  windows.append([row,lo,hi,matches,use])
 for i in range(1,len(windows)):
  prev,cur=windows[i-1],windows[i]
  if prev[2]>cur[1]:boundary=(prev[2]+cur[1])/2;prev[2]=boundary;cur[1]=boundary
 for row,lo,hi,matches,use in windows:
  words,tokens,owners=transcript_tokens(row['text'],a.vocab);mask=(starts>=lo)&(starts<hi)
  path=force_align(e[mask],tokens,a.vocab.get('<pad>',0));ww=words_from_path(e[mask],path,tokens,owners,words,starts[mask],304.88,min_word_confidence=0,min_mean_confidence=0)
  if use and matches[0][0]==0:
   ww[0]['start']=round(min(ww[0]['start'],max(lo,matches[0][1]['start']-.06)),3)
  if use and matches[-1][0]==len(ww)-1:
   ww[-1]['end']=round(max(ww[-1]['end'],min(hi,matches[-1][1]['end'])),3)
  ww[0]['start']=round(max(lo,ww[0]['start']),3)
  ww[-1]['end']=round(min(hi,ww[-1]['end']),3)
  anchors={k:v for k,v in matches}
  for k,w in enumerate(ww):
   v=anchors.get(k)
   agreement=bool(v and v.get('probability',0)>=.7 and abs(w['start']-v['start'])<=.25 and abs(w['end']-v['end'])<=.45)
   w['review']=w['confidence']<.25 and not agreement
   if v:
    w['asrConfidence']=round(v['probability'],4)
    w['boundaryDisagreementSeconds']=round(max(abs(w['start']-v['start']),abs(w['end']-v['end'])),3)
  row.update(start=ww[0]['start'],end=ww[-1]['end'],words=ww)
  report.append({'text':row['text'],'start':row['start'],'end':row['end'],'anchorCoverage':round(len(matches)/len(ww),3),'needsReview':not use or any(w['confidence']<.25 for w in ww),'note':'No independent phrase anchor; supplied wording preserved' if not use else 'CTC constrained by independent ordered speech anchors'})
# The final call has audible backing repetitions; anchor its primary words to
# the first exact ASR sequence rather than the later identical repeat.
for row in lines:
 if row['block']!=18 or not row['text'].startswith(('Now','For')): continue
 target=[norm(w['text']) for w in row['words']]
 source=[w for w in asr if 287.6<=w['start']<297.5]
 for j in range(len(source)-len(target)+1):
  if [norm(w['text']) for w in source[j:j+len(target)]]==target:
   for w,a_word in zip(row['words'],source[j:j+len(target)]):
    w['ctcStart']=w['start'];w['ctcEnd']=w['end']
    w['start']=round(a_word['start'],3);w['end']=round(a_word['end'],3)
    w['asrConfidence']=round(a_word['probability'],4)
    w['boundaryDisagreementSeconds']=round(max(abs(w['ctcStart']-w['start']),abs(w['ctcEnd']-w['end'])),3)
    w['review']=w['confidence']<.25 or w['boundaryDisagreementSeconds']>.3
   row['start']=row['words'][0]['start'];row['end']=row['words'][-1]['end'];break
assert [w['text'] for l in lines for w in l['words']]==(root/'lyrics.txt').read_text().split()
for i,row in enumerate(lines):
 assert row['end']>row['start']
 if i:assert lines[i-1]['end']<=row['start']+.001,(i,lines[i-1],row)
for row,entry in zip(lines,report):
 entry.update(start=row['start'],end=row['end'],needsReview=any(w.get('review',True) for w in row['words']))
 if row['block']==18 and row['text'].startswith(('Now','For')):entry['note']='First exact ordered ASR sequence in final call; raw CTC timing retained in word metadata'
(root/'aligned-lines.json').write_text(json.dumps(lines,indent=2));(root/'alignment-review.json').write_text(json.dumps(report,indent=2))
for i,l in enumerate(lines):print(i,f"{l['start']:.2f}–{l['end']:.2f}",l['text'])
