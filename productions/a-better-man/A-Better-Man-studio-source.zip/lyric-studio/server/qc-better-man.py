"""Actual-file media validation, plus representative frames and editable review data."""
import json,subprocess,hashlib,re,math,sys
from pathlib import Path
file=Path(sys.argv[1] if len(sys.argv)>1 else 'exports/A-Better-Man.mp4')
p=json.loads(Path('projects/a-better-man.json').read_text());prefix='A-Better-Man-master' if 'master' in file.stem else 'A-Better-Man'
q=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(file)],text=True))
v=next(s for s in q['streams'] if s['codec_type']=='video');a=next(s for s in q['streams'] if s['codec_type']=='audio')
assert (v['width'],v['height'])==(1920,1080);assert v['codec_name']=='h264' and a['codec_name']=='aac';assert v['avg_frame_rate']=='24/1'
assert int(v['nb_frames'])==math.ceil(p['duration']*p['settings']['fps'])==7318
assert abs(float(q['format']['duration'])-p['duration'])<.12
sync=abs(float(v.get('start_time',0))-float(a.get('start_time',0)));assert sync<.05
if 'master' not in file.stem:assert file.stat().st_size<100*1024*1024
decode=subprocess.run(['ffmpeg','-v','error','-i',str(file),'-f','null','-'],capture_output=True,text=True,check=True);assert not decode.stderr.strip(),decode.stderr
stats=subprocess.run(['ffmpeg','-hide_banner','-i',str(file),'-af','astats=metadata=1:reset=0','-vn','-f','null','-'],capture_output=True,text=True,check=True)
peaks=[float(x) for x in re.findall(r'Peak level dB: ([-\d.]+)',stats.stderr)];assert peaks and max(peaks)<-.1,peaks
black=subprocess.run(['ffmpeg','-hide_banner','-i',str(file),'-vf','scale=320:-1,blackdetect=d=0.25:pix_th=0.02:pic_th=0.98','-an','-f','null','-'],capture_output=True,text=True,check=True)
dark=[list(map(float,z)) for z in re.findall(r'black_start:([\d.]+) black_end:([\d.]+) black_duration:([\d.]+)',black.stderr)]
layout=json.loads(Path('exports/better-man-layout-check.json').read_text());assert not layout['violations'] and not layout['runtimeErrors']
if 'master' not in file.stem:
 times=[4,24,45,68,88,118,136,164,182,195,211,243,259,277,289,303]
 select='+'.join(f'eq(n,{round(t*24)})' for t in times)
 subprocess.run(['ffmpeg','-v','error','-i',str(file),'-vf',f"select='{select}',scale=480:270,tile=4x4",'-frames:v','1','-y','exports/A-Better-Man-contact-sheet.png'],check=True)
report={'file':file.name,'sizeBytes':file.stat().st_size,'sha256':hashlib.file_digest(file.open('rb'),'sha256').hexdigest(),'duration':float(q['format']['duration']),'video':{'width':v['width'],'height':v['height'],'codec':v['codec_name'],'fps':v['avg_frame_rate'],'frames':int(v['nb_frames'])},'audio':{'codec':a['codec_name'],'channels':a['channels'],'sampleRate':a['sample_rate'],'peakDbfs':max(peaks)},'streamStartDifferenceSeconds':sync,'decodeErrors':decode.stderr.strip(),'darkFrameCandidates':dark,'layoutSamples':layout['samplesChecked'],'timingReview':'A-Better-Man.qc.json; word boundaries remain acoustic estimates, not manually verified word-perfect timing.'}
Path('exports/'+prefix+'.verification.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
