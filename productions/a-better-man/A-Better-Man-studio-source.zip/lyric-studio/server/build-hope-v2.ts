import fs from "node:fs/promises";
import { execFileSync } from "node:child_process";
import { buildV2 } from "../src/hope-v2/model";
const p = buildV2(
  JSON.parse(await fs.readFile("projects/hungry-for-hope.json", "utf8")),
);
p.treatment = await fs.readFile(
  "docs/hungry-for-hope-approved-upgrades.md",
  "utf8",
);
await fs.writeFile(
  "projects/hungry-for-hope-v2.json",
  JSON.stringify(p, null, 2),
);
console.log(
  p.v2.shots.length,
  "shots, original",
  p.lines.length,
  "cues preserved",
);
execFileSync("python3", ["server/cache-hope-v2.py"], {stdio:"inherit"});
