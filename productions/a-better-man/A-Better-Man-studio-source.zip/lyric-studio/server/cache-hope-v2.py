"""Bake static video-grade layers once; original generated artwork is preserved."""
import json,subprocess
from pathlib import Path
p=json.loads(Path('projects/hungry-for-hope-v2.json').read_text())
root=Path('public/hope-v2/cache');root.mkdir(exist_ok=True)
seen=set()
for shot in p['v2']['shots']:
 key=Path(shot['plate']).stem+'-'+str(shot['level'])
 for mono in [False,True]:
  dst=root/(key+('-mono' if mono else '-color')+'.jpg')
  field='monoPlate' if mono else 'gradedPlate'
  shot[field]=str(dst.relative_to('public'))
  if str(dst) not in seen:
   brightness=.78+shot['level']*.045
   vf=f'hue=s={0 if mono else .83},eq=contrast=1.055,colorchannelmixer=rr={brightness}:gg={brightness}:bb={brightness}'
   subprocess.run(['ffmpeg','-v','error','-threads','1','-i','public/'+shot['plate'],'-vf',vf,'-frames:v','1','-q:v','2','-threads','1','-y',str(dst)],check=True)
   seen.add(str(dst))
  fgkey=Path(shot['foreground']).stem
  dst=root/(fgkey+('-mono' if mono else '-color')+'.png')
  shot['monoForeground' if mono else 'gradedForeground']=str(dst.relative_to('public'))
  if str(dst) not in seen:
   vf=f'format=rgba,colorchannelmixer=rr=.75:gg=.75:bb=.75'+(',hue=s=0' if mono else '')+',gblur=sigma=4.5'
   subprocess.run(['ffmpeg','-v','error','-threads','1','-i','public/'+shot['foreground'],'-vf',vf,'-frames:v','1','-threads','1','-y',str(dst)],check=True)
   seen.add(str(dst))
Path('projects/hungry-for-hope-v2.json').write_text(json.dumps(p,indent=2))
print('Cached',len(seen),'static video-grade layers; original artwork unchanged')
