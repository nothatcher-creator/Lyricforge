import fs from "node:fs/promises";
import path from "node:path";
import { bundle } from "@remotion/bundler";
import {
  openBrowser,
  selectComposition,
  renderStill,
  renderMedia,
} from "@remotion/renderer";
import type { HopeV2Project } from "../src/hope-v2/model";
const p: HopeV2Project = JSON.parse(
  await fs.readFile("projects/hungry-for-hope-v2.json", "utf8"),
);
const mode = process.argv[2] || "stills";
const serveUrl = await bundle({
  entryPoint: path.resolve("src/remotion.tsx"),
  publicDir: path.resolve("public"),
});
p.audio = `http://127.0.0.1:3100${p.audio}`;
const browser = await openBrowser("chrome", {
  browserExecutable: process.env.STUDIO_CHROMIUM || "/usr/bin/chromium",
});
const inputProps = { project: p };
try {
  const composition = await selectComposition({
    serveUrl,
    id: "LyricVideo",
    inputProps,
    puppeteerInstance: browser,
  });
  if (mode === "stills" || mode === "poster") {
    const times =
      mode === "poster"
        ? [4]
        : process.env.STUDIO_STILL_TIMES ? process.env.STUDIO_STILL_TIMES.split(",").map(Number) : [
            4, 11, 19.5, 26, 30, 39, 47, 56, 65, 75, 90, 103, 109, 116, 126,
            144, 153, 169,
          ];
    for (const t of times) {
      await renderStill({
        serveUrl,
        composition,
        inputProps,
        puppeteerInstance: browser,
        frame: Math.round(t * p.settings.fps),
        output:
          mode === "poster"
            ? "exports/Hungry-For-Hope-V2-poster.png"
            : `exports/hope-v2-${t}.png`,
      });
      console.log("Still", t);
    }
  } else {
    let last = -1;
    const range =
      mode === "bench" ? { frameRange: [900, 900 + Number(process.env.STUDIO_BENCH_FRAMES || 96) - 1] as [number, number] } : {};
    await renderMedia({
      serveUrl,
      composition,
      inputProps,
      puppeteerInstance: browser,
      codec: "h264",
      audioCodec: "aac",
      audioBitrate: "320k",
      videoBitrate: "3800k",
      encodingMaxRate: "4500k",
      encodingBufferSize: "9000k",
      imageFormat: "jpeg",
      jpegQuality: 86,
      pixelFormat: "yuv420p",
      x264Preset: "veryfast",
      concurrency: 2,
      outputLocation:
        mode === "bench"
          ? "exports/hope-v2-bench.mp4"
          : "exports/Hungry-For-Hope-V2.mp4",
      ...range,
      onProgress: ({ progress, renderedFrames, encodedFrames }) => {
        const percent = Math.floor(progress * 100);
        if (percent !== last) {
          last = percent;
          console.log(
            JSON.stringify({ percent, renderedFrames, encodedFrames }),
          );
        }
      },
    });
  }
} finally {
  await browser.close({ silent: true });
}
