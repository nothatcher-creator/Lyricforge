"""V2 final-file gate, then the authorized next master render."""
import subprocess,time,json,shutil
from pathlib import Path
file=Path('exports/Hungry-For-Hope-V2.mp4')
while True:
 if file.exists():
  r=subprocess.run(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=nb_frames','-of','json',str(file)],capture_output=True,text=True)
  try:
   if int(json.loads(r.stdout)['streams'][0]['nb_frames'])==4245:break
  except (KeyError,ValueError,IndexError):pass
 time.sleep(5)
print('V2 finished; validating actual file',flush=True)
subprocess.run(['python3','server/qc-hope-v2.py'],check=True)
dest=Path('/workspace/v2-delivery/productions/hungry-for-hope-v2')
for name in ['Hungry-For-Hope-V2.mp4','Hungry-For-Hope-V2-contact-sheet.png','Hungry-For-Hope-V2.verification.json']:
 shutil.copy2(Path('exports')/name,dest/name)
Path('projects/hope-v2/render-status.json').write_text(json.dumps({'stage':'verified; GitHub push pending','file':str(file)},indent=2))
print('V2 verified and delivery files staged; starting A Better Man master',flush=True)
with open('projects/better-man/final-render.log','w') as log:
 subprocess.run(['npx','tsx','server/render-better-master.ts'],stdout=log,stderr=subprocess.STDOUT,check=True)
with open('projects/better-man/finish.log','w') as log:
 subprocess.run(['python3','server/finish-better-man.py'],stdout=log,stderr=subprocess.STDOUT,check=True)
print('A Better Man finished and verified',flush=True)
