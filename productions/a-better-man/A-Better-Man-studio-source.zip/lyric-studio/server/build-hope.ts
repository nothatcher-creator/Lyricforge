import fs from "node:fs/promises";
import { demo } from "../src/sample";
import { qc, Project, Line } from "../src/model";
const { duration, analysis } = JSON.parse(
  await fs.readFile("projects/hope/analysis.json", "utf8"),
);
const raw = JSON.parse(
  await fs.readFile("projects/hope/aligned-lines.json", "utf8"),
) as {
  text: string;
  section: string;
  start: number;
  end: number;
  words: { text: string; start: number; end: number; confidence: number }[];
  addedRepeat: boolean;
}[];
const lines: Line[] = raw.map((l, i) => ({
  id: `hope-${i}`,
  text: l.text,
  start: l.start,
  end: l.end,
  preset: /Hook|Refrain/.test(l.section)
    ? "impact"
    : /Starv/.test(l.section)
      ? "drift"
      : "rise",
  words: l.words.map((w) => ({ ...w, review: w.confidence < 0.25 })),
}));
for (let i = 0; i < lines.length; i++)
  lines[i].start = Math.max(
    0,
    lines[i].start - 0.07,
    i ? lines[i - 1].words.at(-1)!.end : 0,
  );
for (let i = 0; i < lines.length; i++)
  lines[i].end = Math.max(
    lines[i].words.at(-1)!.end,
    Math.min(lines[i + 1]?.start ?? duration, lines[i].end + 0.22),
  );
const groups = [...new Set(raw.map((x) => x.section))];
const scenes: Project["scenes"] = [
  {
    id: "hope-intro",
    start: 0,
    end: lines[0].start,
    label: "Introduction",
    environment: "portrait",
    energy: 0.3,
    camera: "drift",
    effects: 0.4,
  },
];
for (let i = 0; i < groups.length; i++) {
  const label = groups[i],
    start = lines[raw.findIndex((x) => x.section === label)].start;
  const next =
    i + 1 < groups.length
      ? lines[raw.findIndex((x) => x.section === groups[i + 1])].start
      : 163;
  const hook = /Hook|Refrain/.test(label);
  scenes.push({
    id: `hope-scene-${i}`,
    start,
    end: next,
    label,
    environment:
      label === "Another"
        ? "coast"
        : label === "Becoming" || label.includes("Final")
          ? "light"
          : ["Starving", "Starved"].includes(label)
            ? "portrait"
            : "cathedral",
    energy: hook ? 0.9 : /Starv/.test(label) ? 0.55 : 0.65,
    camera: hook ? "orbit" : "dolly",
    effects: hook ? 0.8 : 0.5,
  });
}
scenes.push({
  id: "hope-outro",
  start: 163,
  end: duration,
  label: "Resolution",
  environment: "portrait",
  energy: 0.35,
  camera: "drift",
  effects: 0.3,
});
// Impact motion is driven by stronger measured transients, with a refractory interval.
const impacts: { time: number; strength: number }[] = [];
for (const h of analysis.impacts) {
  if (
    h.strength > 0.84 &&
    (!impacts.length || h.time - impacts.at(-1)!.time > 0.34)
  )
    impacts.push(h);
}
analysis.impacts = impacts;
const p: Project = {
  ...structuredClone(demo),
  id: "hungry-for-hope",
  title: "Hungry For Hope",
  artist: "#WEED_SMOK",
  audio: "/media/hungry-for-hope.mp3",
  duration,
  lyrics: await fs.readFile("projects/hope/lyrics.txt", "utf8"),
  lines,
  scenes,
  analysis,
  style: "hope",
  accent: "#efba78",
  intensity: 0.8,
  font: "Oswald",
  branding: true,
  approved: true,
  settings: { width: 1920, height: 1080, fps: 24 },
  treatment: await fs.readFile("docs/hungry-for-hope-treatment.md", "utf8"),
  history: [
    "User confirmed start and full creative control, generated assets and beat-driven typography",
    "Three genuine generated environment images created with image_gen; image plates animate procedurally",
    "Supplied wording retained; repeated Replace verse and reprise reused to cover additional vocal repetitions; clarification offered and default stated",
    "Local Whisper small.en checked against phrase-constrained CTC alignment; uncertain word timestamps retained for review",
    "Both user-reattached portraits incorporated into a generated editorial photographic composite; no invented performance footage",
  ],
};
await fs.writeFile("projects/hungry-for-hope.json", JSON.stringify(p, null, 2));
const captions = lines.flatMap((l) =>
  l.words.map((w) => ({
    text: w.text,
    startMs: Math.round(w.start * 1000),
    endMs: Math.round(w.end * 1000),
    timestampMs: Math.round(w.start * 1000),
    confidence: (w as any).confidence ?? null,
  })),
);
await fs.writeFile(
  "projects/hope/captions.json",
  JSON.stringify(captions, null, 2),
);
function ts(t: number) {
  return new Date(Math.round(t * 1000))
    .toISOString()
    .slice(11, 23)
    .replace(".", ",");
}
await fs.writeFile(
  "exports/Hungry-For-Hope.srt",
  lines
    .map((l, i) => `${i + 1}\n${ts(l.start)} --> ${ts(l.end)}\n${l.text}\n`)
    .join("\n"),
);
await fs.writeFile(
  "exports/Hungry-For-Hope.qc.json",
  JSON.stringify(
    {
      warnings: qc(p),
      phraseCount: lines.length,
      wordCount: captions.length,
      unreviewedWords: lines.flatMap((l) => l.words).filter((w) => w.review)
        .length,
      addedRepetitions: raw
        .filter((l) => l.addedRepeat)
        .map((l) => ({ text: l.text, start: l.start, end: l.end })),
      limits: [
        "Word timings are acoustic estimates, not manually verified frame-perfect singing alignment.",
        "Repeated supplied verse/reprise fills extra vocal repetitions heard by the independent speech pass. No new lyrical wording was invented.",
        "Original reference portraits were unavailable as downloadable attachments. The film uses generated environments and the supplied artist credit.",
        "Tempo is an estimate; strongest motion follows measured transient impacts and bass energy.",
      ],
    },
    null,
    2,
  ),
);
console.log({
  duration,
  bpm: p.analysis.bpm,
  phrases: lines.length,
  words: captions.length,
  impacts: impacts.length,
  warnings: qc(p),
});
