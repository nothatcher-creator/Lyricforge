import sys,json,numpy as np
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from ctc_alignment import transcript_tokens,force_align,words_from_path
vocab=json.loads(next(Path.home().glob('.cache/huggingface/hub/models--Xenova--wav2vec2-base-960h/snapshots/*/vocab.json')).read_text())
c=np.load('projects/hope/emissions.npz');emissions=c['emissions'];starts=c['starts']
lines=json.loads(Path('projects/hope/aligned-lines-proposed.json').read_text())
overrides={
0:(9.1,13.15),1:(13.2,17.5),2:(18.25,20.95),3:(20.95,22.8),4:(22.8,25.1),5:(25.1,28.65),
6:(29,31.15),7:(31.2,33.15),8:(33.3,35.6),9:(35.8,37.65),
10:(37.65,39.75),11:(39.9,41.85),12:(41.85,44.8),13:(44.9,47.95),14:(47.95,50.3),15:(50.3,53.75),
16:(54.2,55.85),17:(56.2,58),18:(58.3,60.45),19:(60.5,62.85),
38:(115.2,116.95),39:(117.2,119.15),40:(119.4,121.65),41:(122.05,123.9)}
# Overrides below are selected by section to avoid positional dependence.
bysection={'Hook III':[(115.2,116.95),(117.2,119.15),(119.4,121.65),(122.05,123.9)]}
positions={}
for i,l in enumerate(lines):
 sec=l['section'];j=positions.get(sec,0);positions[sec]=j+1
 if sec in bysection:bound=bysection[sec][j]
 elif i<20:bound=overrides[i]
 else:continue
 start,end=bound;words,tokens,owners=transcript_tokens(l['text'],vocab)
 mask=(starts>=start)&(starts<end);lp=emissions[mask];ss=starts[mask];path=force_align(lp,tokens,vocab.get('<pad>',0))
 w=words_from_path(lp,path,tokens,owners,words,ss,176.84,min_word_confidence=0,min_mean_confidence=0)
 l.update(start=w[0]['start'],end=w[-1]['end'],words=w)
Path('projects/hope/aligned-lines.json').write_text(json.dumps(lines,indent=2))
for l in lines:print(f"{l['start']:6.2f} {l['end']:6.2f} {l['section']:15} {l['text']}")
