import fs from "node:fs/promises";
import path from "node:path";
import { bundle } from "@remotion/bundler";
import {
  openBrowser,
  selectComposition,
  renderStill,
  renderMedia,
} from "@remotion/renderer";
import type { BetterProject } from "../src/better-man/model";
const p: BetterProject = JSON.parse(
  await fs.readFile("projects/a-better-man.json", "utf8"),
);
const mode = process.argv[2] || "stills";
const serveUrl = await bundle({
  entryPoint: path.resolve("src/remotion.tsx"),
  publicDir: path.resolve("public"),
});
p.audio = `http://127.0.0.1:3100${p.audio}`;
const browser = await openBrowser("chrome", {
  browserExecutable: process.env.STUDIO_CHROMIUM || "/usr/bin/chromium",
});
const inputProps = { project: p };
try {
  const composition = await selectComposition({
    serveUrl,
    id: "LyricVideo",
    inputProps,
    puppeteerInstance: browser,
  });
  if (mode === "stills" || mode === "poster") {
    const times =
      mode === "poster"
        ? [4]
        : process.env.STUDIO_STILL_TIMES ? process.env.STUDIO_STILL_TIMES.split(",").map(Number) : [
            4, 18, 23, 34, 44.5, 61, 68, 78, 89, 105, 118, 136, 152, 164, 174, 182, 195, 201, 211, 230, 243, 249, 258, 270, 284, 289, 300, 303.5,
          ];
    for (const t of times) {
      await renderStill({
        serveUrl,
        composition,
        inputProps,
        puppeteerInstance: browser,
        frame: Math.round(t * p.settings.fps),
        output:
          mode === "poster"
            ? "exports/A-Better-Man-poster.png"
            : `exports/better-man-${t}.png`,
      });
      console.log("Still", t);
    }
  } else {
    let last = -1;
    const range =
      mode === "bench" ? { frameRange: [900, 900 + Number(process.env.STUDIO_BENCH_FRAMES || 96) - 1] as [number, number] } : {};
    await renderMedia({
      serveUrl,
      composition,
      inputProps,
      puppeteerInstance: browser,
      codec: "h264",
      audioCodec: "aac",
      audioBitrate: "320k",
      crf: 18,
      imageFormat: "jpeg",
      jpegQuality: 90,
      pixelFormat: "yuv420p",
      x264Preset: "veryfast",
      concurrency: 2,
      outputLocation:
        mode === "bench"
          ? "exports/better-man-bench.mp4"
          : "exports/A-Better-Man-master.mp4",
      ...range,
      onProgress: ({ progress, renderedFrames, encodedFrames }) => {
        const percent = Math.floor(progress * 100);
        if (percent !== last) {
          last = percent;
          console.log(
            JSON.stringify({ percent, renderedFrames, encodedFrames }),
          );
        }
      },
    });
  }
} finally {
  await browser.close({ silent: true });
}
