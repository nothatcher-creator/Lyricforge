#!/bin/sh
exec /usr/bin/chromium --disable-gpu "$@"
