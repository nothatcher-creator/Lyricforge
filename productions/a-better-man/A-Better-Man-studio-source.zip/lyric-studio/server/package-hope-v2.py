from pathlib import Path
import zipfile
roots=['src','server','docs','tests','public/fonts','public/plates','public/hope','public/hope-v2','projects/hope-v2']
files=[p for root in roots for p in Path(root).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ['.log','.pyc']]
files += list(Path('projects/hope').glob('*.json'))
files += [Path(x) for x in ['.gitignore','package.json','package-lock.json','tsconfig.json','index.html','README.md','public/media/demo.wav','projects/hungry-for-hope-v2.json','projects/hungry-for-hope.json','projects/four-dollars-seventy-three.json','projects/hope/captions.json','projects/hope/lyrics.txt']]
with zipfile.ZipFile('exports/Hungry-For-Hope-V2-studio-source.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
 for p in sorted(set(files)):
  if p.is_file(): z.write(p,'lyric-studio/'+str(p))
print(Path('exports/Hungry-For-Hope-V2-studio-source.zip').stat().st_size)
