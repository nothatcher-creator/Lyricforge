import time,json,subprocess
from pathlib import Path
repo=Path('/workspace/v2-delivery');folder=repo/'productions/hungry-for-hope-v2';report=folder/'Hungry-For-Hope-V2.verification.json'
while not report.exists() or not Path('exports/source-archive-check.json').exists():time.sleep(5)
x=json.loads(report.read_text());readme=folder/'README.md'
with readme.open('a') as f:f.write(f"\nVerified delivery: {x['sizeBytes']:,} bytes; SHA-256 `{x['sha256']}`. Complete stream decode passed; video has {x['video']['frames']:,} frames.\n")
subprocess.run(['git','-C',str(repo),'add','productions/hungry-for-hope-v2'],check=True)
subprocess.run(['git','-C',str(repo),'-c','user.name=Codex','-c','user.email=noreply@openai.com','commit','-m','Add full Hungry For Hope V2 production and editable source'],check=True)
subprocess.run(['git','-C',str(repo),'-c','credential.helper=!gh auth git-credential','push','origin','HEAD:refs/heads/production/hungry-for-hope-v2'],check=True)
print('V2_PUSH_COMPLETE',flush=True)
