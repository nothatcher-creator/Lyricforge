import sys,json,re,os
sys.path.insert(0,str(__import__('pathlib').Path(__file__).resolve().parent))
from ctc_alignment import CpuAligner,decode_audio,transcript_tokens,force_align,words_from_path
os.environ['ALIGN_THREADS']='2'
a=CpuAligner();a.load()
wave=decode_audio('public/media/hungry-for-hope.mp3')
print('Extracting acoustic features',flush=True)
emissions,starts=a.emissions(wave)
import numpy as np
np.savez('projects/hope/emissions.npz',emissions=emissions,starts=starts)
lines=[s for s in open('projects/hope/lyrics.txt').read().splitlines() if s and not s.startswith('[')]
original=' '.join(lines).split()
spoken=' '.join(lines).replace('2023','twenty twenty three')
words,tokens,owners=transcript_tokens(spoken,a.vocab)
print('Aligning',len(words),'words',len(emissions),'frames',flush=True)
path=force_align(emissions,tokens,a.vocab.get('<pad>',0))
result=words_from_path(emissions,path,tokens,owners,words,starts,len(wave)/16000,min_word_confidence=0,min_mean_confidence=0)
assert [w['text'] for w in result]==original
json.dump(result,open('projects/hope/forced-words.json','w'),indent=2)
print('Completed',len(result),flush=True)
