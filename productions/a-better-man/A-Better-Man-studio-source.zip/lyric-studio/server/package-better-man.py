from pathlib import Path
import zipfile
roots=['src','server','docs','tests','public/fonts','public/plates','public/hope','public/hope-v2']
files=[p for root in roots for p in Path(root).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ['.log','.pyc']]
files += [p for p in Path('projects').glob('*.json') if p.is_file() and not p.name.startswith('github-')]
files += [Path(x) for x in ['.gitignore','package.json','package-lock.json','tsconfig.json','index.html','README.md','public/media/demo.wav']]
for root in ['projects/hope','projects/hope-v2','projects/better-man']:
 files += [p for p in Path(root).glob('*') if p.is_file() and p.suffix in ['.json','.md','.txt']]
def write(name,files):
 output=Path('exports')/name;temp=output.with_suffix('.building.zip')
 with zipfile.ZipFile(temp,'w',compression=zipfile.ZIP_DEFLATED) as z:
  for p in sorted(set(files)):
   if p.is_file():z.write(p,'lyric-studio/'+str(p))
 assert temp.stat().st_size<100*1024*1024,temp.stat().st_size
 temp.replace(output);print(output.name,output.stat().st_size,'bytes',flush=True)
write('A-Better-Man-studio-source.zip',files)
write('A-Better-Man-assets.zip',list(Path('public/better-man').glob('*.png'))+[Path('projects/better-man/reference-board.png')])
