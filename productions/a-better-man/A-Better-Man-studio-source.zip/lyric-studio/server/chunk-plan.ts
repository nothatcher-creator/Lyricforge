export function planFrames(
  total: number,
  maxFrames: number,
): [number, number][] {
  if (
    !Number.isInteger(total) ||
    total < 1 ||
    !Number.isInteger(maxFrames) ||
    maxFrames < 1
  )
    throw Error("Frame counts must be positive integers");
  const result: [number, number][] = [];
  for (let start = 0; start < total; start += maxFrames)
    result.push([start, Math.min(total - 1, start + maxFrames - 1)]);
  return result;
}
