"""Section-constrained supplied-lyric alignment from independent vocal anchors."""
import json,sys
import numpy as np
from pathlib import Path
from ctc_alignment import CpuAligner,transcript_tokens,force_align,words_from_path
root=Path('projects/better-man'); a=CpuAligner();a.load()
c=np.load(root/'emissions.npz');e,starts=c['emissions'],c['starts']
blocks=[b.splitlines() for b in (root/'lyrics.txt').read_text().strip().split('\n\n')]
# Vocal block windows checked against the independent Whisper word pass.
bounds=[(18,43.7),(43.7,53.65),(53.65,65.1),(65.1,87.15),(87.15,97.4),(97.4,111),(111,133.8),(133.8,143.65),(143.65,155.2),(159.9,171.3),(171.3,178),(178,189.1),(209.6,220.2),(220.2,235),(240.5,257.7),(257.7,267.8),(267.8,277.5),(277.5,287.7),(287.7,297.5),(297.5,303)]
labels=['Verse 1','Chorus 1A','Chorus 1B','Verse 2','Chorus 2A','Chorus 2B','Verse 3','Chorus 3A','Chorus 3B','Bridge A','Bridge declaration','Bridge B','Chorus 4A','Chorus 4B','Fatherhood','Chorus 5A','Chorus 5B','Final bridge','Final chorus','Resolution']
lines=[];sections=[]
for k,(texts,(start,end),label) in enumerate(zip(blocks,bounds,labels)):
 words,tokens,owners=transcript_tokens(' '.join(texts),a.vocab)
 mask=(starts>=start)&(starts<end)
 path=force_align(e[mask],tokens,a.vocab.get('<pad>',0))
 ww=words_from_path(e[mask],path,tokens,owners,words,starts[mask],304.88,min_word_confidence=0,min_mean_confidence=0)
 cursor=0
 for text in texts:
  count=len(text.split());ws=ww[cursor:cursor+count];cursor+=count
  lines.append({'section':label,'block':k,'text':text,'start':ws[0]['start'],'end':ws[-1]['end'],'words':ws})
 sections.append({'label':label,'block':k,'start':start,'end':end})
assert [w['text'] for l in lines for w in l['words']]==(root/'lyrics.txt').read_text().split()
(root/'aligned-lines.json').write_text(json.dumps(lines,indent=2));(root/'sections.json').write_text(json.dumps(sections,indent=2))
for i,l in enumerate(lines):print(i,f"{l['start']:.2f}–{l['end']:.2f}",l['text'])
