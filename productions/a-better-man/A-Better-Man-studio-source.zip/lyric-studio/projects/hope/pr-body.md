Adds the complete **Hungry For Hope** lyric video for **#WEED_SMOK** (song date supplied: September 22, 2024) under `productions/hungry-for-hope/`.

The production uses three newly generated cinematic environments and an editorial composite made from both user-reattached portraits. Anton/Oswald typography, phrase/word reveals, measured bass and transient pulses, rain/ash/dust, camera pushes and section transitions share one deterministic Remotion composition. The MP4, all four PNG assets, fonts with OFL notices, editable project, SRT, word cues, source ZIP, poster and verification records are included.

Validation: TypeScript/build, twelve automated tests, Chromium boundary checks for all 53 lyric midpoint layouts, and final MP4 stream/frame/decode/audio checks recorded in `verification.json`. Portrait sections were integrated at exact frame boundaries while retaining the full audio stream.

Timing remains a constrained acoustic estimate, with review flags retained. Additional audible “Replace” repetitions reuse the supplied lines; the original pasted sequence is preserved separately. Generated images and photographic composites are animated image assets, not filmed performance footage. Existing application files are unchanged.
