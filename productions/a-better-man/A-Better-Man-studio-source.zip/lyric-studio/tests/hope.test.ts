import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import { qc, Project } from "../src/model";
const p = JSON.parse(
  fs.readFileSync("projects/hungry-for-hope.json", "utf8"),
) as Project;
test("Hope preserves supplied wording; added vocal repeats reuse existing lines", () => {
  const original = p.lyrics.split("\n").filter(Boolean);
  assert.equal(p.lines.length, 53);
  assert.equal(p.lines.flatMap((l) => l.words).length, 213);
  for (const l of p.lines) {
    assert(original.includes(l.text));
    assert.equal(l.words.map((w) => w.text).join(" "), l.text);
  }
  for (const text of original) assert(p.lines.some((l) => l.text === text));
  assert.equal(
    p.lines.filter((l) => l.text === "Replace emptiness for security").length,
    3,
  );
});
test("Hope timing, contiguous scenes and full export duration are valid", () => {
  assert.deepEqual(qc(p), ["Estimated lyric timing requires listening review"]);
  assert.equal(p.scenes[0].start, 0);
  assert.equal(p.scenes.at(-1)!.end, p.duration);
  for (let i = 1; i < p.scenes.length; i++)
    assert.equal(p.scenes[i - 1].end, p.scenes[i].start);
  assert.equal(Math.ceil(p.duration * 24), 4245);
  assert.equal(p.lines.at(-1)!.text, "Hungry for Hope");
});
test("Hope uses measured bass and refractory transient events", () => {
  assert(p.analysis.bass!.length > 3000);
  assert(p.analysis.impacts!.length > 100);
  for (let i = 1; i < p.analysis.impacts!.length; i++)
    assert(
      p.analysis.impacts![i].time - p.analysis.impacts![i - 1].time > 0.34,
    );
  assert(p.analysis.beats.every((x, i) => !i || x > p.analysis.beats[i - 1]));
});
test("Generated Hope environment assets are present and sufficiently sized", () => {
  const a = JSON.parse(fs.readFileSync("projects/hope/assets.json", "utf8"));
  assert.equal(a.assets.length, 4);
  for (const x of a.assets) {
    assert(x.width >= 1500 && x.height >= 900);
    assert(fs.existsSync(`public/hope/${x.file}`));
  }
});
