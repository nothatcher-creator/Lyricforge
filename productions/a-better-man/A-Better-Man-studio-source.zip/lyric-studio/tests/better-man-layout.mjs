import { chromium } from "playwright";
import fs from "node:fs/promises";
import assert from "node:assert/strict";
const p = JSON.parse(
  await fs.readFile("projects/a-better-man.json", "utf8"),
);
const browser = await chromium.launch({
  executablePath: "/usr/bin/chromium",
  headless: true,
  args: ["--no-sandbox"],
});
const page = await browser.newPage({ viewport: { width: 1600, height: 1200 } });
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
await page.goto("http://localhost:3100");
await page.getByRole("button", { name: "Open", exact: true }).click();
await page
  .getByRole("button", { name: "a-better-man.json", exact: true })
  .click();
await page.waitForTimeout(700);
await page.evaluate(() => document.fonts.ready);
const violations = [];
const samples = p.lines.map(l => ({ t: l.start + (l.end-l.start)*.6, line: l.id, expectLyric: true }));
for (const shot of p.film.shots.slice(1)) for (const offset of [.08,.35,.7]) {
 const t=shot.start+offset;
 samples.push({t,line:shot.id,expectLyric:p.lines.some(l=>t>=l.start&&t<l.end)});
}
for (const l of samples) {
  const t = l.t;
  await page.locator(".timeline-head input").fill(t.toFixed(3));
  const frame=Math.round(t*p.settings.fps);
  await page.waitForFunction(frame=>Number(document.querySelector('[data-composition-frame]')?.getAttribute('data-composition-frame'))===frame,frame);
  const expected=p.lines.find(line=>frame/p.settings.fps>=line.start&&frame/p.settings.fps<line.end);
  if(expected) await page.locator(`[data-lyric="${expected.id}"]`).waitFor();
  const bounds = await page.evaluate(() => {
    const wrap = document.querySelector(".player-wrap > div").getBoundingClientRect();
    const words = [
      ...document.querySelectorAll("[data-lyric] [data-word]"),
    ].map((x) => {
      const r = x.getBoundingClientRect();
      return {
        text: x.textContent,
        left: r.left,
        right: r.right,
        top: r.top,
        bottom: r.bottom,
      };
    });
    return {
      wrap: {
        left: wrap.left,
        right: wrap.right,
        top: wrap.top,
        bottom: wrap.bottom,
      },
      words,
    };
  });
  if (expected && !bounds.words.length)
    violations.push({ line: l.line, error: "missing lyric at midpoint" });
  for (const w of bounds.words) {
    if (
      w.left < bounds.wrap.left + 5 ||
      w.right > bounds.wrap.right - 5 ||
      w.top < bounds.wrap.top + 5 ||
      w.bottom > bounds.wrap.bottom - 5
    )
      violations.push({ line: l.line, word: w.text, error: "outside preview" });
  }
}
await page.locator(".timeline-head input").fill("64");
await page.waitForTimeout(200);
await page.screenshot({
  path: "exports/A-Better-Man-studio.png",
  fullPage: true,
});
await browser.close();
await fs.writeFile(
  "exports/better-man-layout-check.json",
  JSON.stringify(
    { phrasesChecked: p.lines.length, transitionSamples: (p.film.shots.length-1)*3, samplesChecked: samples.length, violations, runtimeErrors: errors },
    null,
    2,
  ),
);
assert.equal(violations.length, 0, JSON.stringify(violations));
assert.equal(errors.length, 0, errors.join("\n"));
console.log(
  "All A Better Man lyric midpoint and transition layouts in bounds; no browser runtime errors.",
);
