import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createBetterProject,betterShotAt,isBetterProject} from '../src/better-man/model';
import {demo} from '../src/sample';
const raw=JSON.parse(fs.readFileSync('projects/better-man/aligned-lines.json','utf8'));
const measured=JSON.parse(fs.readFileSync('projects/better-man/analysis.json','utf8'));
const lyrics=fs.readFileSync('projects/better-man/lyrics.txt','utf8');
const make=()=>createBetterProject(demo,measured,raw,lyrics);
test('A Better Man preserves every literal supplied token and full audio',()=>{
 const p=make();assert.deepEqual(p.lines.flatMap(l=>l.words.map(w=>w.text)),lyrics.split(/\s+/).filter(Boolean));
 assert.equal(p.lines.length,67);assert.equal(p.duration,304.88);assert.equal(p.audio,'/media/a-better-man.mp3');
 for(let i=0;i<p.lines.length;i++){
  const l=p.lines[i];assert(l.start<l.end);if(i)assert(p.lines[i-1].end<=l.start);
  assert(l.words.every(w=>w.start>=l.start&&w.end<=l.end&&w.end>w.start));
 }
 assert(!p.lines.some(l=>l.start<209.5&&l.end>189.2),'instrumental break must stay lyric-free');
});
test('A Better Man shot coverage is complete, reference-safe and musically progressive',()=>{
 const p=make();assert(p.film.shots.length>=38);assert(isBetterProject(p));assert(!isBetterProject(demo));
 let end=0;for(const s of p.film.shots){assert.equal(s.start,end);assert(s.end>s.start);end=s.end;assert(fs.existsSync('public/'+s.plate));assert(fs.existsSync('public/'+s.foreground));}
 assert.equal(end,p.duration);assert.equal(betterShotAt(p,p.duration).shot.id,p.film.shots.at(-1)!.id);
 assert(p.film.shots.some(s=>s.mode==='instrumental'&&s.start>=189));
 assert.deepEqual([...new Set(p.film.shots.filter(s=>s.mode==='hook').map(s=>s.level))],[1,2,3,4,5,6]);
 for(const s of p.film.shots.filter(s=>s.plate.includes('father')))assert.equal(s.layout,'right');
});
test('alignment audit identifies the same vocal repeat as the aligned project',()=>{
 const audit=JSON.parse(fs.readFileSync('projects/better-man/alignment-review.json','utf8'));
 assert.equal(audit.length,raw.length);
 for(let i=0;i<raw.length;i++){
  assert.equal(audit[i].text,raw[i].text);
  assert.equal(audit[i].start,raw[i].start,raw[i].text);
  assert.equal(audit[i].end,raw[i].end,raw[i].text);
 }
});
test('final repeated call remains visible until the next phrase',()=>{
 const p=make();assert.equal(p.lines[63].end,p.lines[64].start);assert.equal(p.lines[64].end,p.lines[65].start);
});
test('software production uses the consolidated canvas and keeps the DOM fallback',()=>{
 assert.equal(make().film.renderer,'canvas');
});
