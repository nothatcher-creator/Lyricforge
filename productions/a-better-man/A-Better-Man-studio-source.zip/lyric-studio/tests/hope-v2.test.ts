import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import { buildV2, getShotState, monochromeAt, isV2Project, shotEnvironment } from "../src/hope-v2/model";
const v1 = JSON.parse(fs.readFileSync("projects/hungry-for-hope.json", "utf8"));
test("V2 preserves all original cues, audio and duration", () => {
  const p = buildV2(v1);
  assert.deepEqual(p.lines, v1.lines);
  assert.equal(p.audio, v1.audio);
  assert.equal(p.duration, v1.duration);
  assert.equal(p.style, "hope-v2");
});
test("V2 handles the final playhead and rejects projects without shot data", () => {
  const p = buildV2(v1);
  assert.equal(getShotState(p, p.duration).shot.id, p.v2.shots.at(-1)!.id);
  assert.equal(isV2Project({...v1, style: "hope-v2"}), false);
  assert.equal(isV2Project(p), true);
  for (const shot of p.v2.shots) {
    if (shot.plate.includes("artist-storm")) {
      assert.equal(shotEnvironment(shot), "coast");
      assert(shot.foreground.includes("rain"));
    }
    if (shot.plate.includes("artist-amber")) {
      assert.equal(shotEnvironment(shot), "aperture");
      assert(shot.foreground.includes("stone"));
    }
  }
});
test("V2 shot timeline covers the full song without gaps and resolves assets", () => {
  const p = buildV2(v1);
  assert(p.v2.shots.length >= 26);
  assert.equal(p.v2.shots[0].start, 0);
  assert.equal(p.v2.shots.at(-1)!.end, p.duration);
  for (let i = 0; i < p.v2.shots.length; i++) {
    const s = p.v2.shots[i];
    assert(s.end > s.start);
    if (i) assert.equal(p.v2.shots[i - 1].end, s.start);
    assert(fs.existsSync("public/" + s.plate));
    assert(fs.existsSync("public/" + s.foreground));
  }
  for (const t of [0, 9.49, 37.66, 87.59, 106.1, 115.43, 151.55, 176.83])
    assert(getShotState(p, t).shot);
});
test("V2 has deliberate monochrome middle, color return and escalating hooks", () => {
  assert.equal(monochromeAt(95), 1);
  assert.equal(monochromeAt(110), 1);
  assert.equal(monochromeAt(117), 0);
  const p = buildV2(v1);
  const levels = [30, 55, 116, 153].map((t) => getShotState(p, t).shot.level);
  assert.deepEqual(levels, [1, 2, 3, 4]);
  assert(p.v2.shots.some((s) => s.placement === "wall"));
  assert(p.v2.shots.some((s) => s.placement === "floor"));
  assert(p.v2.shots.some((s) => s.placement === "fog"));
});
