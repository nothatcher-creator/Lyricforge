import {test} from 'node:test';
import assert from 'node:assert/strict';
import {planFrames} from '../server/chunk-plan';
test('long-song chunk plan preserves every frame once including short final range',()=>{
 const ranges=planFrames(7318,1800);assert.deepEqual(ranges,[[0,1799],[1800,3599],[3600,5399],[5400,7199],[7200,7317]]);
 assert.equal(ranges.reduce((n,[a,b])=>n+b-a+1,0),7318);
 assert.deepEqual(planFrames(1,1800),[[0,0]]);
 assert.throws(()=>planFrames(0,1800));assert.throws(()=>planFrames(100,-1));
});
