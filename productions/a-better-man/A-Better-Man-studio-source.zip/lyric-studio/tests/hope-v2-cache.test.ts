import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import type {HopeV2Project} from '../src/hope-v2/model';
test('cached video layers cover every shot without replacing source art',()=>{
 const p:HopeV2Project=JSON.parse(fs.readFileSync('projects/hungry-for-hope-v2.json','utf8'));
 for(const s of p.v2.shots) for(const key of ['gradedPlate','monoPlate','gradedForeground','monoForeground'] as const){
  assert(s[key],key+' missing');
  assert(fs.existsSync('public/'+s[key]));
  assert.notEqual(s[key],s.plate);
 }
});
