import {test} from 'node:test';import assert from 'node:assert/strict';
import {renderCacheKey} from '../server/render-cache';
test('resume cache separates quality, compositor, source and changed media',()=>{
 const base={project:'same project',sources:{'film.tsx':'version 1'},media:{'plate.png':new Uint8Array([1,2,3])},render:{crf:18,backend:'canvas'}};
 const key=renderCacheKey(base);assert.equal(key,renderCacheKey({...base,render:{backend:'canvas',crf:18}}));
 assert.notEqual(key,renderCacheKey({...base,render:{crf:22,backend:'canvas'}}));
 assert.notEqual(key,renderCacheKey({...base,render:{crf:18,backend:'dom'}}));
 assert.notEqual(key,renderCacheKey({...base,sources:{'film.tsx':'version 2'}}));
 assert.notEqual(key,renderCacheKey({...base,media:{'plate.png':new Uint8Array([1,2,4])}}));
});
