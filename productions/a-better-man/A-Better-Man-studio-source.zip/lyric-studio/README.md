# NOCTURNE Lyric Studio

A local React / TypeScript / Remotion production foundation with a visual editor and real H.264/AAC export. No paid services or keys are required.

## Run

Requires Node 22+, Python 3, FFmpeg/ffprobe and Chromium at `/usr/bin/chromium`.

```sh
npm ci
npm run demo
npm run dev
```

Open http://localhost:3100. Keep this server running during rendering. It serves media to Chromium. This is a trusted local workstation application, not an authenticated public service; do not expose its port publicly.

## Simple workflow with Codex

Attach audio and lyrics in chat. Codex can import the audio, revise the versioned project JSON, inspect preview frames, adjust timestamps, and render. Optional direction: mood, artist name, palette, aspect ratio. Review the creative treatment before final rendering. Natural-language revisions can also be entered into the editor's command bar; its built-in parser supports a documented small vocabulary, not a general language model.

## Editor workflow

1. Paste lyrics under Lyrics, then import Audio. The original upload is retained in `public/media`.
2. Inspect the creative treatment and choose neon, industrial, or golden direction.
3. Review phrase and word timestamps while listening. Generated timings distribute words across the track; **they are not forced alignment**. Every generated word is flagged for review. Adjust sustained words with the word end time.
4. Choose animation per phrase, split scenes, set camera and atmosphere.
5. Approve the treatment, choose output dimensions/FPS, and render.
6. Download the MP4. Save projects locally or export JSON. Keep `public/media` alongside project JSON when backing up.

`projects/` uses atomic JSON writes. `exports/` contains render snapshots, reports, and videos. A failed or interrupted render can be rerun from its snapshot; frame-level resume is not implemented. Jobs are in memory and reset with the server. One export runs at a time.

## Completed

- Audio import and real FFmpeg PCM analysis: RMS energy, amplitude waveform, approximate BPM and beat grid.
- Energy-based scene suggestions, editable treatment approval, three procedural palettes, depth rings, light beams, particles/rain, vignette, camera drift/orbit/push and reactive word highlights.
- Eight frame-driven type variations: cinematic, rise, impact, glitch, typewriter, orbit, neon and drift. These are restrained CSS/SVG effects, not simulated smoke/particle typography.
- Live Remotion player; clickable audio, lyrics, scene, camera and effect tracks; numeric phrase/word timing, per-phrase animation, scene split, camera and atmosphere controls.
- Local save/load and JSON interchange, optional artist text branding.
- Small deterministic creative command parser, with explicit errors for unsupported requests. All project properties can be edited through Codex.
- Render progress/errors, H.264 and 320 kbps AAC, 360p draft, 1080p, 4K, portrait and square; 24/30/60 FPS options. Only draft export has been end-to-end verified here; 4K can be slow.
- Preflight checks for timing, overlap, long phrases, missing audio, reviewed timing and approval. No claim of automated perceptual QC.

## Not yet implemented

Whisper transcription, acoustic forced alignment, syllable timing, vocal separation/recognition, reliable genre/instrument/emotion or semantic section recognition; overlapping vocal lanes; full drag/trim/reorder/keyframe editor; custom assets/fonts/logo upload UI; reusable artist-profile library; true 3D environments/DOF, motion blur, fluid smoke, ash disintegration; transparent/ProRes exports; hardware encoder selection; frame-resume; automated contrast/black-frame/overflow repair. These are future extensions, not functioning features.

The demo audio is an original generated 120 BPM instrumental. Its original display lyrics are intentionally illustrative and do not demonstrate sung-word alignment. No song was supplied during development.

## Verify

```sh
npm run build
npm test
node tests/browser.mjs  # running server required
npm run render:demo    # running server required
ffprobe exports/demo.mp4
```

Demo: `exports/demo.mp4`. Screenshot: `exports/studio.png`. Core source: `src/model.ts`, `src/Video.tsx`, `src/main.tsx`, `server/analyze.ts`, `server/render.ts`. Remotion may require a commercial license for some organization sizes/use cases; review its current terms before organizational production use.

## Four Dollars Seventy-Three production

The approved jazz-finance film is in `projects/four-dollars-seventy-three.json`. Use Open in the editor to load it. `src/FinanceFilm.tsx` contains the dedicated art direction; `public/plates` caches original illustrations for efficient rendering. `server/film-render.ts` renders the full production or a poster. `server/qc-film.py` checks the resulting media stream. See `docs/four-dollars-production.md` for timing confidence and reproduction instructions.

Local Whisper and CTC scripts are available for this production through `.venv`; transcription is not yet integrated into the general editor. The supplied-word forced aligner was adapted from the existing Lyricforge repository, which documents its pinned Apache-2.0 wav2vec2 model. Uncertain word timings remain marked for listening review.

## Hungry For Hope production

Load `projects/hungry-for-hope.json` in the editor. Dedicated composition: `src/HopeFilm.tsx`. Four genuine generated PNG assets include three environments and a composite of the user-reattached portraits. Anton and Oswald fonts and OFL notices are included. Bass/impact signals are stored in the project. Render with `npx tsx server/render-hope.ts final`; verify with `python3 server/qc-hope.py`. See `docs/hungry-for-hope-production.md` for lyric repetitions, acoustic timing limitations, and reproduction.
