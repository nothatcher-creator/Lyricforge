import React, { useRef, useState, useEffect } from "react";
import { createRoot } from "react-dom/client";
import { Player, PlayerRef } from "@remotion/player";
import { Video } from "./Video";
import { demo } from "./sample";
import { Project, align, direct, qc, presets } from "./model";
import {
  Music2,
  Layers,
  SlidersHorizontal,
  Download,
  Plus,
  ArrowUpRight,
  Check,
  Command,
  Film,
  Save,
  FolderOpen,
  Sparkles,
} from "lucide-react";
import "./style.css";
function App() {
  const [p, setP] = useState<Project>(demo),
    [tab, setTab] = useState("Direction"),
    [selected, setSelected] = useState(0),
    [time, setTime] = useState(0),
    [notice, setNotice] = useState(""),
    [busy, setBusy] = useState(false),
    [command, setCommand] = useState(""),
    [progress, setProgress] = useState<number | null>(null),
    [download, setDownload] = useState("");
  const player = useRef<PlayerRef>(null);
  const input = useRef<HTMLInputElement>(null);
  const jsonInput = useRef<HTMLInputElement>(null);
  const [files, setFiles] = useState<string[]>([]);
  const [lyrics, setLyrics] = useState(p.lyrics);
  const [sceneIndex, setSceneIndex] = useState(0);
  const update = (v: Partial<Project>) =>
    setP((x) => ({ ...x, ...v, approved: false }));
  async function request(url: string, body?: unknown) {
    const r = await fetch(
      url,
      body
        ? {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(body),
          }
        : undefined,
    );
    const data = await r.json();
    if (!r.ok) throw Error(data.error);
    return data;
  }
  async function perform(fn: () => Promise<void>) {
    setBusy(true);
    try {
      await fn();
    } catch (e) {
      setNotice(String(e));
    } finally {
      setBusy(false);
    }
  }
  async function upload(file: File) {
    const f = new FormData();
    f.append("audio", file);
    f.append("lyrics", lyrics);
    const r = await fetch("/api/import", { method: "POST", body: f });
    const data = await r.json();
    if (!r.ok) throw Error(data.error);
    setP(data);
    setSelected(0);
    setNotice("Audio analyzed. Review estimated word timing before export.");
  }
  function changeLine(index: number, v: Partial<Project["lines"][number]>) {
    const lines = structuredClone(p.lines);
    const old = lines[index];
    if (v.start !== undefined || v.end !== undefined) {
      const start = v.start ?? old.start,
        end = v.end ?? old.end;
      if (end <= start || start < 0 || end > p.duration) {
        setNotice("Cue must have a positive duration inside the song.");
        return;
      }
      const scale = (end - start) / (old.end - old.start);
      old.words = old.words.map((w) => ({
        ...w,
        start: start + (w.start - old.start) * scale,
        end: start + (w.end - old.start) * scale,
      }));
    }
    lines[index] = { ...old, ...v };
    update({ lines });
  }
  async function exportVideo() {
    setDownload("");
    const { id } = await request("/api/render", p);
    setProgress(0);
    const timer = setInterval(async () => {
      try {
        const job = await request(`/api/jobs/${id}`);
        setProgress(job.progress);
        if (
          job.status === "done" ||
          job.status === "error" ||
          job.status === "unknown"
        ) {
          clearInterval(timer);
          setProgress(null);
          if (job.error) setNotice(job.error);
          else {
            setDownload(job.url);
            setNotice(
              "Render complete. MP4 and project snapshot saved to exports.",
            );
          }
        }
      } catch (e) {
        clearInterval(timer);
        setProgress(null);
        setNotice(String(e));
      }
    }, 1200);
  }
  useEffect(() => {
    const current = player.current;
    if (!current) return;
    const listener = (e: { detail: { frame: number } }) =>
      setTime(e.detail.frame / p.settings.fps);
    current.addEventListener("frameupdate", listener);
    return () => current.removeEventListener("frameupdate", listener);
  }, [p.settings.fps]);
  const scene = p.scenes[sceneIndex],
    line = p.lines[selected];
  return (
    <div className="app">
      <aside className="rail">
        <div className="mark">
          N<span>•</span>
        </div>
        <button
          className="active"
          title="Director"
          onClick={() => setTab("Direction")}
        >
          <Film size={21} />
        </button>
        <button title="Lyrics" onClick={() => setTab("Lyrics")}>
          <Music2 size={21} />
        </button>
        <button title="Scenes" onClick={() => setTab("Scenes")}>
          <Layers size={21} />
        </button>
        <button title="Output settings" onClick={() => setTab("Export")}>
          <SlidersHorizontal size={21} />
        </button>
        <div className="rail-bottom">
          NV
          <br />
          <span>01</span>
        </div>
      </aside>
      <main>
        <header>
          <div className="wordmark">
            NOCTURNE <span>LYRIC STUDIO</span>
          </div>
          <div className="header-right">
            <span className="local">
              <i /> LOCAL WORKSPACE
            </span>
            <button
              onClick={() =>
                perform(async () => {
                  await request("/api/save", p);
                  setNotice("Project saved locally.");
                })
              }
            >
              <Save size={14} /> Save project
            </button>
            <button
              className="primary"
              disabled={busy || progress !== null}
              onClick={() => setTab("Export")}
            >
              Export video <ArrowUpRight size={15} />
            </button>
          </div>
        </header>
        <div className="projectbar">
          <div>
            <div className="eyebrow">
              PROJECT / {p.id === "demo" ? "DEMO SESSION" : "LOCAL SESSION"}
            </div>
            <input
              className="title-input"
              value={p.title}
              onChange={(e) => update({ title: e.target.value })}
            />
          </div>
          <div className="projectmeta">
            <span>
              {p.analysis.bpm} <small>BPM</small>
            </span>
            <span>
              {p.duration.toFixed(1)} <small>SEC</small>
            </span>
            <span>
              {p.settings.width} × {p.settings.height}
              <small> / {p.settings.fps} FPS</small>
            </span>
          </div>
        </div>
        <div className="workspace">
          <section className="monitor">
            <div className="sectionbar">
              <span>
                <i className="dot" /> LIVE COMPOSITION
              </span>
              <span>
                FRAME{" "}
                {Math.round(time * p.settings.fps)
                  .toString()
                  .padStart(5, "0")}{" "}
                <span className="muted">/ DRAFT PREVIEW</span>
              </span>
            </div>
            <div className="player-wrap">
              <Player
                ref={player}
                component={Video}
                inputProps={{ project: p }}
                durationInFrames={Math.ceil(p.duration * p.settings.fps)}
                fps={p.settings.fps}
                compositionWidth={p.settings.width}
                compositionHeight={p.settings.height}
                controls
                style={{
                  width: "100%",
                  maxHeight: 440,
                  aspectRatio: `${p.settings.width}/${p.settings.height}`,
                }}
                acknowledgeRemotionLicense
              />
            </div>
            <div className="monitor-caption">
              <span>{p.style.toUpperCase()} / PROCEDURAL ENVIRONMENT</span>
              <span>SAFE AREA · 84%</span>
            </div>
            <div className="command">
              <Sparkles size={18} />
              <input
                value={command}
                onChange={(e) => setCommand(e.target.value)}
                placeholder="Direct the scene… “Make the chorus heavier”"
                onKeyDown={(e) => {
                  if (e.key === "Enter")
                    try {
                      setP(direct(p, command));
                      setNotice(`Applied: ${command}`);
                      setCommand("");
                    } catch (err) {
                      setNotice(String(err));
                    }
                }}
              />
              <button
                onClick={() => {
                  try {
                    setP(direct(p, command));
                    setNotice(`Applied: ${command}`);
                    setCommand("");
                  } catch (e) {
                    setNotice(String(e));
                  }
                }}
              >
                <Command size={14} /> Apply
              </button>
            </div>
            <div className="timeline-head">
              <div>
                <b>Production timeline</b>
                <span>
                  {p.scenes.length} scenes · {p.lines.length} phrases
                </span>
              </div>
              <label>
                Playhead{" "}
                <input
                  type="number"
                  min="0"
                  max={p.duration}
                  step="0.1"
                  value={time}
                  onChange={(e) => {
                    const t = Math.max(
                      0,
                      Math.min(p.duration - 0.05, +e.target.value),
                    );
                    setTime(t);
                    player.current?.seekTo(Math.round(t * p.settings.fps));
                  }}
                />{" "}
                s
              </label>
            </div>
            <div className="timeline">
              <div className="ruler">
                <span>TRACKS</span>
                <div>
                  {Array.from({ length: 9 }, (_, i) => (
                    <span key={i}>{((p.duration * i) / 8).toFixed(1)}s</span>
                  ))}
                </div>
              </div>
              {["Audio", "Lyrics", "Scenes", "Camera", "Effects"].map(
                (track, i) => (
                  <div className="track" key={track}>
                    <label>
                      {["♫", "T", "▧", "↗", "✧"][i]} <span>{track}</span>
                    </label>
                    <div
                      className="trackbody"
                      onClick={(e) => {
                        const rect = e.currentTarget.getBoundingClientRect();
                        const t =
                          ((e.clientX - rect.left) / rect.width) * p.duration;
                        setTime(t);
                        player.current?.seekTo(Math.floor(t * p.settings.fps));
                      }}
                    >
                      {i === 0 ? (
                        <div className="wave">
                          {p.analysis.waveform
                            .filter(
                              (_, i) =>
                                i %
                                  Math.max(
                                    1,
                                    Math.floor(
                                      p.analysis.waveform.length / 180,
                                    ),
                                  ) ===
                                0,
                            )
                            .map((v, j) => (
                              <i
                                key={j}
                                style={{ height: `${Math.max(8, v * 95)}%` }}
                              />
                            ))}
                        </div>
                      ) : (
                        (i === 1 ? p.lines : p.scenes).map((x, j) => (
                          <button
                            key={x.id}
                            className={`clip c${i} ${i === 1 && j === selected ? "selected" : ""}`}
                            style={{
                              left: `${(x.start / p.duration) * 100}%`,
                              width: `${((x.end - x.start) / p.duration) * 100}%`,
                            }}
                            onClick={(e) => {
                              e.stopPropagation();
                              if (i === 1) {
                                setSelected(j);
                                setTab("Lyrics");
                              } else {
                                setSceneIndex(j);
                                setTab("Scenes");
                              }
                              player.current?.seekTo(
                                Math.round(x.start * p.settings.fps),
                              );
                              setTime(x.start);
                            }}
                          >
                            {i === 1
                              ? (x as any).text
                              : i === 2
                                ? (x as any).label
                                : i === 3
                                  ? (x as any).camera
                                  : `Atmosphere ${(x as any).effects.toFixed(1)}`}
                          </button>
                        ))
                      )}
                      <div
                        className="playhead"
                        style={{ left: `${(time / p.duration) * 100}%` }}
                      />
                    </div>
                  </div>
                ),
              )}
            </div>
          </section>
          <aside className="inspector">
            <nav>
              {["Direction", "Lyrics", "Scenes", "Export"].map((t) => (
                <button
                  className={tab === t ? "chosen" : ""}
                  key={t}
                  onClick={() => setTab(t)}
                >
                  {t}
                </button>
              ))}
            </nav>
            <div className="panel">
              {tab === "Direction" && (
                <>
                  <div className="eyebrow">CREATIVE TREATMENT</div>
                  <h2>
                    A world for
                    <br />
                    every word.
                  </h2>
                  <p className="description">{p.treatment}</p>
                  <div className="palette">
                    <i style={{ background: "#0a1220" }} />
                    <i style={{ background: "#29454c" }} />
                    <i style={{ background: p.accent }} />
                    <i style={{ background: "#f1f2ec" }} />
                    <span>01 — NIGHTFALL</span>
                  </div>
                  <button
                    className={p.approved ? "approved wide" : "primary wide"}
                    onClick={() => setP({ ...p, approved: !p.approved })}
                  >
                    <Check size={15} />
                    {p.approved ? "Treatment approved" : "Approve treatment"}
                  </button>
                  <hr />
                  <label>
                    VISUAL DIRECTION
                    <select
                      value={p.style}
                      onChange={(e) => update({ style: e.target.value })}
                    >
                      <option value="hope">
                        Hungry For Hope / cinematic rock
                      </option>
                      <option value="finance">
                        Four Dollars / jazz-finance
                      </option>
                      <option value="neon">Nocturnal / neon rain</option>
                      <option value="industrial">Industrial / ember</option>
                      <option value="golden">Golden / atmospheric</option>
                    </select>
                  </label>
                  <div className="two">
                    <label>
                      ACCENT
                      <input
                        type="color"
                        value={p.accent}
                        onChange={(e) => update({ accent: e.target.value })}
                      />
                    </label>
                    <label>
                      INTENSITY
                      <input
                        type="range"
                        min="0"
                        max="1"
                        step=".05"
                        value={p.intensity}
                        onChange={(e) => update({ intensity: +e.target.value })}
                      />
                    </label>
                  </div>
                  <label>
                    ARTIST
                    <input
                      value={p.artist}
                      onChange={(e) => update({ artist: e.target.value })}
                    />
                  </label>
                  <label className="check">
                    <input
                      type="checkbox"
                      checked={p.branding}
                      onChange={(e) => update({ branding: e.target.checked })}
                    />{" "}
                    Show artist branding
                  </label>
                </>
              )}
              {tab === "Lyrics" && (
                <>
                  <div className="eyebrow">LYRIC SYNCHRONIZATION</div>
                  <h2>Words in time.</h2>
                  <p className="description">
                    Automatic timing is an estimate. Listen, correct each cue,
                    then mark reviewed. No lyrics are transcribed or invented.
                  </p>
                  <textarea
                    value={lyrics}
                    onChange={(e) => setLyrics(e.target.value)}
                    rows={5}
                  />
                  <button
                    className="wide"
                    onClick={() => {
                      update({ lyrics, lines: align(lyrics, p.duration) });
                      setSelected(0);
                    }}
                  >
                    Generate estimated timing
                  </button>
                  <hr />
                  <select
                    value={selected}
                    onChange={(e) => setSelected(+e.target.value)}
                  >
                    {p.lines.map((l, i) => (
                      <option key={l.id} value={i}>
                        {i + 1}. {l.text}
                      </option>
                    ))}
                  </select>
                  {line && (
                    <>
                      <div className="two">
                        <label>
                          IN
                          <input
                            type="number"
                            step=".01"
                            value={line.start.toFixed(2)}
                            onChange={(e) =>
                              changeLine(selected, { start: +e.target.value })
                            }
                          />
                        </label>
                        <label>
                          OUT
                          <input
                            type="number"
                            step=".01"
                            value={line.end.toFixed(2)}
                            onChange={(e) =>
                              changeLine(selected, { end: +e.target.value })
                            }
                          />
                        </label>
                      </div>
                      <label>
                        ANIMATION
                        <select
                          value={line.preset}
                          onChange={(e) =>
                            changeLine(selected, { preset: e.target.value })
                          }
                        >
                          {presets.map((x) => (
                            <option key={x}>{x}</option>
                          ))}
                        </select>
                      </label>
                      <div className="word-list">
                        {line.words.map((w, i) => (
                          <div key={i}>
                            <span
                              title={
                                w.review
                                  ? "Timing needs listening review"
                                  : "Reviewed timing"
                              }
                              style={{
                                color: w.review ? "#d6ad73" : undefined,
                              }}
                            >
                              {w.review ? "○ " : "✓ "}
                              {w.text}
                            </span>
                            <input
                              aria-label={`${w.text} start`}
                              type="number"
                              step=".01"
                              value={w.start.toFixed(2)}
                              onChange={(e) => {
                                const lines = structuredClone(p.lines);
                                lines[selected].words[i].start =
                                  +e.target.value;
                                update({ lines });
                              }}
                            />
                            <input
                              aria-label={`${w.text} end`}
                              type="number"
                              step=".01"
                              value={w.end.toFixed(2)}
                              onChange={(e) => {
                                const lines = structuredClone(p.lines);
                                lines[selected].words[i].end = +e.target.value;
                                update({ lines });
                              }}
                            />
                          </div>
                        ))}
                      </div>
                      <button
                        className="wide"
                        onClick={() =>
                          changeLine(selected, {
                            words: line.words.map((w) => ({
                              ...w,
                              review: false,
                            })),
                          })
                        }
                      >
                        <Check size={14} /> Mark phrase reviewed
                      </button>
                    </>
                  )}
                </>
              )}
              {tab === "Scenes" && (
                <>
                  <div className="eyebrow">SCENE COMPOSITION</div>
                  <h2>Shape the journey.</h2>
                  <select
                    value={sceneIndex}
                    onChange={(e) => setSceneIndex(+e.target.value)}
                  >
                    {p.scenes.map((s, i) => (
                      <option key={s.id} value={i}>
                        {s.label} / {s.start.toFixed(1)}s
                      </option>
                    ))}
                  </select>
                  {scene && (
                    <>
                      <label>
                        SECTION NAME
                        <input
                          value={scene.label}
                          onChange={(e) => {
                            const scenes = structuredClone(p.scenes);
                            scenes[sceneIndex].label = e.target.value;
                            update({ scenes });
                          }}
                        />
                      </label>
                      <label>
                        CAMERA
                        <select
                          value={scene.camera}
                          onChange={(e) => {
                            const scenes = structuredClone(p.scenes);
                            scenes[sceneIndex].camera = e.target.value;
                            update({ scenes });
                          }}
                        >
                          {["dolly", "drift", "orbit"].map((x) => (
                            <option key={x}>{x}</option>
                          ))}
                        </select>
                      </label>
                      <label>
                        ATMOSPHERE
                        <input
                          type="range"
                          min="0"
                          max="1"
                          step=".05"
                          value={scene.effects}
                          onChange={(e) => {
                            const scenes = structuredClone(p.scenes);
                            scenes[sceneIndex].effects = +e.target.value;
                            update({ scenes });
                          }}
                        />
                      </label>
                      <button
                        className="wide"
                        onClick={() => {
                          const scenes = structuredClone(p.scenes),
                            s = scenes[sceneIndex],
                            middle = (s.start + s.end) / 2;
                          scenes.splice(
                            sceneIndex,
                            1,
                            { ...s, end: middle },
                            {
                              ...s,
                              id: crypto.randomUUID(),
                              start: middle,
                              label: `${s.label} II`,
                            },
                          );
                          update({ scenes });
                        }}
                      >
                        Split scene at midpoint
                      </button>
                      <p className="description">
                        Scene labels are energy-based suggestions. Ring
                        geometry, light angles and camera evolve between scenes.
                      </p>
                    </>
                  )}
                </>
              )}
              {tab === "Export" && (
                <>
                  <div className="eyebrow">DELIVERY</div>
                  <h2>
                    Ready for the
                    <br />
                    big screen.
                  </h2>
                  <label>
                    FORMAT
                    <select
                      value={`${p.settings.width}x${p.settings.height}`}
                      onChange={(e) => {
                        const [width, height] = e.target.value
                          .split("x")
                          .map(Number);
                        update({ settings: { ...p.settings, width, height } });
                      }}
                    >
                      <option value="1920x1080">YouTube · 1080p / 16:9</option>
                      <option value="3840x2160">YouTube · 4K / 16:9</option>
                      <option value="1080x1920">Shorts · 1080p / 9:16</option>
                      <option value="1080x1080">Square · 1080p / 1:1</option>
                      <option value="640x360">Draft · 360p / 16:9</option>
                    </select>
                  </label>
                  <label>
                    FRAME RATE
                    <select
                      value={p.settings.fps}
                      onChange={(e) =>
                        update({
                          settings: { ...p.settings, fps: +e.target.value },
                        })
                      }
                    >
                      {[24, 30, 60].map((n) => (
                        <option key={n}>{n}</option>
                      ))}
                    </select>
                  </label>
                  <div className="qc">
                    <b>Preflight review</b>
                    {qc(p).length ? (
                      qc(p).map((x) => <p key={x}>○ {x}</p>)
                    ) : (
                      <p>✓ Project checks passed</p>
                    )}
                  </div>
                  <label className="check">
                    <input
                      type="checkbox"
                      checked={p.approved}
                      onChange={(e) =>
                        setP({ ...p, approved: e.target.checked })
                      }
                    />{" "}
                    Approve current creative treatment
                  </label>
                  <button
                    className="primary wide"
                    disabled={busy || progress !== null || !p.approved}
                    onClick={() => perform(exportVideo)}
                  >
                    <Download size={15} />
                    {progress !== null
                      ? `Rendering ${Math.round(progress * 100)}%`
                      : "Render MP4 · H.264"}
                  </button>
                  {progress !== null && <progress value={progress} max="1" />}
                  {download && (
                    <a className="download" href={download} download>
                      Download finished video ↗
                    </a>
                  )}
                  <p className="description">
                    Original audio is encoded to 320 kbps AAC. Render snapshots
                    and reports are saved locally. 4K speed depends on hardware.
                  </p>
                </>
              )}
              <hr />
              <div className="eyebrow">PROJECT LIBRARY</div>
              <div className="two">
                <button disabled={busy} onClick={() => input.current?.click()}>
                  <Plus size={14} /> Audio
                </button>
                <button
                  onClick={() =>
                    perform(async () =>
                      setFiles(await request("/api/projects")),
                    )
                  }
                >
                  <FolderOpen size={14} /> Open
                </button>
              </div>
              {files.map((f) => (
                <button
                  className="wide"
                  key={f}
                  onClick={() =>
                    perform(async () => {
                      const data = await request(`/api/projects/${f}`);
                      setP(data);
                      setLyrics(data.lyrics);
                      setSelected(0);
                      setSceneIndex(0);
                    })
                  }
                >
                  {f}
                </button>
              ))}
              <div className="two">
                <button
                  onClick={() => {
                    const blob = new Blob([JSON.stringify(p, null, 2)], {
                      type: "application/json",
                    });
                    const a = document.createElement("a");
                    a.href = URL.createObjectURL(blob);
                    a.download = `${p.id}.json`;
                    a.click();
                    URL.revokeObjectURL(a.href);
                  }}
                >
                  Export JSON
                </button>
                <button onClick={() => jsonInput.current?.click()}>
                  Import JSON
                </button>
              </div>
              <input
                hidden
                ref={input}
                type="file"
                accept="audio/*"
                onChange={(e) =>
                  e.target.files?.[0] &&
                  perform(() => upload(e.target.files![0]))
                }
              />
              <input
                hidden
                ref={jsonInput}
                type="file"
                accept=".json"
                onChange={(e) =>
                  e.target.files?.[0] &&
                  perform(async () => {
                    const data = JSON.parse(await e.target.files![0].text());
                    if (data.version !== 1) throw Error("Unsupported project");
                    await request("/api/save", data);
                    setP(data);
                    setLyrics(data.lyrics);
                    setSelected(0);
                    setSceneIndex(0);
                  })
                }
              />
            </div>
          </aside>
        </div>
        <footer>
          <span>
            <i className="dot" /> {busy ? "PROCESSING" : "STUDIO ONLINE"}
          </span>
          <span>DETERMINISTIC ENGINE / LOCAL RENDERING</span>
          <span>NOCTURNE — V1.0</span>
        </footer>
        {notice && (
          <div className="toast" role="status" onClick={() => setNotice("")}>
            {notice}
            <span> ×</span>
          </div>
        )}
      </main>
    </div>
  );
}
createRoot(document.getElementById("root")!).render(<App />);
