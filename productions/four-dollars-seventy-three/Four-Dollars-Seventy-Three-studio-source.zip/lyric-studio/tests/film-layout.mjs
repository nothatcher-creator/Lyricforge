import { chromium } from "playwright";
import fs from "node:fs/promises";
import assert from "node:assert/strict";
const p = JSON.parse(
  await fs.readFile("projects/four-dollars-seventy-three.json", "utf8"),
);
const browser = await chromium.launch({
  executablePath: "/usr/bin/chromium",
  headless: true,
  args: ["--no-sandbox"],
});
const page = await browser.newPage({ viewport: { width: 1600, height: 1200 } });
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
await page.goto("http://localhost:3100");
await page.getByRole("button", { name: "Open", exact: true }).click();
await page
  .getByRole("button", { name: "four-dollars-seventy-three.json", exact: true })
  .click();
await page.waitForTimeout(700);
await page.evaluate(() => document.fonts.ready);
const violations = [];
for (const l of p.lines) {
  const t = l.start + (l.end - l.start) * 0.6;
  await page.locator(".timeline-head input").fill(t.toFixed(3));
  await page.waitForTimeout(40);
  const bounds = await page.evaluate(() => {
    const wrap = document.querySelector(".player-wrap").getBoundingClientRect();
    const words = [...document.querySelectorAll("[data-lyric] span")].map(
      (x) => {
        const r = x.getBoundingClientRect();
        return {
          text: x.textContent,
          left: r.left,
          right: r.right,
          top: r.top,
          bottom: r.bottom,
        };
      },
    );
    return {
      wrap: {
        left: wrap.left,
        right: wrap.right,
        top: wrap.top,
        bottom: wrap.bottom,
      },
      words,
    };
  });
  if (!bounds.words.length)
    violations.push({ line: l.id, error: "missing lyric at midpoint" });
  for (const w of bounds.words) {
    if (
      w.left < bounds.wrap.left + 5 ||
      w.right > bounds.wrap.right - 5 ||
      w.top < bounds.wrap.top + 5 ||
      w.bottom > bounds.wrap.bottom - 5
    )
      violations.push({ line: l.id, word: w.text, error: "outside preview" });
  }
}
await page.locator(".timeline-head input").fill("64");
await page.waitForTimeout(200);
await page.screenshot({
  path: "exports/Four-Dollars-Seventy-Three-studio.png",
  fullPage: true,
});
await browser.close();
await fs.writeFile(
  "exports/layout-check.json",
  JSON.stringify(
    { phrasesChecked: p.lines.length, violations, runtimeErrors: errors },
    null,
    2,
  ),
);
assert.equal(violations.length, 0, JSON.stringify(violations));
assert.equal(errors.length, 0, errors.join("\n"));
console.log(
  "All 78 lyric midpoint layouts in bounds; no browser runtime errors.",
);
