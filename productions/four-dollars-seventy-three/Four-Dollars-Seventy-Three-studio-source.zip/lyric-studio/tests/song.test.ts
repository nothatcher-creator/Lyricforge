import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import { qc, Project } from "../src/model";
const p = JSON.parse(
  fs.readFileSync("projects/four-dollars-seventy-three.json", "utf8"),
) as Project;
test("production preserves all supplied words, punctuation and repeats", () => {
  const original = p.lyrics
    .split("\n")
    .filter((x) => x.trim() && !x.startsWith("["))
    .join(" ")
    .split(/\s+/);
  assert.deepEqual(
    p.lines.flatMap((l) => l.words.map((w) => w.text)),
    original,
  );
  assert.equal(p.lines.length, 78);
  assert.equal(p.lines.flatMap((l) => l.words).length, 317);
});
test("production timing is valid with no lyric during the jazz break", () => {
  assert.deepEqual(qc(p), ["Estimated lyric timing requires listening review"]);
  assert(!p.lines.some((l) => l.start < 134 && l.end > 111));
  assert(p.lines.find((l) => l.text === "LOW BALANCE ALERT.")!.start > 193);
  assert(
    p.lines.find((l) => l.text === "Then my kid laughs from the other room")!
      .start > 134,
  );
});
test("section coverage and export duration preserve the full audio", () => {
  assert.equal(p.scenes[0].start, 0);
  assert.equal(p.scenes.at(-1)!.end, p.duration);
  for (let i = 1; i < p.scenes.length; i++)
    assert.equal(p.scenes[i - 1].end, p.scenes[i].start);
  assert(Math.abs(Math.ceil(p.duration * 24) / 24 - p.duration) < 1 / 24);
  assert.equal(p.settings.width, 1920);
  assert.equal(p.settings.height, 1080);
});
