import { chromium } from "playwright";
import assert from "node:assert/strict";
const browser = await chromium.launch({
  executablePath: "/usr/bin/chromium",
  headless: true,
  args: ["--no-sandbox"],
});
const page = await browser.newPage({ viewport: { width: 1440, height: 1080 } });
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
await page.goto("http://localhost:3100");
await page
  .getByRole("button", { name: "Approve treatment", exact: true })
  .waitFor();
await page.locator(".timeline-head input").fill("2.5");
await page.waitForTimeout(500);
await page.screenshot({ path: "exports/studio.png", fullPage: true });
await page
  .getByPlaceholder("Direct the scene")
  .fill("Make this chorus more aggressive");
await page.getByRole("button", { name: "Apply", exact: true }).click();
await page.getByRole("button", { name: "Save project", exact: true }).click();
await page.waitForTimeout(200);
assert((await page.locator(".toast").innerText()).includes("saved"));
await page
  .locator("nav")
  .getByRole("button", { name: "Lyrics", exact: true })
  .click();
assert.equal(await page.locator(".word-list input").count(), 10);
await page
  .locator("nav")
  .getByRole("button", { name: "Scenes", exact: true })
  .click();
await page.getByRole("button", { name: "Split scene at midpoint" }).click();
assert((await page.locator(".timeline-head").innerText()).includes("5 scenes"));
await page.getByRole("button", { name: "Export", exact: true }).click();
await page.getByLabel("Approve current creative treatment").check();
assert(await page.getByRole("button", { name: "Render MP4" }).isEnabled());
await page.setViewportSize({ width: 390, height: 844 });
await page.screenshot({ path: "exports/mobile.png", fullPage: true });
assert.equal(errors.length, 0, errors.join("\n"));
console.log(
  "Browser passed: preview, creative command, save, word editor, scene split, render controls, mobile; no runtime errors",
);
await browser.close();
