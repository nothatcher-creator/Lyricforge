import { test } from "node:test";
import assert from "node:assert/strict";
import { align, direct, qc } from "../src/model";
import { demo } from "../src/sample";
import { analyze } from "../server/analyze";
test("alignment preserves repeated words and punctuation exactly", () => {
  const lyrics = "Stay, stay with me\nStay, stay with me";
  const lines = align(lyrics, 10);
  assert.equal(lines.map((l) => l.text).join("\n"), lyrics);
  assert.equal(lines.flatMap((l) => l.words).length, 8);
  assert(lines.every((l) => l.words.every((w) => w.review && w.end > w.start)));
  assert(lines[1].start >= lines[0].end);
});
test("creative commands target chorus and keep original intact", () => {
  const p = direct(demo, "Make this chorus more aggressive");
  assert(p.scenes[2].energy > demo.scenes[2].energy);
  assert.equal(p.scenes[0].energy, demo.scenes[0].energy);
  assert.equal(demo.history.length, 0);
  assert.throws(() => direct(demo, "replace it with a giraffe"));
});
test("QC detects invalid and overlapping cues", () => {
  const p = structuredClone(demo);
  p.lines[1].start = -1;
  assert(qc(p).some((x) => x.includes("Invalid")));
  assert(qc(p).some((x) => x.includes("Overlapping")));
  assert(qc(demo).some((x) => x.includes("Estimated")));
});
test("real FFmpeg analysis recovers known demo tempo", async () => {
  const a = await analyze("public/media/demo.wav");
  assert.equal(a.duration, 16);
  assert(Math.abs(a.analysis.bpm - 120) < 2);
  assert(a.analysis.beats.length > 25);
  assert(a.analysis.peak < 1);
});

test("QC rejects nonfinite and overlapping word edits", () => {
  const p = structuredClone(demo);
  p.lines[0].words[0].start = Number.NaN;
  p.lines[1].words[1].start = p.lines[1].words[0].start;
  assert(qc(p).some((x) => x.includes("Word outside")));
  assert(qc(p).some((x) => x.includes("Overlapping words")));
});
