import React from "react";
import { registerRoot, Composition } from "remotion";
import { Video } from "./Video";
import { FinancePlate } from "./FinanceFilm";
import { demo } from "./sample";
registerRoot(() => (
  <>
    <Composition
      id="LyricVideo"
      component={Video}
      durationInFrames={480}
      width={1920}
      height={1080}
      fps={30}
      defaultProps={{ project: demo }}
      calculateMetadata={({ props }) => ({
        durationInFrames: Math.ceil(
          props.project.duration * props.project.settings.fps,
        ),
        ...props.project.settings,
      })}
    />
    <Composition
      id="FinancePlate"
      component={FinancePlate}
      durationInFrames={1}
      width={1920}
      height={1080}
      fps={24}
      defaultProps={{ environment: "balance" }}
    />
  </>
));
