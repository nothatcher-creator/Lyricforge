import React from "react";
import {
  AbsoluteFill,
  Audio,
  Img,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import type { Project, Scene } from "./model";
const C = {
  ink: "#101b1b",
  cream: "#eee7d3",
  green: "#b8c99b",
  muted: "#7b9384",
  gold: "#d6ad73",
  red: "#e09376",
};
const clamp = (x: number) => Math.min(1, Math.max(0, x));
const ease = (x: number) => 1 - Math.pow(1 - clamp(x), 3);
function Grocery({ t }: { t: number }) {
  return (
    <g
      transform={`translate(${Math.sin(t * 0.13) * 18} ${Math.cos(t * 0.17) * 8})`}
    >
      <path d="M0 40H1920V850L1200 650H720L0 850Z" fill="#142a28" />
      <path d="M0 850L720 650H1200L1920 850V1080H0Z" fill="#1e3530" />
      {[0, 1, 2, 3].map((i) => (
        <g key={i} opacity={0.7 - i * 0.11}>
          <path
            d={`M${i * 135} ${150 + i * 105} L${680 + i * 8} ${420 + i * 45}V${520 + i * 45}L${i * 135} ${290 + i * 140}Z`}
            fill="#416052"
          />
          <path
            d={`M${1920 - i * 135} ${150 + i * 105} L${1240 - i * 8} ${420 + i * 45}V${520 + i * 45}L${1920 - i * 135} ${290 + i * 140}Z`}
            fill="#416052"
          />
          {Array.from({ length: 10 }, (_, j) => (
            <g key={j}>
              <rect
                x={j * 62 + i * 12}
                y={160 + i * 140}
                width={34 - i * 3}
                height={50 - i * 4}
                rx="3"
                fill={j % 3 === 0 ? "#b6b38c" : "#63836d"}
                opacity=".5"
              />
              <rect
                x={1920 - j * 62 - i * 12 - 34}
                y={160 + i * 140}
                width={34 - i * 3}
                height={50 - i * 4}
                rx="3"
                fill={j % 3 === 0 ? "#b6b38c" : "#63836d"}
                opacity=".5"
              />
            </g>
          ))}
        </g>
      ))}
      {[0, 1, 2].map((i) => (
        <path
          key={i}
          d={`M${420 + i * 210} 80H${560 + i * 170}L${800 + i * 80} 360H${730 + i * 100}Z`}
          fill="#d8e3b7"
          opacity=".3"
        />
      ))}
      <path
        d="M730 1080L885 650M1190 1080L1035 650"
        stroke="#b8c99b"
        strokeWidth="1"
        opacity=".15"
      />
    </g>
  );
}
function Home({ t }: { t: number }) {
  return (
    <g>
      <rect width="1920" height="1080" fill="#212b27" />
      <rect
        x="170"
        y="120"
        width="670"
        height="750"
        fill="#172326"
        stroke="#5b6652"
        strokeWidth="14"
      />
      <circle cx="580" cy="300" r="68" fill="#d6c8a3" opacity=".7" />
      {Array.from({ length: 11 }, (_, i) => (
        <path
          key={i}
          d={`M${i * 82 + 180} 850V${650 - (i % 4) * 60}h65v${200 + (i % 4) * 60}`}
          fill="#0a1719"
        />
      ))}
      <path d="M504 120V870M170 510H840" stroke="#666b55" strokeWidth="16" />
      <path
        d="M120 80Q220 450 110 1000H285Q350 530 280 80Z"
        fill="#82745b"
        opacity=".5"
      />
      <path
        d="M820 80Q740 550 890 1000H1010Q860 520 995 80Z"
        fill="#82745b"
        opacity=".4"
      />
      <rect x="1240" y="785" width="16" height="230" fill="#b8a47c" />
      <path d="M1150 780L1195 600H1320L1370 780Z" fill="#dac08c" />
      <ellipse
        cx="1260"
        cy="810"
        rx="230"
        ry="100"
        fill="#e0b26a"
        opacity=".07"
      />
      <path
        d="M1030 1000Q1120 850 1300 940L1590 900Q1740 900 1830 1080H1030Z"
        fill="#a98559"
        opacity=".4"
      />
      {Array.from({ length: 14 }, (_, i) => (
        <circle
          key={i}
          cx={(i * 133 + 70) % 1920}
          cy={(i * 177 - t * 8) % 1080}
          r="2"
          fill="#e3c18c"
          opacity=".25"
        />
      ))}
    </g>
  );
}
function Jazz({ t, e }: { t: number; e: number }) {
  return (
    <g>
      <circle
        cx="1280"
        cy="500"
        r={330 + e * 12}
        fill="#d8b17a"
        opacity=".14"
      />
      <circle
        cx="1280"
        cy="500"
        r="270"
        stroke="#d8b17a"
        strokeWidth="1"
        fill="none"
        opacity=".4"
      />
      {Array.from({ length: 6 }, (_, i) => (
        <ellipse
          key={i}
          cx="1280"
          cy="500"
          rx={190 + i * 22}
          ry={190 + i * 22}
          fill="none"
          stroke="#c9b994"
          opacity=".12"
        />
      ))}
      <g
        transform={`translate(1250 400) rotate(${-15 + Math.sin(t * 0.4) * 2})`}
      >
        <path
          d="M20 -280H45V-50Q155 -10 135 110Q220 230 130 350Q30 450-70 350Q-170 260-70 120Q-100 20 0-50Z"
          fill="#9d7148"
          stroke="#e6c48b"
          strokeWidth="2"
        />
        <path
          d="M13 -290L3 330M26 -290L26 340M39 -290L49 330M52 -290L72 320"
          stroke="#e8d7a9"
          opacity=".6"
          strokeWidth="2"
        />
        <path
          d="M-60 200Q-100 220-65 260M95 200Q130 220 98 260"
          stroke="#241e1a"
          fill="none"
          strokeWidth="7"
        />
      </g>
      <g transform={`translate(420 720) rotate(${Math.sin(t * 0.4) * 4 - 25})`}>
        <path
          d="M0 -360H35V-40Q35 80 120 40L185 0L225 100Q80 190-20 100Q-55 60-55-40V-320Q-55-370 0-360Z"
          fill="#bda16c"
          opacity=".7"
        />
        <ellipse cx="210" cy="48" rx="40" ry="63" fill="#e1c58f" />
        <ellipse cx="210" cy="48" rx="24" ry="44" fill="#313c30" />
        {[0, 1, 2, 3, 4].map((i) => (
          <circle key={i} cx="0" cy={-270 + i * 40} r="9" fill="#eee0b7" />
        ))}
      </g>
    </g>
  );
}
function Receipt({ t, section }: { t: number; section: string }) {
  const items =
    section === "bills"
      ? ["INSURANCE", "INTERNET", "PHONE", "GAS"]
      : ["BREAD", "MILK", "EGGS", "CHIPS"];
  return (
    <g
      transform={`translate(${140 + Math.sin(t * 0.15) * 10} ${180 + Math.sin(t * 0.2) * 8}) rotate(-8 220 330)`}
      opacity=".6"
    >
      <path
        d="M0 0H425V660L405 647L385 660L365 647L345 660L325 647L305 660L285 647L265 660L245 647L225 660L205 647L185 660L165 647L145 660L125 647L105 660L85 647L65 660L45 647L25 660L0 647Z"
        fill="#ded7ba"
      />
      <text
        x="212"
        y="65"
        textAnchor="middle"
        fill="#233b30"
        fontFamily="monospace"
        fontSize="25"
        letterSpacing="3"
      >
        {section === "bills" ? "MONTHLY STATEMENT" : "EVERYDAY MARKET"}
      </text>
      <path d="M35 105H390M35 450H390" stroke="#435548" strokeDasharray="8 6" />
      {items.map((s, i) => (
        <g key={s}>
          <text
            x="40"
            y={175 + i * 65}
            fontFamily="monospace"
            fontSize="21"
            fill="#34473b"
          >
            {s}
          </text>
          <text
            x="380"
            y={175 + i * 65}
            textAnchor="end"
            fontFamily="monospace"
            fontSize="21"
            fill="#34473b"
          >
            {["3.29", "5.79", "4.49", "—"][i]}
          </text>
        </g>
      ))}
      <text x="40" y="510" fontFamily="monospace" fontSize="21" fill="#34473b">
        AVAILABLE
      </text>
      <text
        x="380"
        y="564"
        fontFamily="monospace"
        fontSize="42"
        textAnchor="end"
        fill="#34473b"
      >
        $4.73
      </text>
      {Array.from({ length: 65 }, (_, i) => (
        <rect
          key={i}
          x={40 + i * 5.2}
          y="600"
          width={i % 3 === 0 ? 3 : 1}
          height="25"
          fill="#34473b"
        />
      ))}
    </g>
  );
}
function World({ scene, t, e }: { scene: Scene; t: number; e: number }) {
  const env = scene.environment;
  return (
    <svg
      width="100%"
      height="100%"
      viewBox="0 0 1920 1080"
      preserveAspectRatio="xMidYMid slice"
    >
      <defs>
        <radialGradient id="halo">
          <stop
            stopColor={env === "home" ? "#bc8546" : "#78a581"}
            stopOpacity=".27"
          />
          <stop offset="1" stopColor="#122321" stopOpacity="0" />
        </radialGradient>
        <pattern id="grid" width="80" height="80" patternUnits="userSpaceOnUse">
          <path d="M80 0H0V80" stroke="#b8c99b" strokeWidth="1" opacity=".05" />
        </pattern>
      </defs>
      <rect width="1920" height="1080" fill="#122321" />
      <rect width="1920" height="1080" fill="url(#grid)" />
      {env === "grocery" && <Grocery t={t} />}
      {env === "home" && <Home t={t} />}
      {env === "jazz" && <Jazz t={t} e={e} />}
      {env === "bills" && <Receipt t={t} section="bills" />}
      {["hook", "final", "balance", "bridge", "outro"].includes(env) && (
        <>
          <circle
            cx={1280 + Math.sin(t * 0.15) * 50}
            cy="460"
            r="650"
            fill="url(#halo)"
          />
          {Array.from({ length: 7 }, (_, i) => (
            <circle
              key={i}
              cx="1380"
              cy="510"
              r={140 + i * 65 + e * 4}
              stroke="#b8c99b"
              strokeWidth="1"
              fill="none"
              opacity={0.07 + i * 0.015}
            />
          ))}
          <text
            x="1110"
            y="720"
            fontFamily="Editorial,serif"
            fontSize="600"
            fill="#dbe3bb"
            opacity={env === "balance" ? 0.025 : 0.05}
            textAnchor="middle"
          >
            4.73
          </text>
          <path
            d="M0 890Q480 720 960 870T1920 790"
            stroke="#b8c99b"
            fill="none"
            opacity=".2"
          />
          {[0, 1, 2, 3, 4].map((i) => (
            <path
              key={i}
              d={`M0 ${930 + i * 30}Q480 ${760 + i * 30} 960 ${910 + i * 30}T1920 ${830 + i * 30}`}
              stroke="#b8c99b"
              fill="none"
              opacity=".08"
            />
          ))}
        </>
      )}
      {env === "grocery" && (
        <g opacity=".22" transform="translate(1410 520) rotate(9)">
          <rect width="250" height="400" fill="#e3dbbf" />
          <path
            d="M25 70H220M25 110H220M25 150H220M25 190H150M25 280H220"
            stroke="#324b3b"
            strokeWidth="5"
          />
        </g>
      )}
    </svg>
  );
}
export const FinanceFilm: React.FC<{ project: Project }> = ({ project: p }) => {
  const frame = useCurrentFrame(),
    { fps, width, height } = useVideoConfig(),
    t = frame / fps;
  const si = Math.max(
      0,
      p.scenes.findIndex((s) => t >= s.start && t < s.end),
    ),
    scene = p.scenes[si];
  const line = p.lines.find((l) => t >= l.start && t < l.end);
  const env = scene.environment;
  const e = p.analysis.energy[Math.floor(t * 20)] || 0;
  let beat = -10;
  for (const b of p.analysis.beats) {
    if (b > t) break;
    beat = b;
  }
  const pulse = Math.exp(-(t - beat) * 14) * e * p.intensity;
  const sectionT = t - scene.start;
  const phraseT = line ? t - line.start : 0;
  const special =
    line &&
    /^(Nice\.|Yeah\?|Cancel\.|Cancel that|Financially speaking|Still|I'd like some money|Let's not get|LOW BALANCE|Yeah\.|I know)/i.test(
      line.text,
    );
  const money =
    line &&
    /^(Four dollars|and seventy|Four seventy|Than four)/i.test(line.text);
  const intro = env === "balance";
  const size = money ? width * 0.076 : special ? width * 0.071 : width * 0.048;
  const progress = line ? clamp(phraseT / 0.24) : 0;
  const fade = line
    ? Math.min(ease(phraseT / 0.18), clamp((line.end - t) / 0.13))
    : 0;
  const warm = ["home", "bridge", "final"].includes(env);
  const accent = warm ? C.gold : p.accent;
  const camera = 1.025 + (sectionT / (scene.end - scene.start)) * 0.035;
  return (
    <AbsoluteFill
      style={{
        background: C.ink,
        color: C.cream,
        overflow: "hidden",
        fontFamily: "Display, sans-serif",
      }}
    >
      <style>{`@font-face{font-family:Editorial;src:url('${staticFile("fonts/Editorial.ttf")}')}@font-face{font-family:Receipt;src:url('${staticFile("fonts/Receipt.ttf")}')}@font-face{font-family:Display;src:url('${staticFile("fonts/Display.ttf")}')}`}</style>
      <Audio src={p.audio} />
      <AbsoluteFill
        style={{
          transform: `scale(${camera + pulse * 0.003}) translate(${Math.sin(t * 0.12) * 0.3}%,${Math.cos(t * 0.1) * 0.25}%) rotate(${scene.camera === "orbit" ? Math.sin(t * 0.2) * 0.35 : 0}deg)`,
        }}
      >
        <Img
          src={staticFile(`plates/${env}.jpg`)}
          style={{ width: "100%", height: "100%", objectFit: "cover" }}
        />
      </AbsoluteFill>
      <AbsoluteFill
        style={{
          background:
            "linear-gradient(0deg,rgba(6,15,15,.8),transparent 33%,rgba(6,15,15,.18)),radial-gradient(ellipse at center,transparent 15%,rgba(5,12,12,.6))",
        }}
      />
      {env === "bills" && (
        <AbsoluteFill
          style={{
            background:
              "linear-gradient(90deg,transparent,rgba(11,22,21,.55) 40%,rgba(11,22,21,.35))",
          }}
        />
      )}
      <div
        style={{
          position: "absolute",
          top: "8.1%",
          left: "7.8%",
          right: "7.8%",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          color: accent,
          opacity: 0.6,
          fontFamily: "Receipt,monospace",
          fontSize: width * 0.009,
          letterSpacing: width * 0.0014,
        }}
      >
        <span>
          {intro
            ? "AVAILABLE BALANCE"
            : env === "outro"
              ? "ACCOUNT NOTIFICATION"
              : env === "jazz"
                ? "AFTER HOURS / INTERLUDE"
                : scene.label.toUpperCase()}
        </span>
        <span>{intro ? "CHECKING" : `04 : 73`}</span>
      </div>
      <div
        style={{
          position: "absolute",
          top: "12%",
          left: "7.8%",
          right: "7.8%",
          height: 1,
          background: accent,
          opacity: 0.19,
        }}
      />
      {line && (
        <AbsoluteFill
          style={{
            justifyContent: "center",
            alignItems: env === "bills" ? "flex-end" : "center",
            padding: env === "bills" ? "12% 9% 12% 34%" : "13% 12%",
            opacity: fade,
            transform: `translateY(${(1 - ease(progress)) * 16}px)`,
          }}
        >
          {intro && (
            <div
              style={{
                fontFamily: "Receipt",
                fontSize: width * 0.011,
                letterSpacing: 4,
                color: accent,
                marginBottom: height * 0.045,
                opacity: 0.6,
              }}
            >
              YOUR ACCOUNT. YOUR REALITY.
            </div>
          )}
          <div
            data-lyric={line.id}
            style={{
              maxWidth: "100%",
              textAlign: "center",
              display: "flex",
              justifyContent: "center",
              flexWrap: "wrap",
              gap: "0 .25em",
              lineHeight: money ? 1.05 : 1.3,
              fontFamily: special
                ? "Receipt,monospace"
                : money || warm
                  ? "Editorial,serif"
                  : "Display,sans-serif",
              fontSize: size,
              fontWeight: money || special || warm ? 400 : 700,
              letterSpacing: money ? width * -0.002 : width * -0.0007,
              textShadow: "0 3px 28px #081110",
            }}
          >
            {line.words.map((w, i) => {
              const active = t >= w.start - 0.04 && t < w.end,
                done = t >= w.end;
              return (
                <span
                  key={i}
                  style={{
                    display: "inline-block",
                    color: active ? accent : done ? C.cream : "#d3d7c9",
                    transform: `translateY(${active && money ? -2 : 0}px)`,
                    opacity:
                      line.preset === "typewriter" && t < w.start ? 0.12 : 1,
                  }}
                >
                  {w.text}
                </span>
              );
            })}
          </div>
          {special && (
            <div
              style={{
                height: 2,
                width: width * 0.04,
                background: accent,
                marginTop: height * 0.035,
                opacity: 0.8,
              }}
            />
          )}
          {money && (
            <div
              style={{
                fontFamily: "Receipt",
                fontSize: width * 0.009,
                letterSpacing: 4,
                color: accent,
                marginTop: height * 0.045,
                opacity: 0.6,
              }}
            >
              {env === "final"
                ? "MORE THAN A NUMBER"
                : "NO OVERDRAFT. NO APOLOGIES."}
            </div>
          )}
        </AbsoluteFill>
      )}
      {!line && env === "jazz" && (
        <div
          style={{
            position: "absolute",
            left: "11%",
            top: "39%",
            opacity: Math.min(clamp(sectionT / 2), clamp((scene.end - t) / 2)),
          }}
        >
          <div
            style={{
              fontFamily: "Receipt",
              fontSize: width * 0.011,
              color: C.gold,
              letterSpacing: 5,
            }}
          >
            LET IT BREATHE.
          </div>
          <div
            style={{
              fontFamily: "Editorial",
              fontSize: width * 0.071,
              lineHeight: 1.05,
              marginTop: height * 0.035,
            }}
          >
            Small change.
            <br />
            Big sound.
          </div>
        </div>
      )}
      {!line && ((t < 28.15 && t > 15.2) || t > 203) && (
        <AbsoluteFill
          style={{
            justifyContent: "center",
            alignItems: "center",
            opacity: Math.min(
              clamp((t - (t > 203 ? 203 : 15.2)) / 1.5),
              clamp(((t > 203 ? p.duration : 28.15) - t) / 1.2),
            ),
          }}
        >
          <div
            style={{
              fontFamily: "Receipt",
              fontSize: width * 0.011,
              letterSpacing: 5,
              color: accent,
              marginBottom: height * 0.04,
            }}
          >
            {t > 203 ? "TONIGHT’S REALITY" : "A LITTLE MONEY. A WHOLE LIFE."}
          </div>
          <div
            style={{
              fontFamily: "Editorial",
              fontSize: width * 0.078,
              textAlign: "center",
              lineHeight: 1.08,
            }}
          >
            Four Dollars
            <br />
            <span style={{ color: accent }}>Seventy-Three</span>
          </div>
          <div
            style={{
              fontFamily: "Receipt",
              fontSize: width * 0.01,
              letterSpacing: 4,
              color: accent,
              marginTop: height * 0.05,
            }}
          >
            04 : 73
          </div>
        </AbsoluteFill>
      )}
      {env === "outro" && (
        <div
          style={{
            position: "absolute",
            left: "30%",
            right: "30%",
            top: "27%",
            height: 1,
            background: accent,
            opacity: 0.15,
          }}
        />
      )}
      <div
        style={{
          position: "absolute",
          bottom: "8%",
          left: "8%",
          right: "8%",
          display: "flex",
          alignItems: "center",
          gap: width * 0.016,
          opacity: 0.4,
        }}
      >
        <span
          style={{
            fontFamily: "Receipt",
            fontSize: width * 0.008,
            letterSpacing: 2,
            color: accent,
          }}
        >
          CAD
        </span>
        <div
          style={{ height: 1, background: accent, flex: 1, opacity: 0.35 }}
        />
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: width * 0.0015,
            height: height * 0.025,
          }}
        >
          {Array.from({ length: 24 }, (_, i) => (
            <i
              key={i}
              style={{
                display: "block",
                width: width * 0.001,
                height:
                  height * 0.003 +
                  e * Math.abs(Math.sin(t * 3 + i * 1.8)) * height * 0.02,
                background: accent,
              }}
            />
          ))}
        </div>
        <span
          style={{
            fontFamily: "Receipt",
            fontSize: width * 0.008,
            color: accent,
          }}
        >
          $4.73
        </span>
      </div>
      <AbsoluteFill
        style={{
          background:
            "repeating-linear-gradient(0deg,transparent,transparent 3px,rgba(0,0,0,.025) 4px)",
          pointerEvents: "none",
        }}
      />
      {si > 0 && (
        <AbsoluteFill
          style={{
            background: C.ink,
            opacity: (1 - clamp(sectionT / 0.3)) * 0.65,
            pointerEvents: "none",
          }}
        />
      )}
      <AbsoluteFill
        style={{
          background: C.ink,
          opacity: 1 - Math.min(clamp(t / 0.4), clamp((p.duration - t) / 1.2)),
          pointerEvents: "none",
        }}
      />
    </AbsoluteFill>
  );
};

export const FinancePlate: React.FC<{ environment: string }> = ({
  environment,
}) => (
  <AbsoluteFill style={{ background: C.ink }}>
    <World
      scene={{
        id: "plate",
        start: 0,
        end: 1,
        label: "",
        environment,
        energy: 0.5,
        camera: "dolly",
        effects: 0.35,
      }}
      t={0}
      e={0.6}
    />
  </AbsoluteFill>
);
