import React from "react";
import {
  AbsoluteFill,
  Audio,
  useCurrentFrame,
  useVideoConfig,
  interpolate,
} from "remotion";
import { FinanceFilm } from "./FinanceFilm";
import type { Project } from "./model";
const clamp = (n: number) => Math.max(0, Math.min(1, n));
const GenericVideo: React.FC<{ project: Project }> = ({ project: p }) => {
  const f = useCurrentFrame(),
    { fps, width, height } = useVideoConfig(),
    t = f / fps;
  const scene = p.scenes.find((s) => t >= s.start && t < s.end) || p.scenes[0];
  const line = p.lines.find((l) => t >= l.start && t < l.end);
  const energy =
    p.analysis.energy[
      Math.min(p.analysis.energy.length - 1, Math.floor(t * 20))
    ] || 0;
  const beat = p.analysis.beats.reduce((a, b) => (b <= t ? b : a), -10);
  const pulse =
    Math.exp(-(t - beat) * 12) *
    energy *
    p.intensity *
    (0.5 + (scene?.energy || 0.5));
  const palette =
    p.style === "golden"
      ? ["#171a1b", "#a16f43", "#efd6a7"]
      : p.style === "industrial"
        ? ["#100d15", "#642f31", p.accent]
        : ["#070e20", "#23404c", p.accent];
  const si = p.scenes.indexOf(scene);
  const enter = line ? clamp((t - line.start) * 4) : 0;
  const exit = line ? clamp((line.end - t) * 5) : 0;
  const phase = t * 0.12;
  const camera =
    scene?.camera === "orbit"
      ? Math.sin(t * 0.3) * 3
      : Math.sin(t * 0.16) * 1.1;
  return (
    <AbsoluteFill
      style={{
        background: palette[0],
        color: "#fff",
        fontFamily: p.font || "Arial",
        overflow: "hidden",
      }}
    >
      {p.audio && <Audio src={p.audio} />}
      <AbsoluteFill
        style={{
          transform: `scale(${1.04 + (t / p.duration) * 0.08 + pulse * 0.025}) rotate(${camera}deg)`,
          background: `radial-gradient(ellipse at ${35 + Math.sin(phase) * 25}% ${30 + si * 12}%, ${palette[1]} 0%, transparent 60%),linear-gradient(${130 + si * 30}deg,${palette[0]},#0a101b 60%,${palette[1]})`,
        }}
      >
        <svg
          width="100%"
          height="100%"
          viewBox="0 0 1920 1080"
          preserveAspectRatio="xMidYMid slice"
          style={{ position: "absolute", opacity: 0.65 }}
        >
          <defs>
            <linearGradient id="beam">
              <stop stopColor={p.accent} stopOpacity="0" />
              <stop offset=".5" stopColor={p.accent} stopOpacity=".3" />
              <stop offset="1" stopColor={p.accent} stopOpacity="0" />
            </linearGradient>
          </defs>
          {Array.from({ length: 11 }, (_, i) => (
            <g
              key={i}
              transform={`translate(${960 + Math.sin(t * 0.13 + i) * 30},${540 + Math.cos(t * 0.15) * 20}) rotate(${i * 9 + si * 13 + t * 0.5})`}
            >
              <ellipse
                rx={240 + i * 100}
                ry={120 + i * 65}
                fill="none"
                stroke={i % 3 === 0 ? p.accent : "#5e7d88"}
                strokeWidth={i % 3 === 0 ? 1.7 : 0.6}
                opacity={0.12 + energy * 0.1}
              />
            </g>
          ))}
          {Array.from({ length: 7 }, (_, i) => (
            <path
              key={i}
              d={`M ${-400 + i * 420} -200 L ${400 + i * 240} 1300 L ${700 + i * 240} 1300 Z`}
              fill="url(#beam)"
              opacity={0.15 + pulse * 0.4}
            />
          ))}
          <path
            d={`M0 820 Q480 ${620 + Math.sin(t * 0.2) * 80} 960 840 T1920 760 V1080 H0Z`}
            fill="#060b13"
            opacity=".6"
          />
        </svg>
        {Array.from({ length: 80 }, (_, i) => {
          const x = (i * 127.71) % 100,
            y =
              ((i * 73.13 +
                t * (p.style === "neon" ? 18 : 1.5) * (1 + (i % 3))) %
                120) -
              10;
          return (
            <div
              key={i}
              style={{
                position: "absolute",
                left: `${x}%`,
                top: `${y}%`,
                width: p.style === "neon" ? 1 : 2 + (i % 3),
                height: p.style === "neon" ? 35 : 2 + (i % 3),
                background: p.accent,
                opacity: (0.08 + (i % 5) * 0.07) * (scene?.effects || 0.4),
                boxShadow: `0 0 12px ${p.accent}`,
                transform: "rotate(15deg)",
              }}
            />
          );
        })}
      </AbsoluteFill>
      <AbsoluteFill
        style={{
          background:
            "radial-gradient(ellipse,transparent 25%,rgba(0,0,0,.65))",
        }}
      />
      <div
        style={{
          position: "absolute",
          left: "8%",
          top: "9%",
          fontSize: Math.max(12, width * 0.009),
          letterSpacing: 5,
          color: p.accent,
          opacity: 0.7,
        }}
      >
        {p.branding ? p.artist : " "}
      </div>
      {!line && (
        <AbsoluteFill
          style={{
            justifyContent: "center",
            alignItems: "center",
            opacity: clamp(t * 1.3) * clamp((p.duration - t) * 1.5),
          }}
        >
          <div
            style={{
              fontSize: width * 0.012,
              letterSpacing: 8,
              color: p.accent,
            }}
          >
            A SONIC STUDY
          </div>
          <h1
            style={{
              fontSize: width * 0.055,
              letterSpacing: width * 0.008,
              fontWeight: 300,
            }}
          >
            {p.title.toUpperCase()}
          </h1>
        </AbsoluteFill>
      )}
      {line && (
        <AbsoluteFill
          style={{
            justifyContent: "center",
            alignItems: "center",
            padding: "12%",
            opacity: enter * exit,
            transform: `translateY(${line.preset === "rise" ? (1 - enter) * 65 : Math.sin(t * 0.6) * (line.preset === "drift" ? 18 : 5)}px) scale(${line.preset === "impact" ? 1 + (1 - enter) * 0.18 + pulse * 0.04 : 1 + pulse * 0.01})`,
            filter: `blur(${(1 - enter) * 8}px)`,
          }}
        >
          <div
            style={{
              fontSize: Math.min(
                width * 0.055,
                height * 0.09,
                (width * 1.22) / Math.max(12, line.text.length),
              ),
              fontWeight: line.preset === "impact" ? 900 : 600,
              letterSpacing: line.preset === "cinematic" ? width * 0.002 : 0,
              lineHeight: 1.25,
              textAlign: "center",
              maxWidth: "100%",
              textShadow: "0 4px 32px #000",
              display: "flex",
              flexWrap: "wrap",
              gap: "0 .28em",
              justifyContent: "center",
            }}
          >
            {line.words.map((w, i) => {
              const active = t >= w.start && t < w.end,
                done = t >= w.end;
              return (
                <span
                  key={i}
                  style={{
                    display: "inline-block",
                    color: active ? p.accent : done ? "#f1f2ec" : "#a2acb6",
                    opacity:
                      line.preset === "typewriter" && t < w.start ? 0 : 1,
                    transform: `translateY(${active ? -3 : 0}px) ${line.preset === "orbit" ? `rotate(${Math.sin(t + i) * 2}deg)` : ""} ${line.preset === "glitch" && active ? `translateX(${Math.sin(f * 3) * pulse * 8}px)` : ""}`,
                    textShadow:
                      line.preset === "neon" || active
                        ? `0 0 ${active ? 24 : 8}px ${p.accent}66`
                        : "none",
                  }}
                >
                  {w.text}
                </span>
              );
            })}
          </div>
          <div
            style={{
              marginTop: height * 0.04,
              width: width * 0.035,
              height: 2,
              background: p.accent,
              opacity: 0.7,
            }}
          />
        </AbsoluteFill>
      )}
      <div
        style={{
          position: "absolute",
          bottom: "8%",
          left: "8%",
          right: "8%",
          height: height * 0.055,
          display: "flex",
          gap: 3,
          alignItems: "center",
          opacity: 0.35,
        }}
      >
        {Array.from({ length: 90 }, (_, i) => (
          <div
            key={i}
            style={{
              flex: 1,
              height:
                2 +
                Math.abs(Math.sin(i * 3.7 + t * 2)) * energy * height * 0.04,
              background: i % 7 === 0 ? p.accent : "#abc2c9",
            }}
          />
        ))}
      </div>
      {p.branding && (
        <div
          style={{
            position: "absolute",
            right: "8%",
            top: "9%",
            fontSize: width * 0.009,
            letterSpacing: 3,
            opacity: 0.5,
          }}
        >
          {p.title}
        </div>
      )}
      <AbsoluteFill
        style={{
          background: "#000",
          opacity: 1 - Math.min(clamp(t * 2), clamp((p.duration - t) * 2)),
          pointerEvents: "none",
        }}
      />
    </AbsoluteFill>
  );
};

export const Video: React.FC<{ project: Project }> = ({ project }) =>
  project.style === "finance" ? (
    <FinanceFilm project={project} />
  ) : (
    <GenericVideo project={project} />
  );
