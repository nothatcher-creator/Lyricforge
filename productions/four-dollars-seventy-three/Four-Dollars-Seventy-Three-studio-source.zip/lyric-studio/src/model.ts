export type Word = {
  text: string;
  start: number;
  end: number;
  review: boolean;
};
export type Line = {
  id: string;
  text: string;
  start: number;
  end: number;
  words: Word[];
  preset: string;
};
export type Scene = {
  id: string;
  start: number;
  end: number;
  label: string;
  environment: string;
  energy: number;
  camera: string;
  effects: number;
};
export type Project = {
  version: 1;
  id: string;
  title: string;
  artist: string;
  audio: string;
  duration: number;
  lyrics: string;
  lines: Line[];
  scenes: Scene[];
  analysis: {
    bpm: number;
    beats: number[];
    energy: number[];
    waveform: number[];
    peak: number;
    method: string;
  };
  style: string;
  accent: string;
  intensity: number;
  font: string;
  branding: boolean;
  approved: boolean;
  settings: { width: number; height: number; fps: number };
  treatment: string;
  history: string[];
};
export const presets = [
  "cinematic",
  "rise",
  "impact",
  "glitch",
  "typewriter",
  "orbit",
  "neon",
  "drift",
];
export function align(lyrics: string, duration: number): Line[] {
  const lines = lyrics.split("\n").filter((l) => l.trim());
  const total = lines.reduce((s, l) => s + l.split(/\s+/).length, 0);
  let cursor = Math.min(1, duration * 0.05);
  const unit = (duration - cursor - 0.5) / Math.max(1, total);
  return lines.map((text, i) => {
    const start = cursor;
    const words = text
      .trim()
      .split(/\s+/)
      .map((text) => {
        const start = cursor;
        cursor += unit;
        return { text, start, end: cursor, review: true };
      });
    return {
      id: `line-${i}`,
      text,
      start,
      end: cursor,
      words,
      preset: presets[i % presets.length],
    };
  });
}
export function direct(p: Project, instruction: string): Project {
  const q = structuredClone(p),
    s = instruction.toLowerCase();
  const target = /chorus/.test(s)
    ? q.scenes.filter((x) => /chorus/i.test(x.label))
    : /bridge/.test(s)
      ? q.scenes.filter((x) => /bridge/i.test(x.label))
      : q.scenes;
  let changed = false;
  if (/aggressive|heavier|push it further/.test(s)) {
    target.forEach((x) => {
      x.energy = Math.min(1, x.energy + 0.2);
      x.effects = Math.min(1, x.effects + 0.15);
    });
    q.intensity = Math.min(1, q.intensity + 0.15);
    changed = true;
  }
  if (/dark/.test(s)) {
    q.style = "industrial";
    q.accent = "#ff754f";
    changed = true;
  }
  if (/neon|rain/.test(s)) {
    q.style = "neon";
    q.accent = "#76e5f5";
    target.forEach((x) => (x.environment = "neon"));
    changed = true;
  }
  if (/golden|warm|acoustic/.test(s)) {
    q.style = "golden";
    q.accent = "#f5cb87";
    changed = true;
  }
  if (/camera|orbit/.test(s)) {
    target.forEach((x) => (x.camera = /orbit/.test(s) ? "orbit" : "drift"));
    changed = true;
  }
  if (/professional|cinematic/.test(s)) {
    target.forEach((x) => (x.effects = Math.min(x.effects, 0.55)));
    q.lines.forEach((l) => (l.preset = "cinematic"));
    changed = true;
  }
  if (!changed)
    throw Error(
      "Instruction not recognized. Try darker, neon rain, warmer, heavier chorus, orbit camera, or make it professional. You can edit every project field in JSON through Codex.",
    );
  q.history.push(instruction);
  q.approved = false;
  return q;
}
export function qc(p: Project): string[] {
  const issues: string[] = [];
  if (!p.audio) issues.push("Missing audio");
  if (!p.lines.length) issues.push("No lyric cues");
  p.lines.forEach((l, i) => {
    if (
      !Number.isFinite(l.start) ||
      !Number.isFinite(l.end) ||
      l.start < 0 ||
      l.end <= l.start ||
      l.end > p.duration + 0.05
    )
      issues.push(`Invalid timing: line ${i + 1}`);
    if (i && l.start < p.lines[i - 1].end - 0.01)
      issues.push(`Overlapping phrases: line ${i + 1}`);
    if (l.text.length > 110)
      issues.push(`Long phrase: line ${i + 1}; split for readability`);
    l.words.forEach((w, j) => {
      if (
        !Number.isFinite(w.start) ||
        !Number.isFinite(w.end) ||
        w.start < l.start - 0.01 ||
        w.end > l.end + 0.01 ||
        w.end <= w.start
      )
        issues.push(`Word outside phrase: ${w.text}`);
      if (j && w.start < l.words[j - 1].end - 0.01)
        issues.push(`Overlapping words: line ${i + 1}`);
    });
  });
  if (p.lines.some((l) => l.words.some((w) => w.review)))
    issues.push("Estimated lyric timing requires listening review");
  if (p.analysis.peak >= 0.999)
    issues.push("Audio approaches full scale; inspect clipping");
  if (!p.approved) issues.push("Creative treatment awaits approval");
  return [...new Set(issues)];
}
