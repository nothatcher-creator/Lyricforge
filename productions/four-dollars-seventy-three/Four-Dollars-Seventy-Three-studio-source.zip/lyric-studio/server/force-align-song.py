import sys,json,re,os
sys.path.insert(0,str(__import__('pathlib').Path(__file__).resolve().parent))
from ctc_alignment import CpuAligner,decode_audio,transcript_tokens,force_align,words_from_path
os.environ['ALIGN_THREADS']='2'
a=CpuAligner();a.load()
wave=decode_audio('public/media/four-dollars-seventy-three.mp3')
print('Extracting acoustic features',flush=True)
emissions,starts=a.emissions(wave)
import numpy as np
np.savez('projects/four-dollars-emissions.npz',emissions=emissions,starts=starts)
lines=[s for s in open('projects/four-dollars-lyrics.txt').read().splitlines() if s and not s.startswith('[')]
original=' '.join(lines).split()
spoken=' '.join(lines).replace('2023','twenty twenty three')
words,tokens,owners=transcript_tokens(spoken,a.vocab)
print('Aligning',len(words),'words',len(emissions),'frames',flush=True)
path=force_align(emissions,tokens,a.vocab.get('<pad>',0))
result=words_from_path(emissions,path,tokens,owners,words,starts,len(wave)/16000,min_word_confidence=0,min_mean_confidence=0)
# Merge the spoken three-word year back into the supplied literal 2023.
for i in range(len(result)-2):
 if [w['text'] for w in result[i:i+3]]==['twenty','twenty','three']:
  result[i:i+3]=[{'text':'2023','start':result[i]['start'],'end':result[i+2]['end'],'confidence':min(w['confidence'] for w in result[i:i+3])}];break
assert [w['text'] for w in result]==original
json.dump(result,open('projects/four-dollars-forced-words.json','w'),indent=2)
print('Completed exact supplied-word alignment',len(result),flush=True)
