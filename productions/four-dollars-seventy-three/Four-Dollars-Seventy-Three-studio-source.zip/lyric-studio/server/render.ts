import { bundle } from "@remotion/bundler";
import { renderMedia, selectComposition } from "@remotion/renderer";
import path from "node:path";
import type { Project } from "../src/model";
let cached: Promise<string> | undefined;
export async function render(
  p: Project,
  file: string,
  progress: (n: number) => void,
) {
  cached ||= bundle({
    entryPoint: path.resolve("src/remotion.tsx"),
    publicDir: path.resolve("public"),
  }).catch((e) => {
    cached = undefined;
    throw e;
  });
  const serveUrl = await cached;
  const project = structuredClone(p);
  project.audio = `http://127.0.0.1:3100${p.audio}`;
  const inputProps = { project };
  const composition = await selectComposition({
    serveUrl,
    id: "LyricVideo",
    inputProps,
    browserExecutable: "/usr/bin/chromium",
  });
  await renderMedia({
    composition,
    serveUrl,
    codec: "h264",
    audioCodec: "aac",
    audioBitrate: "320k",
    outputLocation: file,
    inputProps,
    browserExecutable: "/usr/bin/chromium",
    concurrency: 2,
    crf: 18,
    onProgress: (x) => progress(x.progress),
  });
}
