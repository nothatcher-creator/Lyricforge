import fs from "node:fs/promises";
import { bundle } from "@remotion/bundler";
import {
  selectComposition,
  renderMedia,
  renderStill,
} from "@remotion/renderer";
import path from "node:path";
import type { Project } from "../src/model";
const p: Project = JSON.parse(
  await fs.readFile("projects/four-dollars-seventy-three.json", "utf8"),
);
const mode = process.argv[2] || "stills";
const serveUrl = await bundle({
  entryPoint: path.resolve("src/remotion.tsx"),
  publicDir: path.resolve("public"),
});
p.audio = `http://127.0.0.1:3100${p.audio}`;
const inputProps = { project: p };
const composition = await selectComposition({
  serveUrl,
  id: "LyricVideo",
  inputProps,
  browserExecutable: "/usr/bin/chromium",
});
if (mode === "poster") {
  await renderStill({
    serveUrl,
    composition,
    inputProps,
    frame: 20 * p.settings.fps,
    output: "exports/Four-Dollars-Seventy-Three-poster.png",
    browserExecutable: "/usr/bin/chromium",
  });
} else if (mode === "stills") {
  for (const t of [7.8, 30, 44.5, 67, 87, 97, 122, 141, 155, 175, 213]) {
    await renderStill({
      serveUrl,
      composition,
      inputProps,
      frame: Math.round(t * p.settings.fps),
      output: `exports/four-dollars-${t}.png`,
      browserExecutable: "/usr/bin/chromium",
    });
    console.log("Still", t);
  }
} else {
  let last = -1;
  await renderMedia({
    serveUrl,
    composition,
    inputProps,
    codec: "h264",
    imageFormat: "jpeg",
    jpegQuality: 88,
    crf: 19,
    audioCodec: "aac",
    audioBitrate: "320k",
    pixelFormat: "yuv420p",
    outputLocation:
      mode === "bench"
        ? "exports/bench.mp4"
        : mode === "draft"
          ? "exports/four-dollars-draft.mp4"
          : "exports/Four-Dollars-Seventy-Three.mp4",
    ...(mode === "bench" ? { frameRange: [720, 815] as [number, number] } : {}),
    scale: mode === "draft" ? 0.5 : 1,
    browserExecutable: "/usr/bin/chromium",
    concurrency: 2,
    x264Preset: "fast",
    onProgress: ({ progress, renderedFrames, encodedFrames }) => {
      const n = Math.floor(progress * 100);
      if (n !== last) {
        last = n;
        console.log(
          JSON.stringify({ percent: n, renderedFrames, encodedFrames }),
        );
      }
    },
  });
}
