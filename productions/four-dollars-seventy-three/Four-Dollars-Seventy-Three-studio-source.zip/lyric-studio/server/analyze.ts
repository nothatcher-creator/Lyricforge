import { execFile } from "node:child_process";
import { promisify } from "node:util";
const run = promisify(execFile);
export async function analyze(path: string) {
  const { stdout } = await run(
    "ffmpeg",
    [
      "-v",
      "error",
      "-i",
      path,
      "-ac",
      "1",
      "-ar",
      "8000",
      "-f",
      "f32le",
      "pipe:1",
    ],
    { encoding: "buffer", maxBuffer: 512 * 1024 * 1024 },
  );
  const data = new Float32Array(
    stdout.buffer,
    stdout.byteOffset,
    Math.floor(stdout.length / 4),
  );
  const hop = 400,
    energy: number[] = [],
    waveform: number[] = [];
  let peak = 0;
  for (let i = 0; i < data.length; i += hop) {
    let sum = 0,
      m = 0;
    for (let j = i; j < Math.min(data.length, i + hop); j++) {
      sum += data[j] ** 2;
      m = Math.max(m, Math.abs(data[j]));
    }
    energy.push(Math.sqrt(sum / hop));
    waveform.push(m);
    peak = Math.max(peak, m);
  }
  const max = Math.max(...energy, 0.001);
  const normalized = energy.map((x) => x / max);
  const onset = normalized.map((v, i) =>
    Math.max(0, v - (normalized[i - 1] || 0)),
  );
  let best = 0,
    lag = 10;
  for (let l = 7; l <= 20; l++) {
    let score = 0;
    for (let i = l; i < onset.length; i++) score += onset[i] * onset[i - l];
    if (score > best) {
      best = score;
      lag = l;
    }
  }
  const bpm = 60 / (lag * 0.05);
  let offset = 0;
  for (let i = 1; i < Math.min(lag, onset.length); i++)
    if (onset[i] > onset[offset]) offset = i;
  const duration = data.length / 8000;
  const beats = [];
  for (let t = offset * 0.05; t < duration; t += 60 / bpm) beats.push(t);
  return {
    duration,
    analysis: {
      bpm: Math.round(bpm * 10) / 10,
      beats,
      energy: normalized,
      waveform,
      peak,
      method:
        "RMS energy + onset autocorrelation; tempo and sections are estimates, not semantic music recognition",
    },
  };
}
