import sys,json,numpy as np
sys.path.insert(0,str(__import__('pathlib').Path(__file__).resolve().parent))
from ctc_alignment import CpuAligner,transcript_tokens,force_align,words_from_path
from pathlib import Path
vocab=json.loads(next(Path.home().glob('.cache/huggingface/hub/models--Xenova--wav2vec2-base-960h/snapshots/*/vocab.json')).read_text())
cache=np.load('projects/four-dollars-emissions.npz');emissions=cache['emissions'];starts=cache['starts']
raw=Path('projects/four-dollars-lyrics.txt').read_text().splitlines()
groups=[];group=[];section='Intro';kind=''
for line in raw:
 if line.startswith('['):
  label=line.strip('[]')
  if label in ['Intro','Verse 1','Hook','Verse 2','Verse 3','Bridge','Final Hook','Outro']:
   if group:groups.append((section,group));group=[]
   section=label
  elif label=='Beat cuts':
   groups.append((section,group));group=[];section='Aside'
 elif line:group.append(line)
if group:groups.append((section,group))
# Split the intro aside and the final notification response for independent anchors.
groups=[('Intro',groups[0][1][:3]),('Nice',groups[0][1][3:])]+groups[1:]
last=groups.pop();groups += [('Alert',last[1][:1]),('Yeah',last[1][1:2]),('I know',last[1][2:])]
bounds=[(3.8,11.5),(11.5,14.8),(28,62.8),(62.8,73.9),(74,96.3),(96.3,98.4),(99.5,110.2),(133.4,157.1),(157.1,169.1),(171.1,184.3),(193.3,195),(198.5,199.6),(199.6,201)]
assert len(bounds)==len(groups),(len(bounds),[(g,len(l)) for g,l in groups])
result=[];line_results=[]
for (section,lines),(start,end) in zip(groups,bounds):
 text=' '.join(lines).replace('2023','twenty twenty three')
 words,tokens,owners=transcript_tokens(text,vocab)
 mask=(starts>=start)&(starts<end);lp=emissions[mask];ss=starts[mask]
 path=force_align(lp,tokens,vocab.get('<pad>',0))
 aligned=words_from_path(lp,path,tokens,owners,words,ss,224.3735,min_word_confidence=0,min_mean_confidence=0)
 for i in range(len(aligned)-2):
  if [w['text'] for w in aligned[i:i+3]]==['twenty','twenty','three']:
   aligned[i:i+3]=[{'text':'2023','start':aligned[i]['start'],'end':aligned[i+2]['end'],'confidence':min(w['confidence'] for w in aligned[i:i+3])}];break
 cursor=0
 for text in lines:
  w=aligned[cursor:cursor+len(text.split())];cursor+=len(w)
  assert [x['text'] for x in w]==text.split()
  row={'section':section,'text':text,'start':w[0]['start'],'end':w[-1]['end'],'words':w}
  line_results.append(row)
  print(f"{row['start']:6.2f}–{row['end']:6.2f} {section:10} {text}",flush=True)
 result+=aligned
json.dump(line_results,open('projects/four-dollars-aligned-lines.json','w'),indent=2)
json.dump(result,open('projects/four-dollars-refined-words.json','w'),indent=2)
