import { bundle } from "@remotion/bundler";
import { renderStill, selectComposition } from "@remotion/renderer";
import fs from "node:fs/promises";
import path from "node:path";
await fs.mkdir("public/plates", { recursive: true });
const serveUrl = await bundle({
  entryPoint: path.resolve("src/remotion.tsx"),
  publicDir: path.resolve("public"),
});
for (const environment of [
  "balance",
  "grocery",
  "bills",
  "jazz",
  "home",
  "hook",
  "bridge",
  "final",
  "outro",
]) {
  const inputProps = { environment };
  const composition = await selectComposition({
    serveUrl,
    id: "FinancePlate",
    inputProps,
    browserExecutable: "/usr/bin/chromium",
  });
  await renderStill({
    serveUrl,
    composition,
    inputProps,
    frame: 0,
    imageFormat: "jpeg",
    jpegQuality: 95,
    output: `public/plates/${environment}.jpg`,
    browserExecutable: "/usr/bin/chromium",
  });
  console.log(environment);
}
