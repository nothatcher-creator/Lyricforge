import os,json,time
os.environ['HF_HUB_DISABLE_XET']='1'
from faster_whisper import WhisperModel
start=time.time()
model=WhisperModel('small.en',device='cpu',compute_type='int8',cpu_threads=6)
segments,info=model.transcribe('public/media/four-dollars-seventy-three.mp3',word_timestamps=True,beam_size=5,vad_filter=True,condition_on_previous_text=False)
result=[]
for segment in segments:
 item={'start':segment.start,'end':segment.end,'text':segment.text,'words':[{'text':w.word.strip(),'start':w.start,'end':w.end,'probability':w.probability} for w in (segment.words or [])]}
 result.append(item)
 print(json.dumps(item),flush=True)
 with open('projects/four-dollars-transcript.json','w') as f:json.dump({'language':info.language,'duration':info.duration,'segments':result},f,indent=2)
print('Elapsed',time.time()-start,flush=True)
