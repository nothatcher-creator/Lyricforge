import fs from "node:fs/promises";
import { analyze } from "./analyze";
const result = await analyze("public/media/four-dollars-seventy-three.mp3");
await fs.writeFile(
  "projects/four-dollars-analysis.json",
  JSON.stringify(result, null, 2),
);
console.log(result.duration, result.analysis.bpm, result.analysis.peak);
