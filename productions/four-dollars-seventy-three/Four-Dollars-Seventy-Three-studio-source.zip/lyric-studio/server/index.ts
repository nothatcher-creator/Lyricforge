import express from "express";
import multer from "multer";
import { createServer as viteServer } from "vite";
import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import { analyze } from "./analyze";
import { align, qc, Project } from "../src/model";
import { demo } from "../src/sample";
import { render } from "./render";
const app = express();
app.use(express.json({ limit: "20mb" }));
app.use("/media", express.static("public/media"));
app.use("/exports", express.static("exports"));
const upload = multer({
  dest: "public/media",
  limits: { fileSize: 250 * 1024 * 1024 },
});
const jobs = new Map<
  string,
  { status: string; progress: number; error?: string; url?: string }
>();
let rendering = false;
function validate(p: Project) {
  if (
    p.version !== 1 ||
    typeof p.title !== "string" ||
    !Array.isArray(p.lines) ||
    !Array.isArray(p.scenes) ||
    !Number.isFinite(p.duration) ||
    p.duration <= 0 ||
    p.duration > 7200 ||
    !/^\/media\/[\w.-]+$/.test(p.audio)
  )
    throw Error("Invalid project or local audio reference");
  if (
    ![24, 30, 60].includes(p.settings.fps) ||
    ![640, 1080, 1920, 3840].includes(p.settings.width) ||
    ![360, 1080, 1920, 2160, 640].includes(p.settings.height)
  )
    throw Error("Unsupported output dimensions or frame rate");
  return p;
}
app.get("/api/demo", (_, res) => res.json(demo));
app.get("/api/projects", async (_, res) =>
  res.json((await fs.readdir("projects")).filter((x) => x.endsWith(".json"))),
);
app.get("/api/projects/:id", async (req, res) => {
  try {
    res.json(
      JSON.parse(
        await fs.readFile(
          path.join("projects", path.basename(req.params.id)),
          "utf8",
        ),
      ),
    );
  } catch {
    res.status(404).json({ error: "Project not found" });
  }
});
app.post("/api/save", async (req, res) => {
  try {
    const p = validate(req.body);
    p.id = /^[\w-]+$/.test(p.id) ? p.id : crypto.randomUUID();
    await fs.writeFile(`projects/${p.id}.json.tmp`, JSON.stringify(p, null, 2));
    await fs.rename(`projects/${p.id}.json.tmp`, `projects/${p.id}.json`);
    res.json({ id: p.id });
  } catch (e) {
    res.status(400).json({ error: String(e) });
  }
});
app.post("/api/import", upload.single("audio"), async (req, res) => {
  try {
    if (!req.file) throw Error("Choose an audio file");
    const a = await analyze(req.file.path);
    const p: Project = {
      ...structuredClone(demo),
      id: crypto.randomUUID(),
      title: req.file.originalname.replace(/\.[^.]+$/, ""),
      audio: `/media/${req.file.filename}`,
      duration: a.duration,
      analysis: a.analysis,
      lyrics: req.body.lyrics || "",
      lines: align(req.body.lyrics || "", a.duration),
    };
    const count = Math.max(1, Math.ceil(a.duration / 16));
    p.scenes = Array.from({ length: count }, (_, i) => {
      const start = (i * a.duration) / count,
        end = ((i + 1) * a.duration) / count;
      const en = a.analysis.energy.slice(
        Math.floor(start * 20),
        Math.floor(end * 20),
      );
      const energy = en.reduce((s, n) => s + n, 0) / Math.max(1, en.length);
      return {
        id: `s${i}`,
        start,
        end,
        label:
          i === 0
            ? "Intro / verse"
            : i === count - 1
              ? "Outro"
              : energy > 0.65
                ? "Chorus candidate"
                : "Verse candidate",
        environment: p.style,
        energy,
        camera: energy > 0.65 ? "orbit" : "dolly",
        effects: 0.3 + energy * 0.4,
      };
    });
    p.treatment = `Estimated ${p.analysis.bpm} BPM. ${p.scenes.length} energy-based scenes in a nocturnal mint and ink palette. Quiet passages use drifting type and restrained particles; louder passages expand the camera and word accents. Section labels are suggestions. Supplied lyrics are preserved; all automatic word timing requires review.`;
    res.json(p);
  } catch (e) {
    if (req.file) await fs.unlink(req.file.path).catch(() => {});
    res.status(400).json({ error: String(e) });
  }
});
app.post("/api/render", async (req, res) => {
  try {
    if (rendering) throw Error("A render is already running");
    const p = validate(req.body);
    if (!p.approved)
      throw Error("Approve the creative treatment before rendering");
    const fatal = qc(p).filter((x) =>
      /Invalid|Overlapping|outside|Missing|No lyric/.test(x),
    );
    if (fatal.length) throw Error(fatal.join("; "));
    await fs.access(`public${p.audio}`);
    const id = crypto.randomUUID();
    const job = { status: "rendering", progress: 0 } as {
      status: string;
      progress: number;
      error?: string;
      url?: string;
    };
    jobs.set(id, job);
    await fs.writeFile(
      `exports/${id}.project.json`,
      JSON.stringify(p, null, 2),
    );
    rendering = true;
    res.json({ id });
    render(p, `exports/${id}.mp4`, (n) => (job.progress = n))
      .then(async () => {
        job.status = "done";
        job.url = `/exports/${id}.mp4`;
        await fs.writeFile(
          `exports/${id}.qc.json`,
          JSON.stringify(
            { warnings: qc(p), completed: new Date().toISOString() },
            null,
            2,
          ),
        );
      })
      .catch((e) => {
        job.status = "error";
        job.error = String(e);
      })
      .finally(() => {
        rendering = false;
      });
  } catch (e) {
    res.status(400).json({ error: String(e) });
  }
});
app.get("/api/jobs/:id", (req, res) =>
  res.json(
    jobs.get(req.params.id) || {
      status: "unknown",
      error:
        "Job unavailable after server restart. Saved render snapshot can be retried.",
    },
  ),
);
app.use((err: any, _req: any, res: any, _next: any) =>
  res.status(400).json({ error: err.message || String(err) }),
);
const vite = await viteServer({
  server: { middlewareMode: true },
  appType: "spa",
});
app.use(vite.middlewares);
app.listen(3100, "0.0.0.0", () =>
  console.log("NOCTURNE studio: http://localhost:3100"),
);
