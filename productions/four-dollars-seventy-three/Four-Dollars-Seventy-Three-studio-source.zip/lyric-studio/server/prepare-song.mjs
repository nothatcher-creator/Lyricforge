import { execFileSync } from "node:child_process";
import { existsSync } from "node:fs";
const input = "public/media/four-dollars-seventy-three.mp3";
if (!existsSync(input))
  throw Error("Place the original Four Dollars Seventy-Three.mp3 at " + input);
execFileSync(
  "ffmpeg",
  [
    "-v",
    "error",
    "-i",
    input,
    "-af",
    "volume=0.68",
    "-c:a",
    "pcm_s24le",
    "-y",
    "public/media/four-dollars-master.wav",
  ],
  { stdio: "inherit" },
);
console.log("Render master prepared. Original audio retained.");
