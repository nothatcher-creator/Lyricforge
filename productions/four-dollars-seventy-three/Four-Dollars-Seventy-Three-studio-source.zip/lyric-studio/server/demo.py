import wave, math, struct, random
random.seed(4)
sr=44100; duration=16
with wave.open('public/media/demo.wav','w') as w:
 w.setparams((1,2,sr,0,'NONE','not compressed'))
 for i in range(sr*duration):
  t=i/sr; beat=t%.5; chord=[110,130.81,87.31,98][int(t/4)%4]
  pad=sum(math.sin(2*math.pi*chord*r*t) for r in [1,1.5,2,3])*.055
  kick=math.sin(2*math.pi*(48*beat+8*(1-math.exp(-beat*40))))*math.exp(-beat*22)*.45
  hat=(random.random()*2-1)*math.exp(-(t%.25)*100)*.07
  lead=math.sin(2*math.pi*chord*4*t)*(.03+.025*math.sin(t*2))
  fade=min(1,t/1.5,(duration-t)/2)
  w.writeframesraw(struct.pack('<h',int(max(-1,min(1,(pad+kick+hat+lead)*fade))*32767)))
