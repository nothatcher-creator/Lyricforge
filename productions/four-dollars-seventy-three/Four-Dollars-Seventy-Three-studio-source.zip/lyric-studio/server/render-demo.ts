import { demo } from "../src/sample";
import { render } from "./render";
await render(
  { ...demo, approved: true, settings: { width: 640, height: 360, fps: 24 } },
  "exports/demo.mp4",
  (n) => {
    if (Math.round(n * 100) % 10 === 0)
      process.stdout.write(`${Math.round(n * 100)}% `);
  },
);
console.log("exports/demo.mp4");
