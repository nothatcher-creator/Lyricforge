import json,subprocess
from faster_whisper import WhisperModel
m=WhisperModel('small.en',device='cpu',compute_type='int8',cpu_threads=3)
all=[]
for name,start,end in [('intro',0,28),('chorus2',98,111),('outro',168,224.3735)]:
 file=f'projects/{name}-check.wav'
 subprocess.run(['ffmpeg','-v','error','-ss',str(start),'-i','public/media/four-dollars-seventy-three.mp3','-t',str(end-start),'-ar','16000','-ac','1','-y',file],check=True)
 segments,_=m.transcribe(file,word_timestamps=True,beam_size=5,vad_filter=False,condition_on_previous_text=False)
 for s in segments:
  row={'region':name,'start':s.start+start,'end':s.end+start,'text':s.text,'words':[{'text':w.word.strip(),'start':w.start+start,'end':w.end+start,'probability':w.probability} for w in (s.words or [])]}
  all.append(row);print(json.dumps(row),flush=True)
 json.dump(all,open('projects/four-dollars-spoken-check.json','w'),indent=2)
