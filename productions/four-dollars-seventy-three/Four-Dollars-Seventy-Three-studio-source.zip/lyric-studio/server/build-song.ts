import fs from "node:fs/promises";
import { demo } from "../src/sample";
import { qc, Project, Line } from "../src/model";
const source = await fs.readFile("projects/four-dollars-lyrics.txt", "utf8");
const aligned = JSON.parse(
  await fs.readFile("projects/four-dollars-aligned-lines.json", "utf8"),
) as {
  section: string;
  text: string;
  start: number;
  end: number;
  words: { text: string; start: number; end: number; confidence: number }[];
}[];
const { duration, analysis } = JSON.parse(
  await fs.readFile("projects/four-dollars-analysis.json", "utf8"),
);
// Preserve the supplied text. Keep low acoustic confidence visible in the source.
const lines: Line[] = aligned.map((l, i) => ({
  id: `fd-${i}`,
  text: l.text,
  start: l.start,
  end: l.end,
  words: l.words.map((w) => ({ ...w, review: w.confidence < 0.25 })),
  preset: /^(Cancel|Nice|Yeah|Financially|Still|I'd like|Let's not|LOW)/.test(
    l.text,
  )
    ? "impact"
    : "cinematic",
}));
// Synthetic bank voice confuses the acoustic model. Restrict cues using the
// independently measured speech intervals; do not stretch words across silence.
lines[0].end = 5.65;
lines[1].end = 8.15;
lines[1].words[1].end = 8.08;
lines[2].start = 9.3;
lines[2].end = 11.35;
lines[2].words = [
  { text: "and", start: 9.3, end: 9.64, review: true },
  { text: "seventy-three", start: 9.64, end: 10.48, review: true },
  { text: "cents.", start: 10.48, end: 11.22, review: false },
];
// A readable phrase may hold into a short gap, while word timestamps remain exact.
for (let i = 0; i < lines.length; i++) {
  const l = lines[i];
  l.start = Math.max(
    0,
    l.start - 0.07,
    i ? lines[i - 1].words.at(-1)!.end + 0.01 : 0,
  );
}
for (let i = 0; i < lines.length; i++) {
  const l = lines[i],
    next = lines[i + 1]?.start ?? duration;
  l.end = Math.max(l.words.at(-1)!.end, Math.min(next - 0.015, l.end + 0.16));
}
const boundaries: [number, number, string, string, number][] = [
  [0, 16, "Opening balance", "balance", 0.2],
  [16, 28.15, "Pocket change / instrumental", "hook", 0.35],
  [28.15, 42.1, "Verse 1 / everyday arithmetic", "grocery", 0.5],
  [42.1, 50.7, "Grocery mathematics", "grocery", 0.6],
  [50.7, 62.8, "What remains", "balance", 0.45],
  [62.8, 73.94, "Hook / entirely mine", "hook", 0.75],
  [73.94, 86.3, "Verse 2 / recurring charges", "bills", 0.55],
  [86.3, 96.3, "Cancel / cost of living", "bills", 0.68],
  [96.3, 99.44, "Financially speaking", "balance", 0.08],
  [99.44, 110.2, "Hook / no apologies", "hook", 0.8],
  [110.2, 134.6, "Jazz break", "jazz", 0.6],
  [134.6, 151.45, "Verse 3 / what matters", "home", 0.42],
  [151.45, 157.1, "Perspective, with limits", "home", 0.4],
  [157.1, 171.25, "Bridge / Friday", "bridge", 0.5],
  [171.25, 184.6, "Final hook / more than a number", "final", 0.85],
  [184.6, 193.4, "Small change / instrumental", "jazz", 0.65],
  [193.4, 202, "Low balance alert", "outro", 0.12],
  [202, duration, "Closing time", "outro", 0.25],
];
const p: Project = {
  ...structuredClone(demo),
  id: "four-dollars-seventy-three",
  title: "Four Dollars Seventy-Three",
  artist: "",
  audio: "/media/four-dollars-master.wav",
  duration,
  lyrics: source,
  lines,
  style: "finance",
  accent: "#b8c99b",
  intensity: 0.4,
  approved: true,
  branding: false,
  settings: { width: 1920, height: 1080, fps: 24 },
  analysis: {
    ...analysis,
    bpm: analysis.bpm / 2,
    beats: analysis.beats.filter((_: number, i: number) => i % 2 === 0),
    peak: analysis.peak * 0.68,
    method:
      "RMS + onset autocorrelation; 85.7 BPM half-time interpretation, not a verified metronomic grid. Supplied lyrics aligned with local CTC, section anchors checked against Whisper small.en. Confidence retained for review.",
  },
  scenes: boundaries.map(([start, end, label, environment, energy], i) => ({
    id: `fds-${i}`,
    start,
    end,
    label,
    environment,
    energy,
    camera: environment === "jazz" ? "orbit" : "dolly",
    effects: 0.35,
  })),
  treatment: await fs.readFile("docs/four-dollars-treatment.md", "utf8"),
  history: [
    "User approved jazz-finance treatment",
    "Supplied lyrics preserved exactly; bracketed directions excluded from lyric cues",
    "Local CTC acoustic alignment constrained to independently transcribed sections",
    "Original source decoded peak exceeds full scale; render master attenuated 3.35 dB",
    "Whisper disagreement and low acoustic-confidence words retained for listening review",
  ],
};
await fs.writeFile(
  "projects/four-dollars-seventy-three.json",
  JSON.stringify(p, null, 2),
);
const captions = lines.flatMap((l) =>
  l.words.map((w) => ({
    text: w.text,
    startMs: Math.round(w.start * 1000),
    endMs: Math.round(w.end * 1000),
    timestampMs: Math.round(w.start * 1000),
    confidence: (w as any).confidence ?? null,
  })),
);
await fs.writeFile(
  "projects/four-dollars-captions.json",
  JSON.stringify(captions, null, 2),
);
function ts(t: number) {
  return new Date(Math.round(t * 1000))
    .toISOString()
    .slice(11, 23)
    .replace(".", ",");
}
await fs.writeFile(
  "exports/Four-Dollars-Seventy-Three.srt",
  lines
    .map((l, i) => `${i + 1}\n${ts(l.start)} --> ${ts(l.end)}\n${l.text}\n`)
    .join("\n"),
);
await fs.writeFile(
  "exports/Four-Dollars-Seventy-Three.qc.json",
  JSON.stringify(
    {
      warnings: qc(p),
      wordCount: captions.length,
      lyricPhraseCount: lines.length,
      unreviewedWords: lines.flatMap((l) => l.words).filter((w) => w.review)
        .length,
      notes: [
        "Nice and synthetic bank/notification speech remain uncertain. Timing is acoustic alignment with corrections, not manually verified sung-word ground truth.",
        "Original lyrical punctuation and profanity preserved. Bracketed cues control scenes and are not printed as lyrics.",
        "Instrumental tail preserved in full.",
      ],
    },
    null,
    2,
  ),
);
console.log("Project created", p.duration, p.lines.length, qc(p));
