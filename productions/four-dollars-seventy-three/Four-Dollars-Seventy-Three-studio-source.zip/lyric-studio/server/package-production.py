"""Build a reproducible source archive without redistributing the raw song."""
from pathlib import Path
import zipfile
patterns=['src/*','server/*','docs/*.md','docs/licenses/*','tests/*','public/fonts/*','public/plates/*']
files=[p for pattern in patterns for p in Path('.').glob(pattern) if p.is_file()]
files += [Path(x) for x in ['.gitignore','package.json','package-lock.json','tsconfig.json','index.html','README.md','public/media/demo.wav','projects/four-dollars-seventy-three.json','projects/four-dollars-captions.json','projects/four-dollars-aligned-lines.json','projects/four-dollars-lyrics.txt','projects/four-dollars-analysis.json']]
with zipfile.ZipFile('exports/Four-Dollars-Seventy-Three-studio-source.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
 for p in files:
  if p.is_file():z.write(p,'lyric-studio/'+str(p))
print('Source archive bytes:',Path('exports/Four-Dollars-Seventy-Three-studio-source.zip').stat().st_size)
